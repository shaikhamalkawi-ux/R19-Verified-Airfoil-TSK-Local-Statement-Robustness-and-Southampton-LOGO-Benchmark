# EP21 — exact OOF source recovery and local verification

The exact pinned R5 CSV was recovered from the user-supplied printed PDF, not from a new model run. Git blob SHA-1: `13969778bd29858f4117912e9dbf99ca16e6929a`; SHA-256: `1d87613c1d2bd103ecde478e421ecfda449b455706bce42a5ef6d00c40f34591`. The source has 30,060 data records and 1,948,267 bytes.

The EP21 AF7 `audit_support.py --oof` and `verify_certificates.py` were executed locally using the original AF3, with the recovered CSV. All 106 exact support certificates and all 12 top-K rankings match EP21. The certificate, ranking and independent QA files are byte-identical. The full-precision error summaries have small rounding-level differences only.

Use this verification addendum with the public operating-support audit and its pinned inputs. No new model fits or scientific findings, manuscript edits or journal submission were performed by the local verification. The recovered CSV is byte-identical to the pinned already-public source; the printed PDF is excluded. The result concerns support in the three operating configuration coordinates, not full F5 input support.
