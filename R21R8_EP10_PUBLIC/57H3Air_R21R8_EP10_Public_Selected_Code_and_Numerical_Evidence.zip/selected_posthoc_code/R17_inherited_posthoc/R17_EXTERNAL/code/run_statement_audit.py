from __future__ import annotations
from pathlib import Path
import json, math
import numpy as np
import pandas as pd
from joint_core import pointwise_bound, minimum_cost

ROOT=Path(__file__).resolve().parents[1]
STATES=ROOT/'results/model/states'
OUT=ROOT/'results/statement'
WIT=OUT/'witnesses'
OUT.mkdir(parents=True,exist_ok=True); WIT.mkdir(exist_ok=True)
ETA=0.01
GAMMA=0.001
GAMMA_EQ=1.0
TOL=5e-7


def objective_parts(z):
    P=z['P']; beta=z['beta']; lam=float(z['lam']); y=z['ytrain']; off=float(z['offset'])
    yc=y-off
    res=yc-P@beta
    J=float(np.mean(res**2)+lam*np.dot(beta,beta))
    H=P.T@P/len(P)+lam*np.eye(P.shape[1])
    station=np.max(np.abs(P.T@(P@beta-yc)/len(P)+lam*beta))
    return H,J,float(station)


def scaled_pointwise(P,j,eps):
    """Column-equilibrated LP with direct primal/dual objective checks."""
    from scipy.optimize import linprog
    norms=np.linalg.norm(P,axis=0)
    S=1/np.maximum(norms,1e-300)  # d = diag(S) u
    Q=P*S[None,:]
    c=np.zeros(P.shape[1]); c[j]=S[j]
    B=np.vstack([Q,-Q]); ub=np.full(2*len(P),eps)
    res=linprog(-c,A_ub=B,b_ub=ub,bounds=[(None,None)]*P.shape[1],method='highs',
                options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
    if not res.success:
        return {'status':'failed','message':res.message}
    u=np.asarray(res.x); d=S*u
    raw=-np.asarray(res.ineqlin.marginals); mu=np.maximum(raw,0.)
    residual=float(np.linalg.norm(B.T@mu-c))
    primal=float(d[j]); dual=float(eps*mu.sum())
    return {'status':'optimal','d':d,'primal':primal,'dual':dual,'gap':dual-primal,
            'residual':residual,'max_training':float(np.max(np.abs(P@d)))}

def solve_target(P,H,J,j,beta_j,eps,gamma):
    target=-(1+gamma)*beta_j
    lp=scaled_pointwise(P,j,eps)
    if lp.get('status')!='optimal':
        return {'classification':'UNRESOLVED_POINTWISE','target':target,'lp_message':lp.get('message','')}
    maxmag=max(lp['primal'],0.0)  # symmetry gives the negative extreme
    rec={'target':target,'pointwise_primal':float(lp['primal']),'pointwise_dual':float(lp['dual']),
         'pointwise_gap':float(lp['gap']),'pointwise_residual':float(lp['residual'])}
    # tight dual certificate: if even dual < required coefficient change, target is impossible.
    if lp['dual'] + 5e-9 < abs(target):
        rec['classification']='PROTECTED_BY_POINTWISE'; return rec
    if maxmag + 5e-9 < abs(target):
        rec['classification']='UNRESOLVED_POINTWISE_GAP'; return rec
    initial=np.asarray(lp['d'])*(target/lp['primal'])
    q=minimum_cost(P,H,J,j,target,eps,initial=initial)
    rec['qp_status']=q.get('status','')
    if q.get('status')!='optimal':
        rec['classification']='UNRESOLVED_QP'; rec['solver_message']=q.get('solver_message',q.get('status','')); return rec
    rec.update({k:float(q[k]) if isinstance(q.get(k),(float,np.floating,int,np.integer)) else q.get(k)
                for k in ['cost','dual_lower','gap','max_training','target_error','stationarity_inf','iterations','time']})
    if q['max_training'] <= eps + TOL and q['target_error'] <= 1e-6 and q['cost'] <= ETA + 2e-7:
        rec['classification']='REVERSAL_WITNESS'
        rec['d']=q['d']; rec['upper_mu']=q['upper_mu']; rec['lower_mu']=q['lower_mu']; rec['nu']=float(q['nu'])
    elif q['dual_lower'] > ETA + 1e-7:
        rec['classification']='PROTECTED_BY_JOINT_COST'
    elif q['cost'] > ETA and q['dual_lower'] > ETA - 5e-7:
        rec['classification']='PROTECTED_BY_JOINT_COST_TIGHT'
    else:
        rec['classification']='UNRESOLVED_GAP'
    return rec

rows=[]; sens=[]
for sp in sorted(STATES.glob('*.npz')):
    z=np.load(sp,allow_pickle=False)
    P=z['P']; Pt=z['Pt']; beta=z['beta']; R=int(z['R']); eps=float(z['epsilon']); fn=[str(x) for x in z['feature_names']]
    H,J,station=objective_parts(z)
    geom=sp.stem.rsplit('_fold',1)[0]; fold=int(sp.stem.rsplit('fold',1)[1]); block=len(fn)+1
    # primary only: log10_frequency coefficient (position 1 inside each rule block)
    for r in range(R):
        j=r*block+1; bj=float(beta[j])
        # zero reachability for a rigorous protected statement classification
        zero=solve_target(P,H,J,j,bj,eps,0.0)
        strict=solve_target(P,H,J,j,bj,eps,GAMMA)
        eq=solve_target(P,H,J,j,bj,eps,GAMMA_EQ)
        if zero['classification'].startswith('PROTECTED'):
            primary='PROTECTED_FROM_ZERO'
        elif strict['classification']=='REVERSAL_WITNESS':
            primary='STRICT_REVERSAL_WITNESS'
        else:
            primary='UNRESOLVED_BOUNDARY'
        rec={'geometry_id':geom,'fold':fold,'rule':r,'R':R,'h':float(z['h']),'lambda':float(z['lam']),
             'feature':'log10_frequency','coefficient':bj,'epsilon':eps,'eta':ETA,'J0':J,'stationarity_inf':station,
             'classification':primary,
             'zero_class':zero['classification'],'strict_class':strict['classification'],'equal_class':eq['classification']}
        for prefix,obj in [('zero',zero),('strict',strict),('equal',eq)]:
            for k in ['target','pointwise_primal','pointwise_dual','pointwise_gap','pointwise_residual','cost','dual_lower','gap','max_training','target_error','stationarity_inf']:
                if k in obj and not isinstance(obj[k],np.ndarray): rec[f'{prefix}_{k}']=obj[k]
        # archive witnesses and compute held-out transport for any strict/equal witness
        for tag,obj in [('strict',strict),('equal',eq)]:
            if obj.get('classification')=='REVERSAL_WITNESS':
                d=np.asarray(obj['d']); train=P@d; test=Pt@d; newcoef=bj+d[j]
                rec[f'{tag}_heldout_max']=float(np.max(np.abs(test)))
                rec[f'{tag}_heldout_rms']=float(np.sqrt(np.mean(test**2)))
                rec[f'{tag}_new_coefficient']=float(newcoef)
                wp=WIT/f'{geom}_fold{fold:02d}_rule{r:02d}_{tag}.npz'
                np.savez_compressed(wp,d=d,upper_mu=np.asarray(obj['upper_mu']),lower_mu=np.asarray(obj['lower_mu']),
                                    nu=np.array(obj['nu']),P_train=P,P_test=Pt,beta=beta,H=H,J0=np.array(J),epsilon=np.array(eps),
                                    eta=np.array(ETA),j=np.array(j),old_coefficient=np.array(bj),new_coefficient=np.array(newcoef),
                                    train_change=train,test_change=test)
                rec[f'{tag}_witness_file']=wp.relative_to(ROOT).as_posix()
        rows.append(rec)
        # sensitivity strict reversal at half and double epsilon
        for mult in [0.5,2.0]:
            e2=eps*mult
            zz=solve_target(P,H,J,j,bj,e2,0.0)
            ss=solve_target(P,H,J,j,bj,e2,GAMMA)
            if zz['classification'].startswith('PROTECTED'): cc='PROTECTED_FROM_ZERO'
            elif ss['classification']=='REVERSAL_WITNESS': cc='STRICT_REVERSAL_WITNESS'
            else: cc='UNRESOLVED_BOUNDARY'
            sens.append({'geometry_id':geom,'fold':fold,'rule':r,'epsilon_multiplier':mult,'epsilon':e2,'classification':cc,
                         'zero_class':zz['classification'],'strict_class':ss['classification'],
                         'strict_cost':ss.get('cost',np.nan),'strict_dual_lower':ss.get('dual_lower',np.nan)})

df=pd.DataFrame(rows); df.to_csv(OUT/'STATEMENT_AUDIT.csv',index=False)
pd.DataFrame(sens).to_csv(OUT/'EPSILON_SENSITIVITY.csv',index=False)
# summary geometry + overall
summ=[]
for geom,g in list(df.groupby('geometry_id'))+[('ALL_PRIMARY_GEOMETRIES',df)]:
    summ.append({'geometry_id':geom,'statements':len(g),'protected':int((g.classification=='PROTECTED_FROM_ZERO').sum()),
                 'reversible':int((g.classification=='STRICT_REVERSAL_WITNESS').sum()),
                 'unresolved':int((g.classification=='UNRESOLVED_BOUNDARY').sum()),
                 'equal_magnitude_reversible':int((g.equal_class=='REVERSAL_WITNESS').sum()),
                 'strict_witnesses_holding_heldout_epsilon':int(((g.strict_class=='REVERSAL_WITNESS') & (g.get('strict_heldout_max',pd.Series(np.nan,index=g.index))<=g.epsilon+1e-12)).sum()),
                 'strict_witnesses_total':int((g.strict_class=='REVERSAL_WITNESS').sum())})
sumdf=pd.DataFrame(summ);sumdf.to_csv(OUT/'STATEMENT_SUMMARY.csv',index=False)
print(sumdf.to_string(index=False))
print('UNRESOLVED',int((df.classification=='UNRESOLVED_BOUNDARY').sum()))
