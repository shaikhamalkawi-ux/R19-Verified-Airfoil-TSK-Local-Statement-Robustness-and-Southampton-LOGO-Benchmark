#!/usr/bin/env python3
"""Check exact support certificates and saved-prediction ranks without hull or LP solvers."""
from pathlib import Path
from fractions import Fraction as F
import argparse,hashlib,json,zipfile,io
import numpy as np,pandas as pd
p=argparse.ArgumentParser();p.add_argument('--af3',type=Path,required=True);p.add_argument('--results',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent
m=json.loads((root/'SOURCE_AND_METHOD.json').read_text());assert hashlib.sha256(a.af3.read_bytes()).hexdigest()==m['af3_sha256']
d=pd.read_csv(root/'inputs/airfoil_F5_SEMANTICALLY_VERIFIED.csv');assert hashlib.sha256((root/'inputs/airfoil_F5_SEMANTICALLY_VERIFIED.csv').read_bytes()).hexdigest()==m['source_data_sha256']
coords=d.groupby('group_id')[['angle_deg','chord_m','velocity_m_s']].first();scale=np.array([10,10000,10]);L=np.rint(coords.to_numpy()*scale).astype(np.int64);assert np.max(abs(L/scale-coords.to_numpy()))<=1e-12
T={g:tuple(map(int,row)) for g,row in zip(coords.index,L)};cert=json.loads((a.results/'SUPPORT_CERTIFICATES.json').read_text());out=pd.read_csv(a.results/'ALL106_SUPPORT_AND_ERROR.csv').set_index('group');assert len(cert)==len(out)==106 and len({x['group'] for x in cert})==106
pred=pd.read_csv(root/'inputs/public_group_metrics.csv').set_index('group'); inside=outside=0
with zipfile.ZipFile(a.af3) as z:
 for f in range(10):
  with np.load(io.BytesIO(z.read(f'inputs/states/AIRFOIL_ONESE_fold{f:02d}.npz')),allow_pickle=False) as s:
   gt=set(d.iloc[s['tr']].group_id);ge=set(d.iloc[s['te']].group_id);assert not gt&ge and gt|ge==set(T)
   subset=[v for v in cert if v['fold']==f];assert {v['group'] for v in subset}==ge
   for v in subset:
    g=v['group'];q=T[g];r=out.loc[g];assert r['fold']==f and r['training_groups']==len(gt)
    assert bool(r['outside_axis_range'])==any(q[k]<min(T[h][k] for h in gt) or q[k]>max(T[h][k] for h in gt) for k in range(3))
    if v['type']=='exact_rational_convex_combination':
     weights={h:F(w) for h,w in v['training_group_weights'].items()};assert set(weights)<=gt and all(w>=0 for w in weights.values()) and sum(weights.values())==1
     assert all(sum(w*T[h][k] for h,w in weights.items())==q[k] for k in range(3));assert not bool(r['outside_convex_hull']);inside+=1
    else:
     assert v['type']=='exact_integer_separating_plane' and v['lattice_scaling']==scale.tolist();o,n=v['point_on_plane'],v['normal'];dot=lambda x:sum((x[k]-o[k])*n[k] for k in range(3))
     assert dot(q)==v['heldout_signed_value']>0 and max(dot(T[h]) for h in gt)==v['max_training_signed_value']==0
     assert set(v['facet_training_groups'])<=gt and all(dot(T[h])==0 for h in v['facet_training_groups']);assert bool(r['outside_convex_hull']);outside+=1
    j=d.iloc[s['te']].group_id.to_numpy()==g;res=(s['Pt']@s['beta']+s['offset']-s['ytest'])[j];assert len(res)==r['rows']==pred.loc[g,'rows']
    assert abs(np.sqrt(np.mean(res*res))-r['tsk_rmse'])<1e-8 and abs(np.max(abs(res))-r['tsk_max_abs'])<1e-8
    assert abs(np.sqrt(pred.loc[g,'et_mse'])-r['et_rmse'])<1e-8 and abs(pred.loc[g,'et_max_abs']-r['et_max_abs'])<1e-8
assert inside==95 and outside==11
ranks=pd.read_csv(a.results/'TOP_K_SUPPORT_SUMMARY.csv');assert len(ranks)==12
for r in ranks.itertuples():
 b=out.sort_values(r.metric,ascending=False).head(r.top_k); assert list(b.index)==r.groups.split(';') and b.outside_convex_hull.sum()==r.outside_hull
q={'status':'PASS','exact_inside':inside,'exact_outside':outside,'total':inside+outside,'fixed_prediction_group_checks':106,'top_k_rank_checks':len(ranks),'scope':'Exact rational/integer arithmetic on admitted decimal lattice; no hull or LP solver, no model refit; Extra Trees uses the checked public OOF group summary.'}
print(json.dumps(q,indent=2));(a.results/'INDEPENDENT_QA.json').write_text(json.dumps(q,indent=2)+'\n')
