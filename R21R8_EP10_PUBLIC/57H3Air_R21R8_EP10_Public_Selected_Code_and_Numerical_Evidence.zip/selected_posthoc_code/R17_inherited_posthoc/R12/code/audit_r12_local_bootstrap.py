"""Audit R12 B200 rule-pair, attempt and fold summaries without fitting code.
Designed independently of run_r12_local_bootstrap.py. No claim of new experiments.
"""
from pathlib import Path
import csv,json,hashlib
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parents[1]
DIR=ROOT/'results'/'local_bootstrap_B200'
REPS=['F5_LOG_F','F5_LOG_ST_DELTA','F5_LOG_K']
checks=[];foldrows=[];fails=[];allpairs=[];allreps=[]
def check(name,cond,details=None):
    checks.append({'gate':name,'passed':bool(cond),'detail':details})
    if not cond:print('QA FAIL',name,details)
for feature in REPS:
    for fold in range(10):
        base=f'{feature}_fold{fold:02d}_B200';summary=DIR/(base+'_summary.json');rp=DIR/(base+'_replicas.csv');pa=DIR/(base+'_pairs.csv')
        check('files:'+base,summary.exists() and rp.exists() and pa.exists())
        if not all(p.exists() for p in [summary,rp,pa]):continue
        one=json.loads(summary.read_text());r=pd.read_csv(rp);p=pd.read_csv(pa)
        r['representation']=feature;r['fold']=fold;p['representation']=feature;p['fold']=fold
        for k in ['R','h','lambda']:
            check('hyperparameter_pair:'+base+k,bool((r[k]==one[k]).all() and np.allclose(p[k],one[k])))
        check('replicas_200:'+base,len(r)==200 and set(r.draw)==set(range(200)) and one['B_attempts']==200)
        check('attempt_counts:'+base,(r.success.sum()==one['B_success']) and ((~r.success).sum()==one['B_failed']))
        check('no_fail_replace:'+base,len(one['failed_register'])==one['B_failed'])
        check('matching_fraction:'+base,bool((r.loc[r.success,'match_fraction'].between(0,1)).all() and r.loc[~r.success,'match_fraction'].isna().all()))
        check('match_pair_accounting:'+base, int(r.pairs_nonempty.sum())==len(p) and int(r.pairs_empty.sum())==one['empty_pairs'] and
            len(p)+int(r.pairs_empty.sum())==int(r.matched_rules.sum()))
        check('pair_positive_and_supported:'+base, bool((p.D_common_dB.ge(0)&p.D_parent_dB.ge(0)&p.J_weighted.ge(.5-1e-12)&
               p.retained_equal_group_fraction.between(0,1)&p.retained_rows.ge(1)&p.retained_groups.ge(1)&
               p.parent_support_rows.ge(p.retained_rows)&p.parent_support_groups.ge(p.retained_groups)).all()))
        check('matching_unique:'+base,not p.duplicated(['draw','parent_rule']).any() and not p.duplicated(['draw','matched_bootstrap_rule']).any())
        check('pair_bootstrap_success_only:'+base,set(p.draw).issubset(set(r.loc[r.success,'draw'])))
        check('pair_D_median:'+base,abs(float(np.median(p.D_common_dB))-one['median_pair_D_common_dB'])<1e-9)
        check('pair_Q_median:'+base,abs(float(np.median(p.retained_equal_group_fraction))-one['median_pair_support_retention'])<1e-9)
        check('fold_match_fraction:'+base,abs(float(r.loc[r.success,'match_fraction'].mean())-one['mean_match_fraction'])<1e-9)
        check('parent_R_is_tuned_selection:'+base,one['R'] in (8,10,12))
        allpairs.append(p);allreps.append(r)
        foldrows.append({'representation':feature,'outer_fold':fold,'R':one['R'],'h':one['h'],'lambda':one['lambda'],
             'bootstrap_attempts':one['B_attempts'],'bootstrap_success':one['B_success'],'bootstrap_failed':one['B_failed'],
             'matched_pairs':one['matched_pairs'],'empty_pairs':one['empty_pairs'],
             'fold_median_D_common_dB':one['median_pair_D_common_dB'],
             'fold_mean_match_fraction':one['mean_match_fraction'],
             'fold_median_support_retention':one['median_pair_support_retention'],
             'parent_OOF_max_abs_error_dB':one['parent_OOF_max_abs_error_dB']})
check('all_30_folds',len(foldrows)==30)
if len(foldrows)==30:
    allpairs=pd.concat(allpairs,ignore_index=True);allreps=pd.concat(allreps,ignore_index=True)
    fd=pd.DataFrame(foldrows).sort_values(['representation','outer_fold'])
    fd.to_csv(ROOT/'results'/'R12_B200_LOCAL_FOLD_RESULTS.csv',index=False)
    summary=[]
    for feature in REPS:
        a=fd[fd.representation==feature]
        summary.append({'representation':feature,'number_folds':len(a),'B_attempts':int(a.bootstrap_attempts.sum()),
          'B_success':int(a.bootstrap_success.sum()),'B_failed':int(a.bootstrap_failed.sum()),
          'matched_pairs':int(a.matched_pairs.sum()),'empty_common_support_pairs':int(a.empty_pairs.sum()),
          'median_of_fold_medians_D_common_dB':float(np.median(a.fold_median_D_common_dB)),
          'median_of_fold_mean_match_fraction':float(np.median(a.fold_mean_match_fraction)),
          'median_of_fold_median_support_retention':float(np.median(a.fold_median_support_retention)),
          'min_fold_median_D_common_dB':float(a.fold_median_D_common_dB.min()),
          'max_fold_median_D_common_dB':float(a.fold_median_D_common_dB.max())})
    summ=pd.DataFrame(summary);summ.to_csv(ROOT/'results'/'R12_B200_LOCAL_SUMMARY.csv',index=False)
    # Paired outer-fold summaries; no assumption of matched RULE identities across different representations
    pair=[];base=fd[fd.representation=='F5_LOG_F'].sort_values('outer_fold')
    for feature in REPS[1:]:
        sub=fd[fd.representation==feature].sort_values('outer_fold')
        d=sub.fold_median_D_common_dB.to_numpy()-base.fold_median_D_common_dB.to_numpy()
        mm=sub.fold_mean_match_fraction.to_numpy()-base.fold_mean_match_fraction.to_numpy()
        pair.append({'contrast':feature+' MINUS F5_LOG_F','median_fold_D_difference_dB':float(np.median(d)),
          'folds_alternative_D_lower':int(sum(d<0)),'min_fold_D_difference_dB':float(d.min()),
          'max_fold_D_difference_dB':float(d.max()),'median_fold_match_fraction_difference':float(np.median(mm)),
          'folds_alternative_match_higher':int(sum(mm>0)),
          'analysis_boundary':'Descriptive paired outer-fold summaries of separately matched rule sets, same draw labels, not independent rule-pair inference'})
    pd.DataFrame(pair).to_csv(ROOT/'results'/'R12_B200_FOLD_PAIRED_LOCAL_DIFFERENCES.csv',index=False)
    check('attempt_totals_6000',int(fd.bootstrap_attempts.sum())==6000)
    check('whole_106_group_coverage',int(pd.read_csv(ROOT/'results'/'R12_NESTED_REPRESENTATION_SUMMARY.csv').heldout_groups.min())==106)
else:summ=pd.DataFrame();pair=[]
report={'version':'R12','status':'PASS' if all(v['passed'] for v in checks) else 'FAIL','gates_passed':sum(v['passed'] for v in checks),'gate_count':len(checks),
        'failures':[v for v in checks if not v['passed']],'local_summary':summary if len(foldrows)==30 else [],
        'paired_fold_differences':pair,
        'boundaries':['D is conditional on successful matches and joint relative firing >=0.1 on parent anchors, not an acoustic prediction error',
                      'Stable local functions may still be inaccurate; unmatched rules and failed resamples are not zeros',
                      'Bootstrap replicates and rule pairs depend on the same observed 106 configurations',
                      'Different coordinate representations can have different matched pairs and selected numbers of rules',
                      'No causal physical or out-of-geometry claims; R9/R11 unchanged']}
(ROOT/'qa'/'R12_LOCAL_BOOTSTRAP_INDEPENDENT_AUDIT.json').write_text(json.dumps(report,indent=2,allow_nan=False))
print('LOCAL QA',report['gates_passed'],'/',report['gate_count'],report['status'])
if len(foldrows)==30:print(summ.to_string(index=False));print(pd.DataFrame(pair).to_string(index=False))
if report['status']!='PASS':raise SystemExit(1)
