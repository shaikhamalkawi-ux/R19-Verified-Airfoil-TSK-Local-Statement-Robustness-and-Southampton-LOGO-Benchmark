from __future__ import annotations
import os, json, re
for v in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']: os.environ.setdefault(v,'1')
from pathlib import Path
import numpy as np, pandas as pd, scipy.linalg
from scipy.special import logsumexp
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
SEEDS=(11,23,47,71,101); RSET=(2,4,6); HSET=(.75,1.,1.5); LSET=(1e-6,1e-4,1e-2,1.,100.); TOL=1e-6;MAX_ITER=2000;FLOOR=.05
PRIMARY=('RisoB1-15','RisoB1-18','Aerofoil-18','Aerofoil-21')

def fcm(Z,R):
    n,p=Z.shape;z2=(Z*Z).sum(1,keepdims=True);best=None
    for seed in SEEDS:
        rng=np.random.default_rng(seed);U=rng.random((n,R))+1e-12;U/=U.sum(1,keepdims=True);conv=False
        for it in range(1,MAX_ITER+1):
            UM=U*U;C=(UM.T@Z)/UM.sum(0)[:,None];D=np.maximum(z2+(C*C).sum(1)[None,:]-2*Z@C.T,1e-25);inv=1/D;new=inv/inv.sum(1,keepdims=True)
            delta=float(np.max(abs(new-U)));U=new
            if delta<TOL:conv=True;break
        UM=U*U;C=(UM.T@Z)/UM.sum(0)[:,None];D=np.maximum(z2+(C*C).sum(1)[None,:]-2*Z@C.T,0);obj=float(np.sum(UM*D))
        if conv and (best is None or (obj,seed)<(best['obj'],best['seed'])):
            vari=(UM.T@(Z*Z))/UM.sum(0)[:,None]-C*C;best={'C':C,'S0':np.maximum(np.sqrt(np.maximum(vari,0)),FLOOR),'obj':obj,'seed':seed,'iters':it}
    return best

def fire(Z,C,S):
    q=(Z[:,None,:]-C[None,:,:])/S[None,:,:];la=-.5*np.sum(q*q,axis=2);return np.exp(la-logsumexp(la,axis=1,keepdims=True))
def design(Z,W):
    T=np.c_[np.ones(len(Z)),Z];return np.einsum('nr,nj->nrj',W,T).reshape(len(Z),-1)
def gram_betas(P,y):
    n=P.shape[0];ym=float(y.mean());yc=y-ym;G=P.T@P/n;rhs=P.T@yc/n;ev,V=scipy.linalg.eigh(G,check_finite=False);a=V.T@rhs
    return np.column_stack([V@(a/(ev+lam)) for lam in LSET]),ym
def ridge(P,y,lam):
    n,q=P.shape;A=np.vstack([P/np.sqrt(n),np.sqrt(lam)*np.eye(q)]);v=np.r_[(y-y.mean())/np.sqrt(n),np.zeros(q)]
    return scipy.linalg.lstsq(A,v,lapack_driver='gelsd',check_finite=False)[0]
def group_rmse(y,p,g):
    e=(y-p)**2;u,iv=np.unique(g,return_inverse=True);return float(np.sqrt(np.mean(np.bincount(iv,weights=e)/np.bincount(iv))))
def weights_for_groups(g):
    u,iv=np.unique(g,return_inverse=True);return 1/(len(u)*np.bincount(iv)[iv])
def features(d):
    return np.c_[np.log10(d.frequency_Hz.to_numpy(float)),d.angle_deg.to_numpy(float),d.trip_flag.to_numpy(float)], ['log10_frequency','angle_deg','trip_flag']

def fit_final(X,y,ix,R,h,lam):
    sc=StandardScaler().fit(X[ix]);Z=sc.transform(X[ix]);fc=fcm(Z,R)
    if fc is None:return None
    C=fc['C'];S=fc['S0']*h;W=fire(Z,C,S);P=design(Z,W);beta=ridge(P,y[ix],lam)
    return {'sc':sc,'C':C,'S':S,'W':W,'P':P,'beta':beta,'offset':float(y[ix].mean()),'seed':fc['seed'],'iters':fc['iters'],'R':R,'h':h,'lam':lam}
def predict(m,X):
    Z=m['sc'].transform(X);W=fire(Z,m['C'],m['S']);P=design(Z,W);return m['offset']+P@m['beta'],W,P

def run_geometry(d,geom,out):
    dd=d[d.geometry_id==geom].copy().reset_index(drop=True);X,fn=features(dd);y=dd.response_norm.to_numpy(float);g=dd.group_id.to_numpy(str)
    if len(np.unique(g))!=8:raise RuntimeError((geom,'expected 8 groups',len(np.unique(g))))
    outer=list(GroupKFold(4).split(X,y,g));states=out/'states';states.mkdir(parents=True,exist_ok=True);cdir=out/'candidates';cdir.mkdir(exist_ok=True)
    rows=[];preds=[]
    for fold,(tr,te) in enumerate(outer):
        inner0=list(GroupKFold(3).split(X[tr],y[tr],g[tr]));inner=[(tr[a],tr[b]) for a,b in inner0];ug=np.unique(g[tr]); rec=[]
        for R in RSET:
            losses={(h,l):{} for h in HSET for l in LSET};fscores={(h,l):[] for h in HSET for l in LSET};valid=True
            for itr,iva in inner:
                sc=StandardScaler().fit(X[itr]);Ztr=sc.transform(X[itr]);Zva=sc.transform(X[iva]);fc=fcm(Ztr,R)
                if fc is None:valid=False;break
                for h in HSET:
                    Ptr=design(Ztr,fire(Ztr,fc['C'],fc['S0']*h));Pva=design(Zva,fire(Zva,fc['C'],fc['S0']*h));B,ym=gram_betas(Ptr,y[itr]);yp=Pva@B+ym
                    for jj,lam in enumerate(LSET):
                        val=group_rmse(y[iva],yp[:,jj],g[iva]);fscores[(h,lam)].append(val)
                        for gg in np.unique(g[iva]):
                            s=g[iva]==gg;losses[(h,lam)][gg]=float(np.mean((y[iva][s]-yp[s,jj])**2))
            for h in HSET:
                for lam in LSET:
                    comp=valid and len(losses[(h,lam)])==len(ug);score=float(np.sqrt(np.mean(list(losses[(h,lam)].values())))) if comp else np.inf
                    se=float(np.std(fscores[(h,lam)],ddof=1)/np.sqrt(3)) if comp else np.nan
                    rec.append({'R':R,'h':h,'lambda':lam,'inner_rmse':score,'inner_se':se,'valid':bool(comp)})
        c=pd.DataFrame(rec);c.to_csv(cdir/f'{geom}_fold{fold:02d}.csv',index=False)
        byR=[]
        for R in RSET:
            z=c[(c.R==R)&c.valid].sort_values(['inner_rmse','h','lambda']);
            if len(z):byR.append(z.iloc[0].to_dict())
        ch=pd.DataFrame(byR);best=ch.sort_values(['inner_rmse','R']).iloc[0];thr=float(best.inner_rmse+best.inner_se);sel=ch[ch.inner_rmse<=thr+1e-12].sort_values(['R','inner_rmse']).iloc[0]
        R=int(sel.R);h=float(sel.h);lam=float(sel['lambda']);m=fit_final(X,y,tr,R,h,lam)
        if m is None:raise RuntimeError((geom,fold,'outer fit failure'))
        pp,Wt,Pt=predict(m,X[te]);rm=group_rmse(y[te],pp,g[te]);eps_rel=.1/6.896361277488791;eps=float(eps_rel*np.std(y[tr],ddof=0))
        row={'geometry_id':geom,'fold':fold,'R':R,'h':h,'lambda':lam,'inner_rmse':float(sel.inner_rmse),'outer_group_rmse_norm':rm,'train_groups':len(np.unique(g[tr])),'test_groups':len(np.unique(g[te])),'train_target_sd':float(np.std(y[tr],ddof=0)),'statement_epsilon':eps}
        rows.append(row)
        for ri,gg,yy,pr in zip(dd.row_id.iloc[te],g[te],y[te],pp):preds.append({'geometry_id':geom,'fold':fold,'row_id':ri,'group_id':gg,'actual_norm':yy,'pred_norm':pr})
        np.savez_compressed(states/f'{geom}_fold{fold:02d}.npz',P=m['P'],Pt=Pt,beta=m['beta'],lam=np.array(lam),offset=np.array(m['offset']),ytrain=y[tr],ytest=y[te],R=np.array(R),h=np.array(h),W=m['W'],weight=weights_for_groups(g[tr]),weight_test=weights_for_groups(g[te]),scale=m['sc'].scale_,mean=m['sc'].mean_,feature_names=np.asarray(fn),train_group=np.asarray(g[tr]),test_group=np.asarray(g[te]),train_row_id=np.asarray(dd.row_id.iloc[tr]),test_row_id=np.asarray(dd.row_id.iloc[te]),epsilon=np.array(eps))
        print('FOLD',geom,fold,row,flush=True)
    pd.DataFrame(rows).to_csv(out/f'{geom}_FOLDS.csv',index=False);pd.DataFrame(preds).to_csv(out/f'{geom}_OOF.csv',index=False)
    p=pd.DataFrame(preds);pooled=float(np.sqrt(p.assign(se=(p.actual_norm-p.pred_norm)**2).groupby('group_id').se.mean().mean()))
    return {'geometry_id':geom,'rows':len(dd),'groups':8,'pooled_equal_group_rmse_norm':pooled,'folds':rows}

def main():
    root=Path(__file__).resolve().parents[1];d=pd.read_csv(root/'data/SOUTHAMPTON_CANONICAL.csv');out=root/'results/model';out.mkdir(parents=True,exist_ok=True);s=[]
    with threadpool_limits(limits=1):
        for g in PRIMARY:s.append(run_geometry(d,g,out))
    (out/'MODEL_SUMMARY.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
if __name__=='__main__':main()
