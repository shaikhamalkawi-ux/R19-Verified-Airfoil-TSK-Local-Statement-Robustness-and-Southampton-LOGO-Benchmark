"""Rebuild all reported R15 tables from stored optimization records."""
from pathlib import Path
import json
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]
def main():
 out=ROOT/'results/reporting';out.mkdir(exist_ok=True)
 main=pd.read_csv(ROOT/'results/ALL_JOINT_STATEMENTS.csv');bud=pd.read_csv(ROOT/'results/budget/ALL_JOINT_STATEMENTS.csv');narrow=pd.read_csv(ROOT/'results/narrow/ALL_JOINT_STATEMENTS.csv')
 p=main[main.gamma==.001].copy();p['final_class']=np.where(p.status=='REVERSAL_WITHIN_1PCT','FEASIBLE_REVERSAL','SIGN_PROTECTED_POINTWISE')
 zero=main[main.gamma==0].copy();assert (zero.status.eq('TARGET_INFEASIBLE_POINTWISE').to_numpy()==p.status.eq('TARGET_INFEASIBLE_POINTWISE').to_numpy()).all()
 old=pd.read_csv(ROOT/'inputs/PRIOR_SCREEN_510.csv').rename(columns={'rule_zero_based':'rule','status':'prior_status'})
 m=p.merge(old[['fold','rule','feature','prior_status']],on=['fold','rule','feature'],validate='one_to_one');assert len(m)==510
 m.to_csv(out/'RESOLVED_510_STATEMENTS.csv',index=False)
 cross=m.groupby(['prior_status','final_class']).size().unstack(fill_value=0).reset_index();cross.to_csv(out/'PRIOR_TO_FINAL_TRANSITION.csv',index=False)
 feat=p.groupby(['feature','final_class']).size().unstack(fill_value=0).reset_index();feat.to_csv(out/'FEATURE_SIGN_COUNTS.csv',index=False)
 byfold=p.groupby(['fold','final_class']).size().unstack(fill_value=0).reset_index();byfold['condition_number']=p.groupby('fold').parent_condition.first().values;byfold.to_csv(out/'WITHIN_PARENT_COUNTS_AND_CONDITION.csv',index=False)
 # Both linear and quadratic feasibility bound thresholds are respected.
 combine=pd.concat([main[main.gamma.isin([0.,.001])],bud],ignore_index=True)
 rows=[]
 for gamma in [0.,.001]:
  for eps,g in combine[combine.gamma==gamma].groupby('epsilon'):
   for eta in [.0001,.001,.01,.05]:
    feasible=(g.minimum_relative_cost<=eta-1e-9)
    excluded=g.pointwise_only_protected|(g.dual_lower>=eta+1e-9)
    ambiguous=~(feasible|excluded)
    assert len(g)==510 and not(feasible&excluded).any()
    rows.append({'gamma':gamma,'epsilon_dB':eps,'eta_relative':eta,'eta_percent':100*eta,'feasible_target':int(feasible.sum()),'excluded_target':int(excluded.sum()),'numerically_unresolved':int(ambiguous.sum()),'pointwise_excluded':int(g.pointwise_only_protected.sum()),'joint_cost_excluded':int((excluded&~g.pointwise_only_protected).sum())})
 budget=pd.DataFrame(rows);budget.to_csv(out/'BUDGET_SURFACE.csv',index=False)
 assert (budget.numerically_unresolved==0).all()
 for eta,g in budget[budget.gamma==.001].groupby('eta_relative'):assert np.all(np.diff(g.sort_values('epsilon_dB').feasible_target)>=0)
 for eps,g in budget[budget.gamma==.001].groupby('epsilon_dB'):assert np.all(np.diff(g.sort_values('eta_relative').feasible_target)>=0)
 wrows=[]
 for name,data in [('original_h1p5',main),('paired_h1',narrow)]:
  for gamma in [0.,.001,1.]:
   g=data[data.gamma==gamma];wrows.append({'family':name,'gamma':gamma,'feasible_target':int(g.status.isin(['REVERSAL_WITHIN_1PCT','ZERO_REACHABLE_WITHIN_1PCT']).sum()),'pointwise_excluded':int(g.pointwise_only_protected.sum()),'total':len(g)})
 pd.DataFrame(wrows).to_csv(out/'WIDTH_TARGET_COUNTS.csv',index=False)
 # Post-hoc, input-only display convention: first equal-magnitude frequency witness;
 # then widest frequency pair in each supported observed configuration. All three
 # requested support thresholds are retained, not chosen for a favorable result.
 eq=main[(main.gamma==1)&(main.feature=='log10_frequency')&(main.status=='REVERSAL_WITHIN_1PCT')].sort_values(['fold','rule']);row=eq.iloc[0]
 f=int(row.fold);r=int(row.rule);z=np.load(ROOT/'inputs/states'/f'AIRFOIL_ONESE_fold{f:02d}.npz',allow_pickle=False);w=np.load(ROOT/'results'/f'AIRFOIL_ONESE_fold{f:02d}_WITNESSES.npz',allow_pickle=False);d=w[f'r{r:02d}_k1_eps0.1_g1_d'];T=z['T'];sl=slice(r*6,(r+1)*6)
 examples=[]
 for tau in [.1,.2,.3]:
  support=z['W'][:,r]>=tau;best=None
  for group in sorted(np.unique(z['gtrain'][support])):
   ix=np.flatnonzero(support&(z['gtrain']==group))
   if len(ix)<2:continue
   a=ix[np.argmin(T[ix,1])];b=ix[np.argmax(T[ix,1])];span=T[b,1]-T[a,1]
   if best is None or span>best[0]:best=(span,group,int(a),int(b))
  assert best is not None
  _,group,a,b=best;freq=10**(T[[a,b],1]*z['scale'][0]+z['mean'][0])
  assert np.max(abs(T[b,2:]-T[a,2:]))==0
  oldcontrast=float((T[b]-T[a])@z['beta'][sl]);newcontrast=float((T[b]-T[a])@(z['beta']+d)[sl]);assert abs(oldcontrast+newcontrast)<1e-12
  examples.append({'fold_zero_based':f,'rule_zero_based':r,'activation_cutoff':tau,'group':str(group),'row_a':int(z['ids_train'][a]),'row_b':int(z['ids_train'][b]),'frequency_a_Hz':float(freq[0]),'frequency_b_Hz':float(freq[1]),'firing_a':float(z['W'][a,r]),'firing_b':float(z['W'][b,r]),'original_local_contrast_dB':oldcontrast,'witness_local_contrast_dB':newcontrast,'all_training_max_change_dB':row.max_training_change,'heldout_max_change_dB':row.max_heldout_change,'objective_increase_percent':100*row.minimum_relative_cost})
  ix=np.flatnonzero(z['gtrain']==group);ix=ix[np.argsort(T[ix,1])]
  spec=pd.DataFrame({'frequency_Hz':10**(T[ix,1]*z['scale'][0]+z['mean'][0]),'firing':z['W'][ix,r],'original_local_dB':float(z['offset'])+T[ix]@z['beta'][sl],'witness_local_dB':float(z['offset'])+T[ix]@(z['beta']+d)[sl],'original_aggregate_dB':float(z['offset'])+z['P'][ix]@z['beta'],'witness_aggregate_dB':float(z['offset'])+z['P'][ix]@(z['beta']+d),'measured_SPL_dB':z['ytrain'][ix],'row_id':z['ids_train'][ix]})
  spec.to_csv(out/f'EXAMPLE_SPECTRUM_SUPPORT{tau:g}.csv',index=False)
 pd.DataFrame(examples).to_csv(out/'OBSERVED_FREQUENCY_CONTRASTS.csv',index=False)
 stats={'primary':{'slopes':len(p),'protected':int(p.pointwise_only_protected.sum()),'reversible':int((p.status=='REVERSAL_WITHIN_1PCT').sum()),'new_flips_from_unresolved':int(((m.prior_status=='JOINT_SET_UNRESOLVED_BY_THIS_SCREEN')&(m.final_class=='FEASIBLE_REVERSAL')).sum()),'new_protected_from_unresolved':int(((m.prior_status=='JOINT_SET_UNRESOLVED_BY_THIS_SCREEN')&(m.final_class=='SIGN_PROTECTED_POINTWISE')).sum()),'equal_magnitude_reversals':int(((main.gamma==1)&main.status.eq('REVERSAL_WITHIN_1PCT')).sum()),'max_strict_flip_objective_percent':100*float(p.minimum_relative_cost.replace(np.inf,np.nan).max()),'all_parents_have_both_classes':bool((byfold.FEASIBLE_REVERSAL>0).all() and (byfold.SIGN_PROTECTED_POINTWISE>0).all())},'transfer':[],'negative_result':'At epsilon=0.1 dB and eta=1%, the objective constraint excludes no additional signs beyond the pointwise LP; the critical-cost surface is still informative at tighter objective budgets or larger prediction budgets.'}
 for gamma in [.001,1.]:
  g=main[(main.gamma==gamma)&main.status.eq('REVERSAL_WITHIN_1PCT')];stats['transfer'].append({'gamma':gamma,'witnesses':len(g),'all_test_points_within_same_budget':int(g.heldout_pointwise_retained.sum()),'max_test_change_dB':float(g.max_heldout_change.max()),'max_objective_increase_percent':100*float(g.minimum_relative_cost.max())})
 stats['observed_spectrum_examples']=examples
 (out/'SUMMARY.json').write_text(json.dumps(stats,indent=2))
 print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
