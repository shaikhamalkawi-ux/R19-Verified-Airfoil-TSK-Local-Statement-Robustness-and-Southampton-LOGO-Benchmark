"""Create a reader-ready evidence note using frozen R11 outputs (not a revised manuscript)."""
from __future__ import annotations
from pathlib import Path
import json,pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import mm
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs'/'57_H3_Airfoil_R11_Scientific_Results_and_QA.pdf'
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DVS',FONT));pdfmetrics.registerFont(TTFont('DVS-Bold',BOLD))
s=getSampleStyleSheet();s.add(ParagraphStyle(name='RTitle',fontName='DVS-Bold',fontSize=17,leading=22,spaceAfter=13))
s.add(ParagraphStyle(name='RSub',fontName='DVS-Bold',fontSize=11.7,leading=16,spaceBefore=13,spaceAfter=8))
s.add(ParagraphStyle(name='RBody',fontName='DVS',fontSize=8.4,leading=13,spaceAfter=7))
s.add(ParagraphStyle(name='RSmall',fontName='DVS',fontSize=7.2,leading=10,spaceAfter=5))
s.add(ParagraphStyle(name='RCell',fontName='DVS',fontSize=7.0,leading=10))
s.add(ParagraphStyle(name='RHeader',fontName='DVS-Bold',fontSize=7,leading=10))
s.add(ParagraphStyle(name='RNote',fontName='DVS',fontSize=8.2,leading=12,spaceAfter=10))

spec=pd.read_csv(ROOT/'results'/'R11_B200_SUMMARY.csv')
paired=pd.read_csv(ROOT/'results'/'R11_FIXED_OOF_PAIRED_CONTRASTS.csv')
local=pd.read_csv(ROOT/'results'/'R11_LOCAL_D_FOLD_CONTRASTS.csv')
lambda_file=ROOT/'results'/'R11_B200_RIDGE_SUMMARY.csv'
lam=pd.read_csv(lambda_file) if lambda_file.exists() else None
audit=json.loads((ROOT/'qa'/'R11_INDEPENDENT_RECORD_AUDIT.json').read_text())
laudit=json.loads((ROOT/'qa'/'R11_LAMBDA_INDEPENDENT_AUDIT.json').read_text()) if (ROOT/'qa'/'R11_LAMBDA_INDEPENDENT_AUDIT.json').exists() else None

def P(t,style='RBody'):return Paragraph(t,s[style])
def num(v,p=3):return f'{v:.{p}f}'
def table(headers,rows,widths=None):
 d=[[P(str(x),'RHeader') for x in headers]]+[[P(str(z),'RCell') for z in x] for x in rows]
 w=widths
 tab=Table(d,colWidths=w,repeatRows=1,hAlign='LEFT')
 tab.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.4,colors.Color(.8,.8,.8)),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('BACKGROUND',(0,0),(-1,0),colors.Color(.92,.92,.92)),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
 return tab

story=[P('R11 | Targeted reproducibility follow-up to the R10 Airfoil pilot','RTitle'),
  P('57 H3 — NASA NACA 0012 airfoil self-noise • 10 October 2026 • Controlled post-pilot evidence note; not a journal manuscript replacement','RNote'),
  P('<b>Scope and result boundaries</b>','RSub'),
  P('The 1,503 observed spectra belong to 106 repeated operating configurations. The R11 calculation tests how predictive accuracy, rule matchability and conditional local-function disagreement respond to declared TSK structure and input placement. The R9 scientific results and manuscript remain locked. This continuation was designed after inspection of the R9/R10 results; it was not externally preregistered and is not validation on a new airfoil geometry.'),
  P('<b>Method</b>','RSub'),
  P('Ten outer GroupKFold partitions exclude entire (angle, chord, velocity) configurations. R10 input preprocessing, five input-only fuzzy-c-means restarts, fuzzifier 2, Gaussian width multiplier h=1, ridge penalty 0.01, normalized firing and Jaccard-based dummy-aware matching are retained without modification. Each selected model/fold underwent 200 whole-configuration bootstrap attempts, with the same group-resample indices across fixed-control specifications. Local D is the matched consequent-function RMSE evaluated where both normalized rule firing strengths are at least 0.1, not measured-SPL prediction error. Only successful matched pairs admit D; unmatched rules and fit failures are kept separate.'),
  P('<b>Six-specification B=200 study</b>','RSub')]
rows=[]
for _,r in spec.sort_values(['variant','R']).iterrows():
 rows.append([f"{r['variant']}, R={int(r.R)}",num(r.group_RMSE_dB),num(r.median_fold_D_common_dB),num(r.median_fold_match_fraction),num(r.median_fold_support_retention),f"{int(r.bootstrap_success)}/{int(r.bootstrap_attempts)}",str(int(r.matched_pairs))])
story.append(table(['Specification','Group RMSE (dB)','Joint D (dB)','Matched fraction','Retained support','B success','Matched pairs'],rows,[78,66,66,69,70,66,70]))
story.append(Spacer(1,8))
story.append(P('RMSE is pooled over 106 equal-weight held-out configurations. D, matching and retention are medians of the ten corresponding fold summaries. These statistics use distinct evaluation populations and must not be collapsed into a composite stability score.','RSmall'))

A=spec[(spec.variant=='A')&(spec.R==10)].iloc[0];B=spec[(spec.variant=='B')&(spec.R==10)].iloc[0];C=spec[(spec.variant=='C')&(spec.R==10)].iloc[0];D=spec[(spec.variant=='D')&(spec.R==10)].iloc[0]
PAB=paired[(paired.first_variant=='B')&(paired.second_variant=='A')].iloc[0]
story += [P('Shared-antecedent role comparisons at R=10','RSub'),
P(f"A uses four antecedent and four consequent features; B uses four antecedent and five consequent features. Adding displacement thickness <b>only to consequents</b> changes group RMSE from {A.group_RMSE_dB:.3f} to {B.group_RMSE_dB:.3f} dB. It changes fold-median joint-support D from {A.median_fold_D_common_dB:.3f} to {B.median_fold_D_common_dB:.3f} dB. All ten held-out folds have lower predictive error under B, while all ten have higher conditional D under B. The A/B branch has exactly the same antecedents, bootstrap draw identities, matches and common-support masks: {int(A.matched_pairs)} matched pairs each, match fraction {A.median_fold_match_fraction:.3f} and retention {A.median_fold_support_retention:.3f}.") ,
P(f"C uses five antecedent and four consequent features; D uses five antecedent and five consequent features. C-to-D changes group RMSE from {C.group_RMSE_dB:.3f} to {D.group_RMSE_dB:.3f} dB and conditional D from {C.median_fold_D_common_dB:.3f} to {D.median_fold_D_common_dB:.3f} dB. C/D share antecedents and matched masks, but the change in conditional D is not uniform across the ten folds. This interaction shows why the marginal effect of adding a consequent input must be qualified by the fixed antecedent representation."),
P(f"B minus A, paired fixed-output group RMSE difference: {PAB.group_RMSE_difference_dB:+.3f} dB; percentile range [{PAB.conditional_group_resampling_p2p5:+.3f}, {PAB.conditional_group_resampling_p97p5:+.3f}] dB from 5,000 resamplings of the 106 fixed OOF group-squared losses. This is a <b>conditional fixed-output resampling range</b>, not a retraining-inclusive confidence interval. The point contrast is favorable in {int(PAB.groups_first_mse_lower)} of 106 configurations."),
P('<b>Interpretive constraints</b>','RSub'),
P('Displacement thickness is constant within each operating configuration and is partly predictable from the other group variables. The role comparisons alter consequent dimensionality and possibly training-model regularization behavior. They do not establish a physical aerodynamic causal effect. In particular, the R9 one-SE-selected predictive endpoint is not replaced by these fixed h/lambda controls.')]

story += [P('Diagnostic figures','RTitle')]
for fn,caption in [('R11_Fold_Paired_B_minus_A.png','Matched-premise A/B contrast: ten fold-level differences. Negative x means B has lower held-out error; positive y means B has more local disagreement.'),('R11_Accuracy_vs_Conditional_D.png','All six controlled fixed-h and fixed-penalty structures. Conditional D cannot characterize unmatched rule functions.')]:
 p=ROOT/'figures'/fn
 if p.exists():
  img=Image(str(p));fac=min((163*mm)/img.drawWidth,(88*mm)/img.drawHeight);img.drawWidth*=fac;img.drawHeight*=fac
  story += [img,P(caption,'RSmall'),Spacer(1,12)]

story += [P('Ridge sensitivity under shared antecedents','RSub')]
if lam is not None:
 rows=[]
 for _,r in lam.iterrows():
  rows.append([f"{r['lambda']:g}",num(r.group_RMSE_dB),num(r.median_fold_D_common_dB),num(r.median_fold_match_fraction),str(int(r.failed_FCM)),str(int(r.matched_pairs))])
 story += [table(['Ridge lambda','Group RMSE (dB)','Joint D (dB)','Match','Failed B','Matched pairs'],rows,[73,90,88,68,70,74]),Spacer(1,12)]
 p=ROOT/'figures'/'R11_Ridge_Collapse_Tradeoff.png'
 if p.exists():
  img=Image(str(p));fac=min((162*mm)/img.drawWidth,(77*mm)/img.drawHeight);img.drawWidth*=fac;img.drawHeight*=fac;story.append(img)
else: story.append(P('Penalty extension not included in this partial report.'))
story += [P('Numerical shrinkage boundary','RSub'),
P('For centered targets and a full-coefficient ridge penalty, beta(lambda) = (Phi.T Phi/n + lambda I)^(-1) Phi.T(y − mean(y))/n, and norm(beta(lambda)) is bounded by norm(Phi.T(y − mean(y))/n)/lambda. Thus all fitted local coefficients tend to zero as lambda tends to infinity, and local rule functions tend to the respective fit-specific training means. If matching masks remain fixed across lambda, matched local D tends to the absolute difference between parent and bootstrap training means, not generally to zero. A small conditional D under strong shrinkage cannot certify physically reproducible rules. This is standard ridge algebra, not a novel theorem.'),
P('Independent computational admission and remaining boundaries','RSub'),
P(f"The fresh original R10 ZIP integrity and its SHA manifest passed 251/251 checks; the copied R10 code/data are byte-identical to their frozen input. The original executable R10 mathematical QA passed 22/22. The R11 B200 record audit passed {audit['validation_pass']}/{audit['validation_gates']} checks. " + (f"The five-lambda record audit passed {laudit['passed']}/{laudit['checks']} checks." if laudit else '') + ' Parent models and held-out prediction squared losses match the original R10 B30 records exactly; increasing B changes only resampling-dependent summaries.'),
P('Limits: every draw reuses original configuration units; pair counts are dependent. Matching fractions can vary with R because Gaussian centers and actual widths are relearnt even with constant multiplier h. Rule changes under alternative match thresholds, independently new wind-tunnel experiments, independent geometries, nested per-R inner-tuned predictive policy, and uncertainty over new training datasets are not covered by this numeric extension. Original downloaded UCI byte provenance remains separate from the verified derived/reconstructed numerical table.'),
P('Scientific status / publication decision','RSub'),
P('The R11 evidence is a candidate post-hoc supplement, not a silently revised R9 result. Do not replace R9 reported RMSE, D, match fractions, equations or conclusions. Do not upload R11 to GitHub/Zenodo or claim software licensing without author approval. Any journal-facing revision should first adjudicate scientific novelty and present a clearly versioned amendment, separate from the inherited one-SE results.'),
P('Sources: Brooks, Pope and Marcolini (1989), NASA/UCI Airfoil Self-Noise dataset, DOI 10.24432/C5VW2C, CC BY 4.0; frozen project source, GitHub commit 6c537312da0388a0c9a2784ee175be95f8657747; exact R10 source ZIP SHA-256 recorded in qa/R10_FROZEN_SOURCE_ADMISSION.json.','RSmall')]


story += [P('Next work required before modifying R9','RSub'),
 table(['Gate','Current position'],[
  ['Grouped inner-CV per rule count','Not executed in R11; required to compare prediction-optimal R at different fixed count levels.'],
  ['Alternative dimensional inputs','Not executed in R11; compare information-equivalent reparameterizations without mixing omitted features.'],
  ['External airfoil geometry','Absent; claims remain specific to NACA 0012 benchmark and admitted configurations.'],
  ['Source / repository governance','Original UCI-byte hash, software licence, Zenodo DOI and repository-release authorization remain open.'],
  ['Manuscript revision decision','Human review required; any admitted amendment must report R9 unchanged and clearly mark R11 as post-pilot.']
 ],[142,324]),
 Spacer(1,10),
 P('Reproduction: retained raw JSON per outer fold for all six B=200 structures and five-lambda shared-antecedent sensitivity; scripts, source-hash parity and audit controls ship together. To verify the frozen numerical outputs without rerunning model fitting, execute the independent record auditing scripts listed in README_FIRST.md.','RSmall')]

def footer(canv,doc):
 canv.setFont('DVS',7);canv.drawString(20*mm,12*mm,'57 H3 Airfoil • R11 numeric evidence • Not R9 manuscript');canv.drawRightString(A4[0]-20*mm,12*mm,str(doc.page))
SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=18*mm,title='57 H3 Airfoil R11 Scientific Results and QA',author='Research evidence report').build(story,onFirstPage=footer,onLaterPages=footer)
print('WROTE',OUT,OUT.stat().st_size)
