from __future__ import annotations
from pathlib import Path
import json, sys
import numpy as np, pandas as pd
from scipy.optimize import linprog
from scipy.linalg import cho_factor, cho_solve
ROOT=Path(__file__).resolve().parents[1]
STATES=ROOT/'results/model/states'; OUT=ROOT/'results/statement'; QA=ROOT/'qa'; QA.mkdir(exist_ok=True)
ETA=.01

def dual_pointwise_with_ridge_residual(P,H,J,j,eps):
    """Numerical joint upper bound on |d_j| under |Pd|<=eps and d'Hd<=ETA*J.
    Solve the pointwise LP dual after column equilibration. If equality has residual r,
    add sqrt(ETA*J)*sqrt(r'H^{-1}r); this preserves a valid exact-algebra bound for that residual.
    """
    norms=np.linalg.norm(P,axis=0); S=1/np.maximum(norms,1e-300); Q=P*S[None,:]
    c=np.zeros(P.shape[1]); c[j]=S[j]
    B=np.vstack([Q,-Q])
    du=linprog(np.full(2*len(P),eps),A_eq=B.T,b_eq=c,bounds=[(0,None)]*(2*len(P)),method='highs',
               options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
    if not du.success: raise RuntimeError(du.message)
    mu=du.x; mup=mu[:len(P)]; mum=mu[len(P):]
    r=P.T@(mup-mum)-np.eye(P.shape[1])[j]
    cf=cho_factor(H,lower=True,check_finite=False)
    corr=float(np.sqrt(ETA*J)*np.sqrt(max(0.0,float(r@cho_solve(cf,r,check_finite=False)))))
    base=float(eps*mu.sum()); return base+corr,base,corr,float(np.max(np.abs(r))),float(np.linalg.norm(r))

rows=[]; failures=[]; checks=0
for sp in sorted(STATES.glob('*.npz')):
    z=np.load(sp,allow_pickle=False); P=z['P']; beta=z['beta']; eps=float(z['epsilon']); R=int(z['R']); block=len(z['feature_names'])+1
    lam=float(z['lam']); y=z['ytrain']; off=float(z['offset']); yc=y-off; n=len(P)
    H=P.T@P/n+lam*np.eye(P.shape[1]); J=float(np.mean((yc-P@beta)**2)+lam*np.dot(beta,beta)); cf=cho_factor(H,lower=True,check_finite=False)
    stat=float(np.max(np.abs(P.T@(P@beta-yc)/n+lam*beta)))
    geom=sp.stem.rsplit('_fold',1)[0]; fold=int(sp.stem.rsplit('fold',1)[1])
    for rule in range(R):
        j=rule*block+1; bj=float(beta[j]); e=np.zeros(P.shape[1]);e[j]=1
        ell=float(np.sqrt(ETA*J*float(e@cho_solve(cf,e,check_finite=False))))
        dual,base,corr,rinf,rnorm=dual_pointwise_with_ridge_residual(P,H,J,j,eps)
        joint=min(ell,dual); source='OBJECTIVE_ONLY' if ell<=dual else 'POINTWISE_PLUS_OBJECTIVE_RESIDUAL'
        protected=joint+2e-8 < abs(bj)
        checks+=5
        if stat>2e-9 or rinf>5e-8 or not protected: failures.append({'state':sp.name,'rule':rule,'stationarity':stat,'rinf':rinf,'beta':bj,'ellipsoid':ell,'dual_joint':dual,'joint':joint})
        rows.append({'geometry_id':geom,'fold':fold,'rule':rule,'coefficient':bj,'epsilon':eps,'eta':ETA,'J0':J,
                     'objective_only_abs_change_bound':ell,'pointwise_dual_base':base,'dual_residual_correction':corr,
                     'pointwise_plus_objective_upper':dual,'joint_upper_bound':joint,'protection_source':source,
                     'protected_primary':protected,'critical_multiplier_lower_bound_zero':abs(bj)/joint if joint>0 else np.inf,
                     'dual_residual_inf':rinf,'stationarity_inf':stat})
v=pd.DataFrame(rows);v.to_csv(OUT/'INDEPENDENT_PROTECTION_CERTIFICATES.csv',index=False)
# Verify the one double-epsilon witness generated during sensitivity analysis.
wp=OUT/'witnesses/RisoB1-18_fold02_rule04_eps2x_strict.npz'
if wp.exists():
    w=np.load(wp,allow_pickle=False); d=w['d'];P=w['P_train'];Pt=w['P_test'];beta=w['beta'];j=int(w['j']);eps=float(w['epsilon']);H=w['H'];J=float(w['J0'])
    train=P@d;test=Pt@d;new=float(beta[j]+d[j]);cost=float(d@H@d/J)
    ok=(np.max(np.abs(train))<=eps+2e-8 and cost<=ETA+2e-7 and np.sign(new)==-np.sign(beta[j]))
    checks+=4
    if not ok: failures.append({'sensitivity_witness':'failed','trainmax':float(np.max(np.abs(train))),'eps':eps,'cost':cost,'old':float(beta[j]),'new':new})
    wit={'geometry_id':'RisoB1-18','fold':2,'rule':4,'epsilon_multiplier':2.0,'epsilon':eps,'old_coefficient':float(beta[j]),'new_coefficient':new,'objective_increase_fraction':cost,'training_max_change':float(np.max(np.abs(train))),'heldout_max_change':float(np.max(np.abs(test))),'heldout_rms_change':float(np.sqrt(np.mean(test**2))),'heldout_within_epsilon':bool(np.max(np.abs(test))<=eps+2e-8)}
else: wit={}
summary={'checks':checks,'failures':len(failures),'primary_statements':len(v),'protected_primary':int(v.protected_primary.sum()),
         'objective_only_protected':int(((v.objective_only_abs_change_bound+2e-8)<v.coefficient.abs()).sum()),
         'requiring_joint_pointwise_bound':int(((v.objective_only_abs_change_bound+2e-8)>=v.coefficient.abs()).sum()),
         'minimum_protection_margin_ratio':float((v.coefficient.abs()/v.joint_upper_bound).min()),
         'median_protection_margin_ratio':float((v.coefficient.abs()/v.joint_upper_bound).median()),
         'maximum_stationarity_inf':float(v.stationarity_inf.max()),'maximum_dual_residual_inf':float(v.dual_residual_inf.max()),
         'double_epsilon_witness':wit,'failure_records':failures}
(QA/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
if failures: raise SystemExit(2)
