# Project 57 H3Air — Independent Evidence Closure, R21R8

**Date:** 22 November 2026  
**Decision:** **NUMERICAL SOURCE-TO-REPLAY GATE PASS; IEEE ACCESS RESUBMISSION STILL HOLD.**  
**Manuscript:** *Local-Statement Robustness in Takagi–Sugeno Airfoil Self-Noise Regression: A Finite-Input Audit* (IEEE Access submission #Access-2026-52679).

## Executive scientific decision

The R5 historical archive preserves seeds, per-replicate coefficients/predictions, rule assignments/similarity and failure records for 28,000 attempted bootstrap fits, but did not retain the original full fitting-state bytes for each relearned rule base. A separate deterministic execution of the same R5 code and archived seeds now reproduces **40 of 40 complete tasks** (each 500 fixed-antecedent + 200 relearned-antecedent attempts). A checker that does not import the replay generator independently reads **all 27,998 newly saved fitted internal states**, validates their SHA-256 and tests them against original R5 arrays. Two original nonconvergences recur at the original task/seed identities and were not substituted. This is numerical reproducibility of a frozen model, not new experimental/physical validation and not byte recovery of the original October internal states.

## Primary verification results

| Verification criterion | Observed result | Gate |
|---|---:|---|
| Complete task archive pairs (ZIP + summary) | 40/40 | PASS |
| Original bootstrap attempt identities newly replayed | 28,000/28,000 | PASS |
| Successful fitted state records newly saved + individually hashed | 27,998 | PASS |
| Historical fit failures reproduced | 2/2 | PASS |
| Exact task/replicate identity of failures | F5 fold00 compact relearn141; F5 fold02 reference relearn115 | PASS |
| Maximum absolute prediction difference | 1.2573764252e-10 | PASS |
| Maximum absolute coefficient difference | 1.46974343807e-08 | PASS |
| Maximum absolute rule-similarity difference | 1.848521336e-14 | PASS |
| Numeric check acceptance | `atol=1e-7`, `rtol=1e-9`, exact assignment/seeds and finite masks | PASS |
| Saved ZIP total | 773,361,055 bytes (40 separately stored archives) | RECORDED |

The checker separately confirmed: 40 complete and exactly indexed attempt journals; all 27,998 state-member SHA-256 hashes; no duplicate/omitted attempt identifiers; exact register seeds and aligned rule matches; matching FCM seed/iteration records where available; fixed-versus-relearn outcome identity; and all LS/ridge predictions and aligned coefficients within the declared tolerances. The detailed per-task numerical results, maximum differences, file sizes and hashes are preserved separately.

## Original NASA/UCI data source

A **new current official** `airfoil_self_noise.dat` was downloaded from UCI, not reconstructed from the authors' spreadsheet, with 59,984 bytes and SHA-256 `74c75fd71783f1e6b71f8a622b993dc592897a97cd689c5090a07147a1b097b3`. Its 1,503 rows, six columns and 9,018 numeric cells were independently compared with the frozen R5-derived table. Maximum absolute numeric difference was `1.00613961606655e-16`; all differences were below `1e-12`. Row order and 106 operating-configuration groups match. This establishes **current-official-source numeric equivalence only**. The raw first-acquired October 2026 UCI bytes and their original hash are **not recovered**. A later downloaded hash cannot be described as a historical hash.

## Immutable scientific results

No new model selection, tuning, threshold, rule structure or test dataset was admitted. The originally published-audit outcomes remain: the one-standard-error TSK policy produces **403 protected and 107 strict-reversible slopes out of 510**, and the minimum-error-selected alternative produces **437 protected and 153 strict-reversible out of 590**, at the primary declared `epsilon=0.1 dB` and `eta=1%` budgets. Extra Trees' higher predictive accuracy remains a benchmark, not a reason to claim superior TSK predictions. The conditional finite-input statement audit does not establish aerodynamic causality or physically calibrated measurement uncertainty.

## Deliverable crosswalk

* `R21R8_FULL40_Completion_Certificate.json`: machine-readable 40-task release gate and individual ZIP hashes.
* `R21R8_Independent_Full28k_QA.json`: direct independent run/record comparisons.
* `R21R8_All40_TaskSummary.json`: task-by-task counts, differences, bytes and SHA-256.
* `R21R8_40Task_Archive_SHA256SUMS.txt`: 40 task archive checksums.
* `R21R8_Current_UCI_Source_QA.json`: raw-source comparison with 9,018 checked cells.
* 40 original-result-matched ZIP archives and 40 summaries stored under `NEW_FULLSTATE_TASK_ARCHIVES/` in the controlled Google Drive project. The archived 773 MB evidence is not necessarily licensed for public redistribution.
* `R21R8_Manuscript_CLEAN_AUTHOR_REVIEW.pdf`, `R21R8_Supplementary_AUTHOR_REVIEW.pdf` (S28), and the full verbatim 16-comment Response to Reviewers (DOCX/PDF) carry the new evidence into the manuscript.

## What is NOT closed (pre-resubmission gates)

1. Original first-acquired October 2026 NASA raw download bytes and its contemporaneous checksum remain unavailable; disclose this openly and distinguish the newly downloaded official file.
2. The newly saved full fitted-state bytes are **recomputed**; the historical original per-attempt internal-state bytes remain unavailable. Do not relabel the new evidence as October historical files.
3. The 40-archive ~773MB author-review evidence needs a final access/permission/reuse strategy (not merely links in a private folder). No author-approved software license or permanent published Zenodo DOI yet exists for the complete releasable code.
4. Final all-author manuscript/rebuttal and CRediT approval, journal portal metadata/AI disclosures, and full highlight-file author visual sign-off remain outstanding. IEEE Access allows only one resubmission opportunity.
5. No independent calibration of original SPL instrument uncertainty or new-airfoil physical validation was established by these software tests.
6. The generic IEEE LaTeX build generates persistent overfull-box warnings (also present in R21R7), and the highlighted PDF may over-mark reflowed passages. There are no reported undefined citations/references. Production sign-off should inspect these explicitly.

## Author decision

**Proceed with author review of R21R8 and repository permission/DOI closure. Do not press IEEE Access resubmission or Zenodo Publish until the remaining author-side gates have been approved.**
