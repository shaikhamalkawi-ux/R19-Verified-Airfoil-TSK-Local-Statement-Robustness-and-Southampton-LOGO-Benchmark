# Component scope

The Bristol measurements are by J. Branch, N. Zang and M. Azarpeyvand (2024), University of Bristol, DOI 10.5523/bris.30c8q39wi1mxf205flnun3l5rl. The original provider metadata identifies the Non-Commercial Government Licence for public sector information. Obtain the measurements directly from the official repository and comply with that licence; this package does not relicense them. The original archive and row-level measurements, prediction rows, fitted states, coefficient vectors and detailed source-derived arrays are excluded. The four expected summary files report aggregate research checks only.

Inherited project code retains its applicable previously authorized terms; see the earlier H3Air GitHub evidence release licence and component scope. The current public-access copy of the original reproduction scripts and aggregate checks is made available at the project representative’s instruction. No new blanket reuse licence is inferred. Do not redistribute generated source-derived payloads or private evidence without appropriate component-level clearance. No affiliation with or endorsement by the data provider is implied.

Source: https://doi.org/10.5523/bris.30c8q39wi1mxf205flnun3l5rl
Source licence: https://www.nationalarchives.gov.uk/doc/non-commercial-government-licence/non-commercial-government-licence.htm
Inherited project code and scope: https://github.com/shaikhamalkawi-ux/R19-Verified-Airfoil-TSK-Local-Statement-Robustness-and-Southampton-LOGO-Benchmark/releases/tag/h3air-r21r8-ep18-evidence-v1
