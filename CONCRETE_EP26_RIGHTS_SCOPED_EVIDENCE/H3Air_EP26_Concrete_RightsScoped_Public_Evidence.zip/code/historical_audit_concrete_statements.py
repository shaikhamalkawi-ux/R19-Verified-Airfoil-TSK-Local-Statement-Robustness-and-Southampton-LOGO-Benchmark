#!/usr/bin/env python3
"""Independent numerical finite-input coefficient bounds for an admitted mirror scenario.
Uses unchanged R17 LP/QP core; does NOT claim directed-rounding rigorous certification.
"""
import os
for x in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[x]='1'
import argparse,csv,json,sys,time
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from original_r17_optimization_core import pointwise_bound,minimum_cost

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--dataset',choices=('high','rounded','official'),default='high');ap.add_argument('--fold',type=int,required=True);args=ap.parse_args()
 folder=ROOT/'runs'/args.dataset
 with np.load(folder/f'fold{args.fold:02d}_state.npz') as z:d={k:z[k] for k in z.files}
 P=np.asarray(d['P']);Pt=np.asarray(d['Pt']);beta=d['beta'];y=d['ytrain'];lam=float(d['lam']);J=float(d['J']);H=d['H'];R=int(d['R']);sigma=float(np.std(y,ddof=0));q=len(beta);p=8
 assert P.shape==(len(y),R*(p+1)) and q==R*(p+1)
 total=[];start=time.monotonic()
 for input_idx,input_name in ((7,'curing_age'),(3,'water')):
  for rule in range(R):
   j=rule*(p+1)+input_idx+1
   for frac in (.01,.025,.05):
    eps=frac*sigma;target=-(1.001)*float(beta[j])
    # First solve exact pointwise prediction-only projection LP
    lp=pointwise_bound(P,j,eps)
    if lp['status']!='optimal':
     result={'classification':'HOLD_LP','lp_status':lp['status'],'solver_message':lp.get('message')};qp=None
    elif lp['upper'] < abs(target)-1e-7:
     result={'classification':'PROTECTED_BY_POINTWISE_LP','lp_lower':lp['lower'],'lp_upper':lp['upper'],'lp_gap':lp['gap'],'max_training':lp['max_training']};qp=None
    else:
     qp=minimum_cost(P,H,J,j,target,eps)
     if qp['status']=='optimal':
      cost=qp['cost'];dual=qp['dual_lower'];gap=qp['gap']
      tr_bound=qp['max_training']
      held_max=float(np.max(np.abs(Pt@qp['d'])))
      admissible=cost<=.01+1e-7 and tr_bound<=eps+1e-7 and qp['target_error']<1e-6
      if admissible: classification='REVERSIBLE_CONSTRUCTIVE'
      elif dual>.01+1e-7:classification='PROTECTED_BY_QP_DUAL'
      else:classification='HOLD_NUMERIC'
      result={'classification':classification,'relative_cost':cost,'dual_lower':dual,'gap':gap,'max_training':tr_bound,'max_heldout':held_max,'heldout_eps_pass':held_max<=eps+1e-7,'iterations':int(qp['iterations']),'stationarity_inf':qp['stationarity_inf'],'target_error':qp['target_error']}
      np.savez_compressed(folder/f'fold{args.fold:02d}_{input_name}_rule{rule}_eps{str(frac).replace(".","p")}_QP.npz',delta=qp['d'],mu_plus=qp['upper_mu'],mu_minus=qp['lower_mu'],nu=qp['nu'],beta=beta,original_target=beta[j],delta_target=target,max_training=tr_bound,max_heldout=held_max,relative_cost=cost,dual_lower=dual,eps=eps,stationarity_inf=qp['stationarity_inf'])
     else:
      result={'classification':'HOLD_QP','status':qp['status'],'message':qp.get('solver_message','')}
    total.append(dict(dataset=args.dataset,fold=args.fold,R=R,rule=rule,input_name=input_name,coef_index=j,coef_standardized=float(beta[j]),coef_physical=float(beta[j]/d['scale'][input_idx]),epsilon_fraction=frac,epsilon=eps,eta=.01,gamma=.001, **result))
    print('AUDIT',args.dataset,args.fold,rule,input_name,frac,result['classification'],'elapsed',round(time.monotonic()-start,1),flush=True)
 with (folder/f'fold{args.fold:02d}_audits.csv').open('w',newline='') as f:
  allkeys=list(dict.fromkeys(k for x in total for k in x))
  w=csv.DictWriter(f,fieldnames=allkeys);w.writeheader();w.writerows(total)
 counts={frac:{name:sum(x['classification']==name and x['epsilon_fraction']==frac for x in total) for name in set(y['classification'] for y in total)} for frac in (.01,.025,.05)}
 summary={'dataset':args.dataset,'fold':args.fold,'audits':len(total),'counts':counts,'slope_parameter_unit':'MPa/day for age; MPa/(kg/m^3) for water','tr_eps_only':True,'gamma':.001,'eta':.01,'elapsed_s':time.monotonic()-start}
 (folder/f'fold{args.fold:02d}_audit_summary.json').write_text(json.dumps(summary,indent=2));print('DONE',json.dumps(summary),flush=True)
if __name__=='__main__':
 with threadpool_limits(limits=1):main()
