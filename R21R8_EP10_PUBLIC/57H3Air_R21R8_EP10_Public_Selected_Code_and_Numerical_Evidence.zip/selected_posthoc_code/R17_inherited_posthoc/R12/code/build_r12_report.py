"""Create an audit-aligned LaTeX technical report from independently QA'd R12 tables."""
from pathlib import Path
import pandas as pd,json,subprocess,hashlib
ROOT=Path(__file__).resolve().parents[1];DOC=ROOT/'docs';DOC.mkdir(exist_ok=True)
ns=pd.read_csv(ROOT/'results'/'R12_NESTED_REPRESENTATION_SUMMARY.csv')
local=pd.read_csv(ROOT/'results'/'R12_B200_LOCAL_SUMMARY.csv')
interval=pd.read_csv(ROOT/'results'/'R12_FIXED_OOF_PAIRED_REPRESENTATION_CONTRASTS.csv')
pr=pd.read_csv(ROOT/'results'/'R12_TUNED_RULE_COUNT_SUMMARY.csv')
a=json.loads((ROOT/'qa'/'R12_INDEPENDENT_AGGREGATE_AUDIT.json').read_text())
b=json.loads((ROOT/'qa'/'R12_LOCAL_BOOTSTRAP_INDEPENDENT_AUDIT.json').read_text())
assert a['status']=='AUDITED' and b['status']=='PASS' and a['gate_count']==653 and b['gate_count']==483
code_names={'F5_LOG_F':'Original $\\log_{10} f$','F5_LOG_ST_DELTA':'$\\log_{10} St_{\\delta}$','F5_LOG_K':'$\\log_{10} k$'}
represent=['F5_LOG_F','F5_LOG_ST_DELTA','F5_LOG_K']
rows=[]
for r in represent:
    def ne(pol):return ns[(ns.representation==r)&(ns.selection_policy==pol)].iloc[0]
    lo=local[local.representation==r].iloc[0]
    rows.append(f"{code_names[r]} & {ne('ONE_SE').equal_group_RMSE_dB:.3f} & {ne('MIN_ERROR').equal_group_RMSE_dB:.3f} & {lo.median_of_fold_medians_D_common_dB:.3f} & {100*lo.median_of_fold_mean_match_fraction:.1f} & {100*lo.median_of_fold_median_support_retention:.1f} \\\\ ")
perlines=[]
for R in [2,4,6,8,10,12]:
    a2=[]
    for rep in represent:
        rr=pr[(pr.representation==rep)&(pr.R==R)].iloc[0]
        a2.append(f'{float(rr.equal_group_RMSE_dB):.3f}' if bool(rr.complete_all_106) else 'N/A$^{a}$')
    perlines.append(f"{R} & {a2[0]} & {a2[1]} & {a2[2]} \\\\ ")
intlines=[]
for alt,display in [('F5_LOG_ST_DELTA','$\\log_{10} St_\\delta$'),('F5_LOG_K','$\\log_{10} k$')]:
    z=interval[(interval.policy=='ONE_SE')&(interval.alternative_representation==alt)].iloc[0]
    intlines.append(f'{display} & {z.RMSE_difference_alt_minus_ref_dB:+.3f} & [{z.conditional_fixed_OOF_p2p5:+.3f}, {z.conditional_fixed_OOF_p97p5:+.3f}] & {int(z.groups_alt_lower_MSE)}/106 & {int(z.outer_folds_alt_lower_RMSE)}/10 \\\\ ')

tex=r'''\documentclass[10pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\usepackage{amsmath,amssymb,booktabs,graphicx,geometry,microtype,longtable}
\usepackage[hidelinks]{hyperref}
\geometry{margin=22mm,headheight=14pt}
\setlength{\parskip}{4pt}
\setlength{\parindent}{0pt}
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\lhead{57 H3 Airfoil | R12 numerical extension}
\rhead{10 October 2026}
\cfoot{\thepage}
\begin{document}
\begin{center}
{\Large\bfseries Nested rule-count tuning and dimensionless-coordinate sensitivity\\[3pt]
for Takagi--Sugeno airfoil self-noise regression}\\[8pt]
{\small R12 author-review technical report | R9 scientific manuscript preserved unchanged}
\end{center}
\vspace{3pt}
\textbf{Status.} Completed post-pilot analysis and independent record QA. This report is not an amended journal manuscript, not a preregistered confirmation, and not evidence from a new airfoil or independent wind-tunnel experiment.

\textbf{Abstract.} The existing NASA NACA 0012 benchmark provides 1,503 sound-pressure observations distributed across 106 operating configurations. We extended the prior fixed-width, fixed-penalty diagnostic by independently tuning Gaussian width and ridge penalty for each of six rule counts within five-fold grouped inner validation, before testing on complete excluded operating configurations in ten outer folds. Three information-preserving five-input coordinate representations were examined: original log frequency, log displacement-thickness Strouhal number, and log reduced frequency. A further 200 whole-configuration bootstrap attempts per outer fold and representation evaluated matched first-order local functions on joint relative firing support. The original representation reproduced the previously reported one-standard-error selected prediction error and rule-count frequencies. No consistent predictive advantage of the two transformed representations was established. The smaller conditional local disagreements of the transformed fits coincided with lower rule-match fractions; therefore a lower disagreement conditional on matched rules is not a general certificate of improved rule reproducibility.

\section{Frozen evidence and evaluation design}
The sole admitted observations are the inherited public NASA/UCI Airfoil Self-Noise records \cite{UCI,NASA}, represented by frequency $f$ (Hz), angle of attack $\alpha$ (degrees), chord $c$ (m), free-stream velocity $U$ (m/s), suction-side displacement thickness $\delta^*$ (m), and scaled sound pressure level (dB). A configuration is a unique $(\alpha,c,U)$ tuple. There are 106 configurations with 8--19 frequency observations each. No additional measurements or airfoil geometries were introduced.

The parent modeling procedure is unchanged from the frozen R10 code: fuzzy c-means on standardized antecedent inputs ($m=2$, five randomized starts 11, 23, 47, 71, 101, tolerance $10^{-6}$, iteration ceiling 2000), product-Gaussian memberships, first-order local consequents, and a full-coefficient positive ridge penalty. For each of ten outer \texttt{GroupKFold} partitions, all hyperparameter scores use only its training configurations. Five-fold inner \texttt{GroupKFold} scores determine a separate $(h,\lambda)$ for every rule count $R \in \{2,4,6,8,10,12\}$, with $h\in\{0.75,1,1.5\}$ and $\lambda\in\{10^{-6},10^{-4},10^{-2},1,100\}$. Every candidate is evaluated using the same training-fold scaling policy.

The primary error measure is the root of equally weighted held-out configuration mean squared errors:
\begin{equation}
 E_{\mathrm{grp}}=\left[\frac1G\sum_{g=1}^G\frac1{n_g}\sum_{i\in g}(y_i-\widehat y_i)^2\right]^{1/2}.
\label{eq:group}
\end{equation}
The minimum-inner-error policy chooses the best $(R,h,\lambda)$ using inner results alone. The compact one-SE policy chooses the smallest $R$ whose best inner $E_{\mathrm{grp}}$ is within one inner-fold standard error of the minimum-error winner (the SE is the empirical SD across its five inner-fold RMSEs divided by $\sqrt5$). This is a selection heuristic, not an independent confidence interval.

\section{Information-preserving aerodynamic coordinates}
The original input vector is $[\log_{10}f,\alpha,c,U,\log_{10}\delta^*]$. Two alternatives replace only the first coordinate, leaving the other four intact:
\begin{align}
 St_{\delta}&=f\delta^*/U,&\log_{10}f&=\log_{10}St_{\delta}+\log_{10}U-\log_{10}\delta^*,\\
 k&=\pi fc/U,&\log_{10}f&=\log_{10}k+\log_{10}U-\log_{10}c-\log_{10}\pi.
\label{eq:invert}
\end{align}
Positive $U,c,\delta^*$ make both coordinate changes invertible on the admitted rows. They add no independent acoustic or aerodynamic measurement. The R12 transforms are calculated at full retained input precision, rather than from rounded Excel display cells. Although these vectors have equivalent information content, standardization, Euclidean fuzzy clustering and axis-aligned Gaussian rule regions are not invariant to their coordinate mixing. Any fitted difference is therefore conditional on the numerical representation, not evidence of a new physical mechanism. Neither Reynolds number nor dynamic pressure was introduced, avoiding extra fluid-property assumptions.

\section{Nested prediction results}
Table~\ref{tab:summary} combines the separate endpoints for the three input representations. Every prediction value is computed from 106 complete outer-held-out configuration groups. The original one-SE policy is $4.166475$ dB and the minimum-error policy is $4.069013$ dB, reproducing the R9 reported three-decimal values (4.166 and 4.069 dB). The original one-SE rule-count distribution is likewise $R=8$ once, $R=10$ seven times, and $R=12$ twice. This confirms numerical consistency of the two calculation routes under the declared settings; it is not an independent physical replication.

\begin{table}[htbp]\centering\small
\caption{Outer predictive error and separate matched-rule reproducibility descriptors (all 10 folds). The $D^{\cap}$ and support-retention values are medians of fold-specific bootstrap summaries; they are not errors against SPL.}\label{tab:summary}
\begin{tabular}{lrrrrr}\toprule
Representation & One-SE $E_{\rm grp}$ & Min-error $E_{\rm grp}$ & $D^\cap$ (dB) & Matched (\%) & Retained (\%) \\
& (dB) & (dB) & & & \\
\midrule
__TABLE_SUMMARY__
\bottomrule\end{tabular}\end{table}

\begin{figure}[htbp]\centering\includegraphics[width=.76\linewidth]{figures/R12_Nested_Representation_RMSE.pdf}
\caption{Nested outer predictive error for the two inner-only selection policies. The displayed differences are small relative to the held-out error scale and do not measure physics or stability.}\label{fig:nested}\end{figure}

\begin{table}[htbp]\centering\small
\caption{One-SE predictive contrast: transformed representation minus original. Ranges are the 2.5--97.5 percentiles of 5,000 reweightings of 106 \emph{fixed out-of-fold} group losses, and omit training, tuning and independent-campaign uncertainty.}\label{tab:paired}
\begin{tabular}{lrrrr}\toprule
Alternative & Difference (dB) & Conditional range (dB) & Groups improved & Folds improved \\
\midrule
__TABLE_INTERVAL__
\bottomrule\end{tabular}\end{table}

The one-SE reduced-frequency representation obtains a lower aggregate RMSE by about $0.055$ dB, but its conditional range crosses zero and only 38 of 106 configurations have a lower squared loss. The log-Strouhal alternative increases aggregate RMSE by about $0.055$ dB. Neither result establishes a representation-wide predictive improvement.

\clearpage
\section{Rule-count profiles and nonconvergence}
Rule-specific scores in Table~\ref{tab:rule} permit like-$R$ comparisons after independent inner tuning of $(h,\lambda)$. These results should not be used to choose $R$ by inspecting outer scores; any deployable rule-count selection must be performed using training-side data only. In particular, at $R=8$, reduced frequency has a larger conditional difference from the original representation than at $R=10$ or $R=12$. A post hoc choice of $R$ from this table would be outcome-driven.

\begin{table}[htbp]\centering\small
\caption{Fully held-out equal-group RMSE (dB), tuning $h$ and $\lambda$ separately within each count. ``N/A'' denotes incomplete coverage and is not imputed.}\label{tab:rule}
\begin{tabular}{rrrr}\toprule
Rule count $R$ & Original $\log_{10}f$ & $\log_{10} St_\delta$ & $\log_{10} k$ \\
\midrule
__TABLE_RULE__
\bottomrule\end{tabular}\\[3pt]
{\footnotesize $^{a}$At $R=8$, the log-Strouhal fit had one inner fold in which all five FCM restarts failed; no valid inner score or outer prediction was admitted for that rule count and outer fold (only 95 groups covered).}
\end{table}

\begin{figure}[htbp]\centering\includegraphics[width=.86\linewidth]{figures/R12_Tuned_RuleCount_RMSE.pdf}
\caption{Rule-count prediction profiles. The invalid log-Strouhal $R=8$ full-cohort cell is omitted, not joined or replaced by a partial-cohort statistic.}\label{fig:complexity}\end{figure}

\section{Local-rule agreement under whole-configuration bootstrap}
For each of the three one-SE-selected systems in each outer fold, 200 configuration-bootstrap attempts re-estimated scaling, input-only fuzzy clustering and local consequents under the previously selected $(R,h,\lambda)$. The same group-draw identifiers were used across the feature representations at the same outer fold. Similarity was defined by equal-configuration weighted Jaccard firing scores; a Hungarian assignment could leave a rule unmatched when $J<0.5$. Local function disagreement $D^\cap$ was evaluated only on parent-training anchors where \emph{both} matched normalized firing strengths reached $0.1$, using common dB-scale full local consequent outputs and equal weighting of the retained configurations. The bootstrap responses and match identities are dependent; no pair-level $p$-values are provided.

All 6,000 attempted bootstrap retrainings succeeded; there were no zero-support matched pairs. Across the folds, original frequency had median match fraction 75.8\%, log-Strouhal 71.1\%, and log-reduced-frequency 68.9\%. Although conditional fold-median local disagreement is numerically lower for the two transformed inputs, their reduced matchability prevents interpreting this as a general increase in reproducibility: the unmatchable local rules have no $D^\cap$ value and are not counted as zero disagreement. The alternative fits also select different $R$ values, so matched-pair totals must not be compared as if they have a common rule denominator.

\begin{figure}[htbp]\centering\includegraphics[width=.84\linewidth]{figures/R12_Accuracy_vs_Local_Disagreement.pdf}
\caption{The two distinct endpoints: held-out prediction error against measured SPL versus matched local-function disagreement. This is not a composite score or an interpretation-quality certificate.}\label{fig:tradeoff}\end{figure}

\begin{figure}[htbp]\centering\includegraphics[width=.84\linewidth]{figures/R12_Fold_Conditional_Differences.pdf}
\caption{Outer-fold paired comparisons of conditional local function disagreement. Rule matches are recomputed separately after each coordinate transformation; the curves do not compare identical rule identities.}\label{fig:fold}\end{figure}

\clearpage
\section{Reproducibility checks and limitations}
\textbf{Calculation gate.} The independent prediction audit passed 653/653 defined checks; the independently reconstructed bootstrap summary passed 483/483 checks. Nine representative screening ridge solutions were checked against the original augmented least-squares solver, with maximum coefficient deviation below $3.1\times10^{-10}$ in that sample. The full inner study used 900 FCM fits, 899 with a convergent selected restart. The one failed fit invalidated 15 hyperparameter candidates from one rule-count/outer-fold grid, rather than assigning an artificial score. The 30 one-SE and 30 minimum-error selected fits all retain complete outer test configurations. Original R9 and R11 scientific values are not modified.

\textbf{Inference boundary.} There are only 106 operating configurations from one public airfoil benchmark. The 6,000 resamples reuse them, and the 46,402 matched rule pairs from the three feature representations are not independent experiments. The matching cutoff $J\geq0.5$ and joint normalized activation threshold 0.1 are declared operational choices, not physical support or interpretability thresholds. Distinct representations may produce different selected rule counts, localized Gaussian memberships, and conditional evaluation sets. Comparisons based on their matched subsets cannot be identified as a causal effect of a frequency coordinate transformation. Even exact reproduction of historical predictions would not prove physical rule identifiability.

\textbf{Provenance and release status.} The inherited R9 dataset is semantically and numerically audited, but an original UCI download byte-for-byte SHA-256 attestation remains outstanding. The public GitHub record at commit \texttt{6c537312da0388a0c9a2784ee175be95f8657747} holds R9-era evidence; this R12 package is an author-held extension, not a GitHub/Zenodo publication. Software reuse permissions and public full-state archive release remain subject to author decision. No new dataset or independent aircraft geometry is included.

\textbf{Decision.} Keep R9 as the scientific baseline. The nested-tuning parity and paired coordinate sensitivities merit consideration as a concise post hoc supplementary analysis, but the available results do not justify a statement that dimensionless coordinates universally improve prediction or stabilize fuzzy rules. The next integration step is an editorial and evidence-scope decision, not automatic replacement of R9 scientific tables. The previously reported five-input Extra Trees $2.381$ dB performance remains a distinct, stronger aggregate accuracy baseline; none of the R12 TSK fits establishes predictive superiority over it.

\section*{Traceable artefacts}
The deliverable contains the unmodified R10 fitting module, inherited source CSV with hash lineage, executable R12 nested and bootstrap scripts, 2,700 candidate rows, 179 valid outer rule-specific fits, all 30 selected-pipeline predictions per policy, fold-level matching/conditional disagreement rows, independent QA JSON, figures, and a SHA-256 manifest. A fresh archive extraction can run the independent audits before optionally rerunning model fitting. Figure and table metrics are derived from stored CSVs; no reported number is a text-model estimate.

\begin{thebibliography}{3}\small
\bibitem{NASA} Brooks, T. F., Pope, D. S., and Marcolini, M. A. (1989). \emph{Airfoil Self-Noise and Prediction}. NASA Reference Publication 1218.
\bibitem{UCI} Brooks, T., Pope, D., and Marcolini, M. (1989). \emph{Airfoil Self-Noise} [dataset]. UCI Machine Learning Repository. DOI: \href{https://doi.org/10.24432/C5VW2C}{10.24432/C5VW2C}.
\bibitem{Redonnet} Redonnet, S., Bose, T., Seth, A., and Li, L. K. B. (2024). Airfoil self-noise prediction using deep neural networks. \emph{Engineering Analysis with Boundary Elements}, 159, 180--191. DOI: \href{https://doi.org/10.1016/j.enganabound.2023.11.024}{10.1016/j.enganabound.2023.11.024}.
\end{thebibliography}
\end{document}
'''
tex=tex.replace('__TABLE_SUMMARY__','\n'.join(rows)).replace('__TABLE_RULE__','\n'.join(perlines)).replace('__TABLE_INTERVAL__','\n'.join(intlines))
texpath=DOC/'57_H3_Airfoil_R12_Scientific_Results_and_Reproducibility.tex';texpath.write_text(tex)
for run in range(2):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','-output-directory',str(DOC),str(texpath)],cwd=ROOT,capture_output=True,text=True)
    if p.returncode!=0:
        print(p.stdout[-9000:]); print(p.stderr[-3000:]);raise RuntimeError('Latex compilation failed')
print('COMPILED',DOC/(texpath.stem+'.pdf'),'sha256',hashlib.sha256((DOC/(texpath.stem+'.pdf')).read_bytes()).hexdigest())
