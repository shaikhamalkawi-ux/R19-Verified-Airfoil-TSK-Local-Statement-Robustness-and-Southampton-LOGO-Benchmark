#!/usr/bin/env python3
"""Reproduce from the exact source ZIP supplied separately by the data repository."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--source-zip',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--workers',type=int,default=4);a=p.parse_args();root=Path(__file__).resolve().parent
m=json.loads((root/'SOURCE_PROVENANCE.json').read_text());b=a.source_zip.read_bytes();assert len(b)==m['archive_bytes'] and hashlib.sha256(b).hexdigest()==m['archive_sha256'],'Source identity differs; review provenance before proceeding.'
w=a.work.resolve();w.mkdir(parents=True,exist_ok=False);raw=w/'raw';raw.mkdir();out=w/'results'
with zipfile.ZipFile(a.source_zip) as z:
    assert z.testzip() is None
    assert all(not n.startswith(('/', '\\')) and '..' not in PurePosixPath(n).parts for n in z.namelist())
    z.extractall(raw)
for script,args in [('run.py',['--raw',str(raw),'--out',str(out),'--workers',str(a.workers)]),('verify.py',['--raw',str(raw),'--results',str(out)]),('check_expected.py',['--results',str(out)])]:
    subprocess.run([sys.executable,str(root/script),*args],check=True)
