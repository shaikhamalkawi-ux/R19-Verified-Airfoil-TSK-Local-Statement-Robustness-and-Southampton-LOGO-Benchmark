"""Independent R12 audit, CSV summary, paired fixed-OOF group ranges. No fitting.
Reconstructed from R12 per-fold exports alone, excludes incomplete rule-count panels.
"""
from pathlib import Path
import numpy as np,pandas as pd,json,hashlib,collections,math
from sklearn.model_selection import GroupKFold
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv'
RSET=[2,4,6,8,10,12]
REPS=['F5_LOG_F','F5_LOG_ST_DELTA','F5_LOG_K']
PDIR=ROOT/'results'/'per_fold'
res=ROOT/'results';qa=ROOT/'qa';qa.mkdir(exist_ok=True)
checks=[]
def ck(label,cond,info=None):
    checks.append({'name':label,'pass':bool(cond),'detail':info});
    if not cond:print('FAIL',label,info)
D=pd.read_csv(DATA).sort_values('row_id').reset_index(drop=True)
y=D.scaled_SPL_dB.to_numpy(); g=D.group_id.to_numpy(str)
orig_num=D[['frequency_Hz','angle_deg','chord_m','velocity_m_s','displacement_m']].to_numpy()
ck('source_1503_106',len(D)==1503 and len(set(g))==106)
ck('source_ids_1_to_1503',np.array_equal(np.sort(D.row_id),np.arange(1,1504)))
ck('inputs_all_positive_for_log',bool((D[['frequency_Hz','chord_m','velocity_m_s','displacement_m']]>0).all().all()))
# R12 representations are bijective given retained original U,chord,delta in X
f=D.frequency_Hz.to_numpy(float);U=D.velocity_m_s.to_numpy(float);c=D.chord_m.to_numpy(float);delta=D.displacement_m.to_numpy(float)
xlog=np.log10(f)
ck('logStdelta_inverse',np.max(np.abs(np.log10(f*delta/U)+np.log10(U)-np.log10(delta)-xlog))<1e-12)
ck('logK_inverse',np.max(np.abs(np.log10(np.pi*f*c/U)+np.log10(U)-np.log10(c)-np.log10(np.pi)-xlog))<1e-12)
outer=list(GroupKFold(10).split(orig_num,y,g))
models={};selected_rows=[];candrows=[];outrows=[];oofrows=[];traces=[];unusable=[]
for rep in REPS:
    for fold,(tr,te) in enumerate(outer):
        stem=f'{rep}_fold{fold:02d}'
        ftrace=PDIR/(stem+'_trace.json')
        ck('trace_file:'+stem,ftrace.is_file())
        if not ftrace.exists():continue
        t=json.loads(ftrace.read_text());traces.append(t)
        ck('source_hash:'+stem,t.get('input_sha256')==hashlib.sha256(DATA.read_bytes()).hexdigest())
        ck('outer_group_separation:'+stem,not(set(g[tr]) & set(g[te])) and set(g[tr])==set(t['outer_train_group_ids']) and set(g[te])==set(t['outer_test_group_ids']))
        cand=pd.read_csv(PDIR/(stem+'_candidates.csv'));opts=pd.read_csv(PDIR/(stem+'_outer_R.csv'));oof=pd.read_csv(PDIR/(stem+'_oof.csv'))
        candrows.append(cand);outrows.append(opts);oofrows.append(oof)
        ck('candidate_grid:'+stem,len(cand)==6*3*5 and len(cand.drop_duplicates(['R','h','lambda']))==90)
        ck('full_test_folds:'+stem,opts.test_groups.ge(1).all() and opts.train_groups.add(opts.test_groups).eq(106).all())
        ck('all_test_row_ids_per_R:'+stem,all(set(oof[oof.R==R].row_id)==set(D.row_id.iloc[te]) for R in opts.R))
        ck('target_truth_consistency:'+stem,np.max(np.abs(oof.actual_SPL_dB.to_numpy()-D.set_index('row_id').scaled_SPL_dB.loc[oof.row_id].to_numpy()))<1e-9)
        ck('all_selected_only_valid:'+stem,all(R in set(opts.R) for R in t['selected'].values()))
        # crosscheck each R choice is minimum inner (h,lam) among VALID candidates; absent R8 fold2 is allowed
        for z in t['R_choices']:
            R=z['R']; v=cand[(cand.R==R)&(cand.status=='VALID')]
            this=v[(abs(v.h-z['h'])<1e-12)&(abs(v['lambda']-z['lambda'])<1e-12)]
            ck(f'inner_rule_choice:{stem}:R{R}',len(this)==1 and np.isclose(this.inner_Egrp_RMSE_dB.iloc[0],v.inner_Egrp_RMSE_dB.min(),atol=1e-12))
            pred=oof[oof.R==R]
            err=float(np.sqrt(np.mean(pred.assign(sq=(pred.pred_SPL_dB-pred.actual_SPL_dB)**2).groupby('group_id').sq.mean())))
            raw=opts[opts.R==R].iloc[0]
            ck(f'outer_R_recompute:{stem}:R{R}',abs(err-raw.outer_fold_Egrp_RMSE_dB)<1e-8)
        best=min(t['R_choices'],key=lambda d:(d['inner_Egrp_RMSE_dB'],d['R']))
        threshold=best['inner_Egrp_RMSE_dB']+best['inner_fold_RMSE_SE_dB']
        oneSE=min([z for z in t['R_choices'] if z['inner_Egrp_RMSE_dB']<=threshold+1e-12],key=lambda z:(z['R'],z['inner_Egrp_RMSE_dB']))
        ck('selection_from_inner_only:'+stem,best['R']==t['selected']['MIN_ERROR'] and oneSE['R']==t['selected']['ONE_SE'] and abs(threshold-t['one_SE_cutoff_inner_RMSE_dB'])<1e-10)
        for policy,R in t['selected'].items():
            chosen=opts[opts.R==R].iloc[0]
            p=oof[oof.R==R].copy()
            p.insert(1,'policy',policy);p['R_selected']=R; p['h_selected']=float(chosen.h);p['lambda_selected']=float(chosen['lambda'])
            models.setdefault((rep,policy),[]).append(p)
            selected_rows.append({'representation':rep,'policy':policy,'outer_fold':fold,'R':R,
                                  'h':float(chosen.h),'lambda':float(chosen['lambda']),
                                  'inner_Egrp_RMSE_dB':float(chosen.inner_Egrp_RMSE_dB),
                                  'outer_fold_Egrp_RMSE_dB':float(chosen.outer_fold_Egrp_RMSE_dB),
                                  'test_groups':int(chosen.test_groups),'test_rows':int(chosen.test_rows)})
        if len(opts)!=6:unusable.append({'rep':rep,'fold':fold,'available_R':opts.R.tolist(),'failed_R':sorted(set(RSET)-set(opts.R)),'diagnostics':t['failures']})

ALL_C=pd.concat(candrows,ignore_index=True);ALL_O=pd.concat(outrows,ignore_index=True);ALL_P=pd.concat(oofrows,ignore_index=True);ALL_S=pd.DataFrame(selected_rows)
ALL_C.to_csv(res/'R12_ALL_INNER_TUNING_CANDIDATES.csv',index=False)
ALL_O.to_csv(res/'R12_OUTER_BY_R.csv',index=False)
ALL_P.to_csv(res/'R12_ALL_OOF_PREDICTIONS_BY_R.csv',index=False)
ALL_S.to_csv(res/'R12_PER_FOLD_SELECTED_POLICIES.csv',index=False)
ck('all_30_outer_pipelines',len(traces)==30)
ck('all_2700_inner_grid_rows',len(ALL_C)==2700)
ck('expected_inner_failed_R8',len(unusable)==1 and unusable[0]['rep']=='F5_LOG_ST_DELTA' and unusable[0]['fold']==2 and unusable[0]['failed_R']==[8])
ck('all_30_selected_policies_complete',len(ALL_S)==60 and ALL_S.groupby(['representation','policy']).size().eq(10).all())
run_status=[]
for rep in REPS:
    for f in range(10):
        rec=next(x for x in traces if x['representation']==rep and x['fold']==f)
        run_status.append({'rep':rep,'fold':f,'inner_fcm_failures':len([z for z in rec['failures'] if z['reason']=='all fcm restarts failed']),
            'missing_R':sorted(set(RSET)-set(int(z['R']) for z in rec['R_choices'])),'time_s':rec['duration_seconds']})
for rep in REPS:
    for policy in ('ONE_SE','MIN_ERROR'):
        p=pd.concat(models[(rep,policy)],ignore_index=True).sort_values('row_id')
        ck('selection_OOF_once:'+rep+policy,len(p)==1503 and p.row_id.is_unique and p.group_id.nunique()==106)
        ck('selection_OOF_group_true:'+rep+policy,np.array_equal(p.actual_SPL_dB.to_numpy(),D.sort_values('row_id').scaled_SPL_dB.to_numpy()))
        p.to_csv(res/f'R12_OOF_{rep}_{policy}.csv',index=False)

summary=[]
for rep in REPS:
    for pol in ('ONE_SE','MIN_ERROR'):
        p=pd.concat(models[(rep,pol)],ignore_index=True)
        gg=p.groupby('group_id').apply(lambda z:float(np.mean((z.actual_SPL_dB-z.pred_SPL_dB)**2)),include_groups=False)
        row_RMSE=np.sqrt(np.mean((p.actual_SPL_dB-p.pred_SPL_dB)**2))
        summary.append({'representation':rep,'selection_policy':pol,'outer_folds':10,'heldout_groups':len(gg),
                        'equal_group_RMSE_dB':float(np.sqrt(gg.mean())),'row_RMSE_dB':float(row_RMSE),
                        'R_count_distribution':','.join(f'{int(r)}:{int(count)}' for r,count in sorted(collections.Counter(ALL_S[(ALL_S.representation==rep)&(ALL_S.policy==pol)].R).items())),
                        'h_distribution':','.join(f'{h}:{ct}' for h,ct in sorted(collections.Counter(ALL_S[(ALL_S.representation==rep)&(ALL_S.policy==pol)].h).items())),
                        'lambda_distribution':','.join(f'{lm}:{ct}' for lm,ct in sorted(collections.Counter(ALL_S[(ALL_S.representation==rep)&(ALL_S.policy==pol)]['lambda']).items()))})
summaryD=pd.DataFrame(summary);summaryD.to_csv(res/'R12_NESTED_REPRESENTATION_SUMMARY.csv',index=False)
perR=[]
for rep in REPS:
    for R in RSET:
        p=ALL_P[(ALL_P.representation==rep)&(ALL_P.R==R)]
        gcounts=p.groupby('group_id').size()
        complete=len(p)==1503 and len(gcounts)==106 and gcounts.eq(D.groupby('group_id').size()).all()
        metric=(np.sqrt(p.assign(sq=(p.actual_SPL_dB-p.pred_SPL_dB)**2).groupby('group_id').sq.mean().mean()) if complete else float('nan'))
        perR.append({'representation':rep,'R':R,'outer_folds_completed':int((ALL_O.representation.eq(rep)&ALL_O.R.eq(R)).sum()),
                      'heldout_groups':len(gcounts),'complete_all_106':bool(complete),'equal_group_RMSE_dB':float(metric) if complete else None,
                      'median_selected_h':float(ALL_O[(ALL_O.representation==rep)&(ALL_O.R==R)].h.median()),
                      'median_selected_lambda':float(ALL_O[(ALL_O.representation==rep)&(ALL_O.R==R)]['lambda'].median())})
pd.DataFrame(perR).to_csv(res/'R12_TUNED_RULE_COUNT_SUMMARY.csv',index=False)

# Fixed-out-of-fold whole-configuration reweighting; do not infer new independent campaigns.
rng=np.random.default_rng(12021010)
contrasts=[]
for policy in ('ONE_SE','MIN_ERROR'):
    base=pd.concat(models[('F5_LOG_F',policy)],ignore_index=True)
    def groupsq(p):return p.assign(sq=(p.actual_SPL_dB-p.pred_SPL_dB)**2).groupby('group_id').sq.mean().sort_index()
    base_sq=groupsq(base)
    for alt in ['F5_LOG_ST_DELTA','F5_LOG_K']:
        z=pd.concat(models[(alt,policy)],ignore_index=True)
        alt_sq=groupsq(z)
        ck('pair_106_alignment:'+policy+alt,list(alt_sq.index)==list(base_sq.index))
        a=alt_sq.to_numpy();b=base_sq.to_numpy()
        ind=rng.integers(0,106,size=(5000,106))
        diff=np.sqrt(a[ind].mean(axis=1))-np.sqrt(b[ind].mean(axis=1))
        contrasts.append({'policy':policy,'alternative_representation':alt,'reference':'F5_LOG_F',
                          'RMSE_difference_alt_minus_ref_dB':float(np.sqrt(a.mean())-np.sqrt(b.mean())),
                          'conditional_fixed_OOF_p2p5':float(np.quantile(diff,.025)),
                          'conditional_fixed_OOF_p97p5':float(np.quantile(diff,.975)),
                          'groups_alt_lower_MSE':int((a<b).sum()),
                          'outer_folds_alt_lower_RMSE':int(sum(ALL_S[(ALL_S.representation==alt)&(ALL_S.policy==policy)].sort_values('outer_fold').outer_fold_Egrp_RMSE_dB.to_numpy()
                                                              <ALL_S[(ALL_S.representation=='F5_LOG_F')&(ALL_S.policy==policy)].sort_values('outer_fold').outer_fold_Egrp_RMSE_dB.to_numpy())),
                          'inference_boundary':'Reweighted fixed OOF losses; conditional descriptive intervals; no model refitting, no independent campaigns, no prospective selection claim'})
pd.DataFrame(contrasts).to_csv(res/'R12_FIXED_OOF_PAIRED_REPRESENTATION_CONTRASTS.csv',index=False)

full={'version':'R12','status':'AUDITED' if all(x['pass'] for x in checks) else 'FAILED',
      'gate_count':len(checks),'gate_passed':sum(x['pass'] for x in checks),'failures':[x for x in checks if not x['pass']],
      'attempted_inner_fcm':30*6*5,'failed_inner_fcm':sum(r['inner_fcm_failures'] for r in run_status),
      'successful_inner_fcm':30*6*5-sum(r['inner_fcm_failures'] for r in run_status),
      'planned_inner_candidates':2700,'invalid_inner_candidates':int((ALL_C.status!='VALID').sum()),
      'attempted_outer_fits':30*6,'successful_outer_fits':len(ALL_O),'incomplete_rules':unusable,
      'source_SHA256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
      'report_summary':summary,'per_R':perR,'contrasts':contrasts,
      'scientific_boundary':['R12 prospective only relative to the already inspected R10/R11 pilot, not externally preregistered',
         'CV selection is within each outer training fold; same holdouts as R9/R10/R11, not independent',
         'F5 representations are bijective, information-identical given retained features, but distance geometry changes',
         'FCM candidate failure logged and excluded from within-R selection; no silently imputed predictions',
         'One-SE uses inner five-fold error SE as a heuristic, not statistically calibrated',
         'No local matched-rule retraining performed in this predictive-audit module',
         'No R9 or R11 value updated or overwritten']}
(qa/'R12_INDEPENDENT_AGGREGATE_AUDIT.json').write_text(json.dumps(full,indent=2,allow_nan=False))
print('R12 GATES',full['gate_passed'],'/',full['gate_count'],'OK',full['status'])
print('INNER',full['successful_inner_fcm'],'/',full['attempted_inner_fcm'],'FITS, failures',full['failed_inner_fcm'],'candidate invalid',full['invalid_inner_candidates'])
print(summaryD.to_string(index=False))
print(pd.DataFrame(perR).to_string(index=False))
print(pd.DataFrame(contrasts).to_string(index=False))
if full['status']!='AUDITED':raise SystemExit(1)
