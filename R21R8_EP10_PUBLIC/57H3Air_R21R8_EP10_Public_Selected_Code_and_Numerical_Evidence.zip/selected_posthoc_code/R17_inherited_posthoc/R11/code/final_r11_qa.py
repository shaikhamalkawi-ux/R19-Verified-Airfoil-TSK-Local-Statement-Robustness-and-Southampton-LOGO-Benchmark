"""Release-level checksum/count/PDF bounds audit, independent of the core numerical solvers."""
from pathlib import Path
import fitz,hashlib,json,zipfile
r=Path(__file__).resolve().parents[1]
pdf=r/'docs/57_H3_Airfoil_R11_Scientific_Results_and_QA.pdf'
d=fitz.open(pdf)
pages=[]
for i,page in enumerate(d):
 text=page.get_text()
 spans=[(sp.get('text',''),sp['bbox']) for b in page.get_text('dict')['blocks'] if b.get('type')==0 for line in b.get('lines',[]) for sp in line.get('spans',[])]
 bad=[t for t,(x0,y0,x1,y1) in spans if not(-0.5<=x0<=page.rect.width+0.5 and -0.5<=x1<=page.rect.width+0.5 and -0.5<=y0<=page.rect.height+0.5 and -0.5<=y1<=page.rect.height+0.5)]
 pages.append({'page':i+1,'text_chars':len(text),'text_spans':len(spans),'out_of_page_text_spans':len(bad),'images':len(page.get_images())})
with zipfile.ZipFile(r/'input/R10_SOURCE_ARCHIVE_UNCHANGED.zip') as z:
 prefix='57_H3_Airfoil_R10_Exploratory_QAClosure/'
 manifest=z.read(prefix+'R10_SHA256SUMS.txt').decode().splitlines()
 count=sum(hashlib.sha256(z.read(prefix+line.split('  ',1)[1])).hexdigest()==line.split('  ',1)[0] for line in manifest)
 zip_crc_error=z.testzip()
 sha=hashlib.sha256((r/'input/R10_SOURCE_ARCHIVE_UNCHANGED.zip').read_bytes()).hexdigest()
source=json.loads((r/'input/R10_FROZEN_SOURCE/COPIED_SOURCE_SHA256.json').read_text())
core=json.loads((r/'qa/R11_INDEPENDENT_RECORD_AUDIT.json').read_text())
lam=json.loads((r/'qa/R11_LAMBDA_INDEPENDENT_AUDIT.json').read_text())
r9_sha=hashlib.sha256((r/'input/R9_EDITORIALLY_CORRECTED_READ_ONLY.pdf').read_bytes()).hexdigest()
failed_core=sum(row['bootstrap_failures'] for row in core['specification_results']);attempted_core=sum(row['bootstrap_attempts'] for row in core['specification_results'])
failed_lam=lam['summary'][0]['failed_FCM'];attempted_lam=lam['summary'][0]['bootstrap_attempts']
out={'project':'57 H3 Airfoil','version':'R11','date':'2026-10-10','r9_pdf_sha256':r9_sha,
 'r9_source_unchanged':r9_sha=='0a9669801ad6379fa1cf1a3f3b143bb56121f53e5b517fe9e2f6abdde8975ad5',
 'r10_source_zip_sha256':sha,'r10_original_zip_crc_error':zip_crc_error,
 'r10_original_manifest_entries':len(manifest),'r10_original_manifest_pass':count,
 'r10_source_subset_count':len(source),'r10_subset_byte_parity':sum(x['unchanged'] for x in source),
 'r10_math_qa_pass_22':('R10 QA: 22 / 22 PASS' in (r/'qa/R10_22_QA_FRESH_REPLAY.log').read_text()),
 'r11_record_gate_pass':core['validation_pass'],'r11_record_gate_total':core['validation_gates'],
 'r11_lambda_gate_pass':lam['passed'],'r11_lambda_gate_total':lam['checks'],
 'main_attempts':attempted_core,'main_success':attempted_core-failed_core,'main_failures':failed_core,
 'lambda_shared_attempts':attempted_lam,'lambda_shared_success':attempted_lam-failed_lam,'lambda_shared_failures':failed_lam,
 'total_shared_attempts':attempted_core+attempted_lam,'total_shared_success':attempted_core+attempted_lam-failed_core-failed_lam,
 'manuscript_science_changed':False,
 'PDF_pages':len(d),'PDF_page_checks':pages,
 'PDF_text_bounds_pass':all(x['out_of_page_text_spans']==0 for x in pages),
 'PDF_has_selectable_text':all(x['text_chars']>600 for x in pages),
 'font_check_policy':'DejaVu TrueType embedded/subset; reportlab default Helvetica Base14 resource appears but no Type3; internal evidence note, not a final journal submission PDF.',
 'external_airfoil_validation':False,'grouped_inner_re_tuning_per_R':False,'overall_pass':None}
out['overall_pass']=all([out['r9_source_unchanged'],zip_crc_error is None,count==len(manifest),len(source)==out['r10_subset_byte_parity'],out['r10_math_qa_pass_22'],core['validation_pass']==core['validation_gates'],lam['passed']==lam['checks'],len(d)==4,out['PDF_text_bounds_pass'],out['PDF_has_selectable_text'],out['total_shared_attempts']==14000,out['total_shared_success']==13999])
(r/'qa/R11_FINAL_RELEASE_AUDIT.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:out[k] for k in ['overall_pass','r10_original_manifest_pass','r10_source_subset_count','r11_record_gate_pass','r11_lambda_gate_pass','total_shared_attempts','total_shared_success','main_failures','PDF_pages','PDF_text_bounds_pass']},indent=2))
if not out['overall_pass']:raise SystemExit(1)
