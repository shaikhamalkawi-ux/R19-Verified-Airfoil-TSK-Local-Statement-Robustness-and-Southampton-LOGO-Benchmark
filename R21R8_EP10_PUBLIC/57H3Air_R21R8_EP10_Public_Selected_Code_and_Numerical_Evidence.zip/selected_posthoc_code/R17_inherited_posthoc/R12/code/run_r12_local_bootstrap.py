"""R12 one-SE tuned model, matched-local-rule common-support bootstrap (B=200).

Each outer fold uses ONLY prior R12 five-fold inner-tuned h,lambda,R. Rule-pair
comparisons are conditional on success, J>=0.5, normalized activation>=0.1.
Group bootstrap draws are common by fold, replicate across representations.
This is a post-hoc sensitivity run; no unobserved physical mechanism claim.
"""
from __future__ import annotations
import sys,hashlib,time,json,argparse,traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'inputs'/'R10_FROZEN_CODE'))
import controlled_rule_study as original
from run_r12_nested import features,fit_with_h_lam
REPS=['F5_LOG_F','F5_LOG_ST_DELTA','F5_LOG_K']


def draw_configuration_bootstrap(g,tr,fold,rep):
    train_groups=g[tr];names=np.unique(train_groups)
    rng=np.random.default_rng(int.from_bytes(hashlib.sha256(f'R12-NESTED|{fold}|{rep}'.encode()).digest()[:8],'little'))
    idx=[np.flatnonzero(train_groups==name) for name in names]
    drawn=rng.integers(0,len(names),size=len(names))
    return tr[np.concatenate([idx[i] for i in drawn])]


def one(rep,fold,B):
    st=time.time();d=pd.read_csv(ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').sort_values('row_id').reset_index(drop=True)
    X=features(d,rep);y=d.scaled_SPL_dB.to_numpy();g=d.group_id.to_numpy(str)
    tr,te=list(GroupKFold(10).split(X,y,g))[fold]
    trc=json.loads((ROOT/'results'/'per_fold'/f'{rep}_fold{fold:02d}_trace.json').read_text())
    R=int(trc['selected']['ONE_SE']); hyper=next(v for v in trc['R_choices'] if int(v['R'])==R)
    h=float(hyper['h']);lam=float(hyper['lambda'])
    parent,info=fit_with_h_lam(d,X,tr,R,h,lam)
    if parent is None:raise RuntimeError('PARENT FCM FAILED '+rep+str(fold))
    yp=original.infer(parent,X[te],X[te]);oof=pd.read_csv(ROOT/'results'/'per_fold'/f'{rep}_fold{fold:02d}_oof.csv')
    expect=oof[oof.R==R].sort_values('row_id')
    sortedrow=d.row_id.to_numpy()[te];inv=np.argsort(sortedrow)
    prediction_err=float(np.max(np.abs(yp[inv]-expect.pred_SPL_dB.to_numpy())))
    if prediction_err>1e-8:raise AssertionError('parent changed relative to frozen R12 OOF '+str(prediction_err))
    Wp=original.fire(parent['scante'].transform(X[tr]),parent['C'],parent['S'])
    flp=original.local_full_on_X(parent,X[tr]); gp=g[tr]
    replica_rows=[];pair_rows=[];failed=[]
    for b in range(B):
        ix=draw_configuration_bootstrap(g,tr,fold,b)
        boot,start=fit_with_h_lam(d,X,ix,R,h,lam)
        if boot is None:
            replica_rows.append({'representation':rep,'fold':fold,'draw':b,'R':R,'h':h,'lambda':lam,
                                 'success':False,'match_fraction':None,'matched_rules':0,'pairs_nonempty':0,'pairs_empty':0})
            failed.append({'rep':rep,'fold':fold,'draw':b,'reason':'FCM_ALL_FIVE_RESTARTS_NONCONVERGENT',
                           'FCM_restarts':start})
            continue
        Wb=original.fire(boot['scante'].transform(X[tr]),boot['C'],boot['S'])
        match,J=original.jaccard_assignment(Wp,Wb,gp,threshold=.5)
        flb=original.local_full_on_X(boot,X[tr])
        present=0;empty=0
        for parent_r,boot_r in enumerate(match):
            if boot_r<0:continue
            Pmask=Wp[:,parent_r]>=.1
            mask=Pmask&(Wb[:,boot_r]>=.1)
            if not mask.any():empty+=1;continue
            original_groups=np.unique(gp[Pmask]);ret=[]
            for group in original_groups:
                local=(gp==group)&Pmask
                ret.append(float(np.mean(mask[local])))
            D=original.common_D(flp[mask,parent_r],flb[mask,boot_r],gp[mask])
            Dp=original.common_D(flp[Pmask,parent_r],flb[Pmask,boot_r],gp[Pmask])
            pair_rows.append({'representation':rep,'fold':fold,'R':R,'h':h,'lambda':lam,'draw':b,
                              'parent_rule':int(parent_r),'matched_bootstrap_rule':int(boot_r),'J_weighted':float(J[parent_r,boot_r]),
                              'D_common_dB':float(D),'D_parent_dB':float(Dp),
                              'retained_equal_group_fraction':float(np.mean(ret)),
                              'retained_rows':int(mask.sum()),'retained_groups':int(len(np.unique(gp[mask]))),
                              'parent_support_rows':int(Pmask.sum()),'parent_support_groups':int(len(original_groups))})
            present+=1
        replica_rows.append({'representation':rep,'fold':fold,'draw':b,'R':R,'h':h,'lambda':lam,
                             'success':True,'match_fraction':float(np.mean(match>=0)),
                             'matched_rules':int((match>=0).sum()),'pairs_nonempty':present,'pairs_empty':empty})
    p=ROOT/'results'/'local_bootstrap_B200';p.mkdir(exist_ok=True,parents=True)
    stem=f'{rep}_fold{fold:02d}_B{B:03d}'
    pd.DataFrame(replica_rows).to_csv(p/f'{stem}_replicas.csv',index=False)
    pd.DataFrame(pair_rows).to_csv(p/f'{stem}_pairs.csv',index=False)
    r={ 'representation':rep,'fold':fold,'R':R,'h':h,'lambda':lam,'B_attempts':B,
        'B_success':sum(v['success'] for v in replica_rows),'B_failed':len(failed),
        'failed_register':failed,'parent_OOF_max_abs_error_dB':prediction_err,
        'matched_pairs':len(pair_rows),'empty_pairs':sum(v['pairs_empty'] for v in replica_rows),
        'median_pair_D_common_dB':float(np.median([v['D_common_dB'] for v in pair_rows])) if pair_rows else None,
        'mean_match_fraction':float(np.mean([v['match_fraction'] for v in replica_rows if v['success']])) if len(failed)<B else None,
        'median_pair_support_retention':float(np.median([v['retained_equal_group_fraction'] for v in pair_rows])) if pair_rows else None,
        'elapsed_s':time.time()-st}
    (p/f'{stem}_summary.json').write_text(json.dumps(r,indent=2,allow_nan=False))
    return {key:r[key] for key in ['representation','fold','R','h','lambda','B_success','B_failed','matched_pairs','median_pair_D_common_dB','mean_match_fraction','elapsed_s']}


def worker(job):
    with threadpool_limits(limits=1):return one(*job)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--workers',type=int,default=3);ap.add_argument('--bootstrap',type=int,default=200)
    ap.add_argument('--representations',nargs='+',default=REPS,choices=REPS)
    ap.add_argument('--folds',nargs='+',type=int,default=list(range(10)))
    args=ap.parse_args();jobs=[(rep,fold,args.bootstrap) for rep in args.representations for fold in args.folds]
    allres=[];errors=[];st=time.time()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        fu={pool.submit(worker,job):job for job in jobs}
        for v in as_completed(fu):
            try:r=v.result();allres.append(r);print('R12 B200 DONE',r,'elapsed overall',round(time.time()-st,1),'completed',len(allres),'/',len(jobs),flush=True)
            except Exception:
                errors.append({'task':fu[v],'traceback':traceback.format_exc()});print('R12 B200 FAIL',fu[v],traceback.format_exc(),flush=True)
    p=ROOT/'qa'/('R12_LOCAL_BOOTSTRAP_RUN_PARTIAL.json' if len(jobs)<30 else 'R12_LOCAL_BOOTSTRAP_RUN_STATUS.json')
    p.write_text(json.dumps({'jobs':jobs,'completed':allres,'errors':errors,'wall_s':time.time()-st},indent=2))
    if errors:raise RuntimeError('FAILED '+str(len(errors)))
if __name__=='__main__':main()
