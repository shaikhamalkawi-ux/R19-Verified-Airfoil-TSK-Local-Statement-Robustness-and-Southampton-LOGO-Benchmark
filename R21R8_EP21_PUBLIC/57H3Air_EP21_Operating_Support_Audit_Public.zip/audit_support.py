#!/usr/bin/env python3
"""R1-8 all-configuration support audit; fixed saved predictions, no refit.
Optional --oof validates and recomputes summaries from the exact pinned public R5 CSV.
"""
from pathlib import Path
import argparse, hashlib, json, zipfile, io
from fractions import Fraction
import numpy as np
import pandas as pd
from scipy.spatial import ConvexHull
from scipy.optimize import linprog
from scipy.special import logsumexp

ROOT=Path(__file__).resolve().parent
D_SHA='1d3433fe4fc65073b0cf858809dff9906db237dd6460b1e319e33fc2d98f1588'
OOF_BLOB='13969778bd29858f4117912e9dbf99ca16e6929a'
COLS=['angle_deg','chord_m','velocity_m_s']
SCALE=np.array([10,10000,10],dtype=np.int64)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git_blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def from_oof(path,d):
    b=Path(path).read_bytes(); assert git_blob(b)==OOF_BLOB and len(b)==1948267
    raw=pd.read_csv(path); assert len(raw)==30060
    raw=raw[(raw.feature_set=='F5')&(raw['mode']=='group')&(raw.representation=='log')&raw.model.isin(['TSK-Ridge-oneSE','extra_trees'])]
    assert len(raw)==3006 and not raw.duplicated(['model','row_id']).any()
    j=raw.merge(d[['row_id','group_id','scaled_SPL_dB']],on='row_id',validate='many_to_one',suffixes=('','_src'))
    assert len(j)==3006 and (j.group_id==j.group_id_src).all() and np.max(abs(j.y-j.scaled_SPL_dB))<=1e-10
    j['sq']=(j.y-j.pred)**2; j['ae']=abs(j.y-j.pred)
    a=j.groupby(['group_id','outer_fold','model']).agg(rows=('row_id','size'),mse=('sq','mean'),max_abs=('ae','max')).reset_index()
    t=a[a.model=='TSK-Ridge-oneSE'].drop(columns='model').rename(columns={'mse':'tsk_mse','max_abs':'tsk_max_abs'})
    e=a[a.model=='extra_trees'].drop(columns='model').rename(columns={'mse':'et_mse','max_abs':'et_max_abs'})
    return t.merge(e,on=['group_id','outer_fold','rows'],validate='one_to_one').rename(columns={'group_id':'group','outer_fold':'fold'})

def exact_weights(T,q,approx):
    # A basic feasible LP point has at most four positive weights.
    ids=np.flatnonzero(approx>1e-12); m=len(ids); assert 1<=m<=4
    arr=np.vstack([np.ones(m,dtype=np.int64),T[ids].T]); rhs=np.r_[1,q]
    mat=[[Fraction(int(x)) for x in row]+[Fraction(int(b))] for row,b in zip(arr,rhs)]
    r=0; piv=[]
    for c in range(m):
        i=next((i for i in range(r,4) if mat[i][c]),None)
        if i is None: continue
        mat[r],mat[i]=mat[i],mat[r]; den=mat[r][c];mat[r]=[x/den for x in mat[r]]
        for i in range(4):
            if i!=r:
                v=mat[i][c];mat[i]=[x-v*y for x,y in zip(mat[i],mat[r])]
        piv.append(c);r+=1
    assert r==m
    x=[Fraction(0)]*m
    for i,c in enumerate(piv):x[c]=mat[i][-1]
    assert all(v>=0 for v in x)
    assert all(sum(Fraction(int(v))*w for v,w in zip(row,x))==int(b) for row,b in zip(arr,rhs))
    return ids,x

def fnv64(b):
    h=0xcbf29ce484222325
    for c in b:h=((h^c)*0x100000001b3)&0xffffffffffffffff
    return f'{h:016x}'

def run(inputs,out,af3,oof=None):
    out.mkdir(parents=True,exist_ok=True)
    assert sha(Path(af3))==json.loads((ROOT/"SOURCE_AND_METHOD.json").read_text())["af3_sha256"]
    dp=inputs/'airfoil_F5_SEMANTICALLY_VERIFIED.csv'; assert sha(dp)==D_SHA
    d=pd.read_csv(dp); assert len(d)==1503 and d.group_id.nunique()==106 and np.array_equal(d.row_id,np.arange(1,1504))
    groups=d.groupby('group_id',sort=True)
    assert (groups[COLS].nunique()==1).all().all()
    group=groups[COLS].first(); assert len(group.drop_duplicates())==106
    lattice=np.rint(group.to_numpy()*SCALE).astype(np.int64)
    max_round=float(np.max(abs(group.to_numpy()-lattice/SCALE)))
    assert max_round<=1e-12
    canonical=pd.DataFrame(lattice,index=group.index,columns=COLS)
    assert fnv64((inputs/'public_group_metrics.csv').read_bytes())=='0f476627b3bf4d71'
    p=pd.read_csv(inputs/'public_group_metrics.csv'); assert len(p)==106 and p.group.nunique()==106
    if oof:
        c=from_oof(oof,d).sort_values('group').reset_index(drop=True)
        a=p.sort_values('group').reset_index(drop=True)
        assert (c[['group','fold','rows']]==a[['group','fold','rows']]).all().all()
        assert np.max(abs(c[['tsk_mse','et_mse','tsk_max_abs','et_max_abs']]-a[['tsk_mse','et_mse','tsk_max_abs','et_max_abs']]).to_numpy())<=1e-8
        p=c
    p=p.set_index('group').sort_index(); assert p.index.equals(group.index)
    X=d[['frequency_Hz','angle_deg','chord_m','velocity_m_s','displacement_m']].to_numpy();X[:,[0,4]]=np.log10(X[:,[0,4]])
    results=[]; certs=[]; all_test=[]; max_mse_err=0.; max_abs_err=0.; lp_resid=0.; qhull_max_error=0.
    for f in range(10):
        with zipfile.ZipFile(af3) as z:
            payload=z.read(f'inputs/states/AIRFOIL_ONESE_fold{f:02d}.npz')
        with np.load(io.BytesIO(payload),allow_pickle=False) as s:
            tr=s['tr']; te=s['te']; assert np.array_equal(np.sort(np.r_[tr,te]),np.arange(len(d)))
            all_test.extend(te.tolist()); gt=sorted(d.iloc[tr].group_id.unique()); ge=sorted(d.iloc[te].group_id.unique()); assert not set(gt)&set(ge) and set(gt)|set(ge)==set(group.index)
            assert set(p.index[p.fold==f])==set(ge)
            Z=(X[te]-s['mean'])/s['scale']; v=(Z[:,None,:]-s['C'][None,:,:])/s['S'][None,:,:]; loga=-0.5*np.sum(v*v,axis=2); W=np.exp(loga-logsumexp(loga,axis=1,keepdims=True)); Phi=np.einsum('nr,nj->nrj',W,np.column_stack([np.ones(len(te)),Z])).reshape(len(te),-1); assert np.max(abs(Phi-s['Pt']))<1e-9; pred=s['Pt']@s['beta']+s['offset']; assert np.max(abs(pred-(Phi@s['beta']+s['offset'])))<1e-8; assert np.max(abs(s['ytest']-d.iloc[te].scaled_SPL_dB))<1e-10; res=pred-d.iloc[te].scaled_SPL_dB.to_numpy()
            # Exact lattice facet verification; Qhull identifies the candidate simplices only.
            T=canonical.loc[gt].to_numpy(dtype=np.int64); assert np.linalg.matrix_rank(T-T.mean(axis=0))==3
            mean=T.mean(axis=0); std=T.std(axis=0); N=(T-mean)/std; hull=ConvexHull(N); facets=[]
            for face in hull.simplices:
                a,b,c=T[face]; n=np.cross(b-a,c-a); assert np.any(n)
                side=(T-a)@n
                if np.min(side)>=0: n=-n; side=-side
                assert np.max(side)==0 and np.min(side)<0
                facets.append((a,n,[gt[i] for i in face]))
            for g in ge:
                q=canonical.loc[g].to_numpy(dtype=np.int64); j=d.iloc[te].group_id.to_numpy()==g; r=res[j]; mse=float(np.mean(r*r)); ae=float(np.max(abs(r)))
                assert len(r)==int(p.loc[g,'rows']); max_mse_err=max(max_mse_err,abs(mse-p.loc[g,'tsk_mse']));max_abs_err=max(max_abs_err,abs(ae-p.loc[g,'tsk_max_abs']))
                out_axis=bool(np.any((q<T.min(0))|(q>T.max(0))))
                sides=np.array([int((q-a)@n) for a,n,_ in facets],dtype=np.int64); outside=bool(np.max(sides)>0)
                qp=(q-mean)/std; fvals=hull.equations[:,:3]@qp+hull.equations[:,3]; maxfacet=float(np.max(fvals)); assert bool(maxfacet>1e-9)==outside
                # Separate LP on barycentric representation, independent of the hull triangulation.
                lp=linprog(np.zeros(len(T)), A_eq=np.vstack([np.ones(len(T)),N.T]),b_eq=np.r_[1.,qp], bounds=(0,None),method='highs', options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
                assert lp.status in (0,2) and (lp.status==2)==outside,(g,lp.status,lp.message)
                if lp.status==0:
                    err=max(abs(lp.x.sum()-1),float(np.max(abs(lp.x@N-qp))),max(0.,float(-np.min(lp.x))))
                    assert err<1e-8;lp_resid=max(lp_resid,err)
                    ids,weights=exact_weights(T,q,lp.x)
                    cert={'group':g,'fold':f,'type':'exact_rational_convex_combination','training_group_weights':{gt[i]:str(w) for i,w in zip(ids,weights)},'normalized_reconstruction_error':err}
                else:
                    ix=int(np.argmax(sides));a,n,face=facets[ix];assert int((q-a)@n)>0 and int(np.max((T-a)@n))==0
                    cert={'group':g,'fold':f,'type':'exact_integer_separating_plane','lattice_scaling':SCALE.tolist(),'point_on_plane':a.tolist(),'normal':n.tolist(),'facet_training_groups':face,'heldout_signed_value':int((q-a)@n),'max_training_signed_value':int(np.max((T-a)@n))}
                certs.append(cert)
                results.append({'group':g,'fold':f,'rows':len(r),'training_groups':len(gt),**dict(zip(COLS,group.loc[g].tolist())),'outside_axis_range':out_axis,'outside_convex_hull':outside,'on_hull_boundary':not outside and int(np.max(sides))==0,'max_normalized_facet_value':maxfacet,'nearest_training_config_L2':float(np.min(np.linalg.norm(N-qp,axis=1))),'tsk_rmse':float(np.sqrt(mse)),'et_rmse':float(np.sqrt(p.loc[g,'et_mse'])),'tsk_max_abs':ae,'et_max_abs':float(p.loc[g,'et_max_abs'])})
    assert sorted(all_test)==list(range(1503)) and max_mse_err<1e-8 and max_abs_err<1e-8
    a=pd.DataFrame(results).sort_values('group').reset_index(drop=True);assert len(a)==106 and a.group.nunique()==106
    for met in ['tsk_rmse','et_rmse','tsk_max_abs','et_max_abs']:
        a[met+'_rank']=a[met].rank(method='min',ascending=False).astype(int)
    a.to_csv(out/'ALL106_SUPPORT_AND_ERROR.csv',index=False,float_format='%.12g')
    (out/'SUPPORT_CERTIFICATES.json').write_text(json.dumps(certs,indent=2)+'\n')
    summary={'observations':int(a.rows.sum()),'groups':len(a),'folds':10,'coordinate_roundtrip_max_abs_error':max_round,'range_outside':int(a.outside_axis_range.sum()),'joint_outside':int(a.outside_convex_hull.sum()),'joint_inside':int((~a.outside_convex_hull).sum()),'boundary_inside':int(a.on_hull_boundary.sum()),'joint_outside_within_marginal_ranges':int((a.outside_convex_hull&~a.outside_axis_range).sum()),'max_tsk_group_mse_diff_vs_public_predictions':max_mse_err,'max_tsk_group_maxabs_diff_vs_public_predictions':max_abs_err,'max_lp_feasible_reconstruction_error':lp_resid,'classifications_agree_106':True,'exact_rational_inside_certificates':int((~a.outside_convex_hull).sum()),'exact_integer_outside_certificates':int(a.outside_convex_hull.sum()),'af3_sha256':sha(Path(af3)),'public_summary_rounding_decimals':8,'public_summary_transfer_fnv64':fnv64((inputs/'public_group_metrics.csv').read_bytes()),'oof_full_source_replayed_locally':bool(oof),'scope':'Held-out configuration triples only; not full F5 input support, not causality or prospective risk prediction. Fixed stored predictions and parent states; post hoc; dependent outer folds.'}
    tops=[]
    for met in ['tsk_rmse','et_rmse','tsk_max_abs','et_max_abs']:
        b=a.sort_values([met,'group'],ascending=[False,True]);summary[met+'_largest']=b.iloc[0][['group','outside_convex_hull',met]].to_dict()
        for k in [5,10,20]:
            x=b.head(k);assert x.iloc[-1][met]>b.iloc[k][met],('tie at cutoff',met,k)
            tops.append({'metric':met,'top_k':k,'outside_hull':int(x.outside_convex_hull.sum()),'inside_hull':int((~x.outside_convex_hull).sum()),'outside_any_marginal':int(x.outside_axis_range.sum()),'groups':';'.join(x.group)})
        if met.endswith('rmse'):
            summary[met+'_equal_group_all']=float(np.sqrt(np.mean(a[met]**2)))
            for flag,name in [(False,'inside'),(True,'outside')]:
                s=a[a.outside_convex_hull==flag];summary[met+'_'+name]={'groups':len(s),'equal_group_rmse':float(np.sqrt(np.mean(s[met]**2))),'median_group_rmse':float(np.median(s[met])),'max_group_rmse':float(s[met].max())}
    pd.DataFrame(tops).to_csv(out/'TOP_K_SUPPORT_SUMMARY.csv',index=False)
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else x)+'\n')
    print(json.dumps(summary,indent=2,default=lambda x:x.item() if isinstance(x,np.generic) else x));print(pd.DataFrame(tops).to_string(index=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,default=ROOT/'inputs');p.add_argument('--out',type=Path,default=ROOT/'results');p.add_argument('--af3',type=Path,required=True);p.add_argument('--oof',type=Path);args=p.parse_args();run(args.inputs,args.out,args.af3,args.oof)
