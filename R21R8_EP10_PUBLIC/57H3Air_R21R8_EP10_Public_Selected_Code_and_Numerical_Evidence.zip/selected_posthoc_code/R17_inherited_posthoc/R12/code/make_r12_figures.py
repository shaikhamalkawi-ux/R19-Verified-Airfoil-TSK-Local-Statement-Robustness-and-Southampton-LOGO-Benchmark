"""R12 provenance-locked plots from audited CSVs (read-only)."""
from pathlib import Path
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['pdf.fonttype']=42
plt.rcParams['ps.fonttype']=42
root=Path(__file__).resolve().parents[1]
f=root/'figures';f.mkdir(exist_ok=True)
labels={'F5_LOG_F':'Original log frequency','F5_LOG_ST_DELTA':'Log Strouhal (displacement)','F5_LOG_K':'Log reduced frequency'}
rep=['F5_LOG_F','F5_LOG_ST_DELTA','F5_LOG_K']
per=pd.read_csv(root/'results'/'R12_TUNED_RULE_COUNT_SUMMARY.csv')
fig,ax=plt.subplots(figsize=(7.8,4.1))
for r in rep:
    dat=per[per.representation==r].sort_values('R')
    valid=dat[dat.complete_all_106]
    ax.plot(valid.R,valid.equal_group_RMSE_dB,marker='o',linewidth=1.5,label=labels[r])
ax.set_xticks([2,4,6,8,10,12]);ax.set_xlabel('Number of TSK rules (each R internally tuned)')
ax.set_ylabel('Outer equal-configuration RMSE (dB)')
ax.set_title('Tuned prediction error by rule count')
ax.legend(loc='upper right',fontsize=8);ax.grid(alpha=.22)
fig.tight_layout();fig.savefig(f/'R12_Tuned_RuleCount_RMSE.pdf');fig.savefig(f/'R12_Tuned_RuleCount_RMSE.png',dpi=170);plt.close(fig)

pred=pd.read_csv(root/'results'/'R12_NESTED_REPRESENTATION_SUMMARY.csv')
pol=['ONE_SE','MIN_ERROR'];X=np.arange(len(rep));width=.35
fig,ax=plt.subplots(figsize=(7.8,4.1))
for j,p in enumerate(pol):
    sub=pred[pred.selection_policy==p].set_index('representation').loc[rep]
    vals=sub.equal_group_RMSE_dB.to_numpy()
    rect=ax.bar(X+(j-.5)*width,vals,width,label=p.replace('_','-'))
    ax.bar_label(rect,fmt='%.3f',padding=3,fontsize=8)
ax.set_xticks(X,['Original log frequency','Log Strouhal','Log reduced frequency'])
ax.set_ylim(0,max(pred.equal_group_RMSE_dB)+1)
ax.set_ylabel('Outer equal-configuration RMSE (dB)')
ax.set_title('Fully nested prediction performance')
ax.legend();ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(f/'R12_Nested_Representation_RMSE.pdf');fig.savefig(f/'R12_Nested_Representation_RMSE.png',dpi=170);plt.close(fig)

localcsv=root/'results'/'R12_B200_LOCAL_SUMMARY.csv'
if localcsv.exists():
    loc=pd.read_csv(localcsv).set_index('representation').loc[rep]
    pp=pred[pred.selection_policy=='ONE_SE'].set_index('representation').loc[rep]
    fig,ax=plt.subplots(figsize=(7.8,4.1))
    for i,r in enumerate(rep):
        ax.scatter(pp.loc[r,'equal_group_RMSE_dB'],loc.loc[r,'median_of_fold_medians_D_common_dB'],s=75,
                   label=labels[r],marker=['o','s','^'][i])
    ax.set_xlabel('Outer equal-configuration RMSE (dB)')
    ax.set_ylabel('Conditional joint-support local disagreement (dB)')
    ax.set_title('Accuracy and local-rule reproducibility are separate endpoints')
    ax.legend(fontsize=8);ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(f/'R12_Accuracy_vs_Local_Disagreement.pdf');fig.savefig(f/'R12_Accuracy_vs_Local_Disagreement.png',dpi=170);plt.close(fig)
    fd=pd.read_csv(root/'results'/'R12_B200_LOCAL_FOLD_RESULTS.csv')
    baseline=fd[fd.representation=='F5_LOG_F'].sort_values('outer_fold')
    fig,ax=plt.subplots(figsize=(7.8,4.1))
    for r in rep[1:]:
        cur=fd[fd.representation==r].sort_values('outer_fold')
        v=cur.fold_median_D_common_dB.to_numpy()-baseline.fold_median_D_common_dB.to_numpy()
        ax.plot(np.arange(1,11),v,marker='o',linewidth=1.4,label=labels[r]+' minus original')
    ax.axhline(0,ls='--',linewidth=1)
    ax.set_xticks(range(1,11));ax.set_xlabel('Outer configuration fold')
    ax.set_ylabel('Difference in fold median local D (dB)')
    ax.set_title('Fold-level stability contrasts (conditional on matching)')
    ax.legend(fontsize=8);ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(f/'R12_Fold_Conditional_Differences.pdf');fig.savefig(f/'R12_Fold_Conditional_Differences.png',dpi=170);plt.close(fig)
print('R12 FIGURES',sorted(x.name for x in f.glob('*.pdf')))
