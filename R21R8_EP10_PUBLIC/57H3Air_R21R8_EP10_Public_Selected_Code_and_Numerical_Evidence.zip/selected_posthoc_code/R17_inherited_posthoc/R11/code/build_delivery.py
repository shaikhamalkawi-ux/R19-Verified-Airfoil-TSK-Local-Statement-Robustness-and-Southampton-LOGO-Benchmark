"""Deterministically package R11 result/data/code/QA without temporary caches or alternate renders."""
from pathlib import Path
import hashlib,zipfile,json
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT.parent

def selected(p):
 rel=p.relative_to(ROOT)
 if not p.is_file():return False
 if '__pycache__' in rel.parts:return False
 if rel.name.endswith('.pyc'):return False
 if rel.name in ['R11_SHA256SUMS.txt']:return False
 if 'frozen_r10_input' in rel.parts:return False
 if any(q.startswith('report_render') for q in rel.parts):return False
 if rel.name.endswith('_PID.txt'):return False
 return True

# Explicit contact sheet is a visual QA evidence file; unused interim renders are excluded.
contact=ROOT/'qa/report_render_final/CONTACT_FINAL.jpg'
if contact.exists():
 (ROOT/'qa/R11_PDF_VISUAL_CONTACT_SHEET.jpg').write_bytes(contact.read_bytes())
allfiles=sorted((p for p in ROOT.rglob('*') if selected(p)),key=lambda p:str(p.relative_to(ROOT)))

# Canonical root manifest excludes itself but includes every member of the full ZIP.
manifest=''.join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n" for p in allfiles)
(ROOT/'R11_SHA256SUMS.txt').write_text(manifest)
allfiles.append(ROOT/'R11_SHA256SUMS.txt')


full=DEST/'57_H3_Airfoil_R11_TargetedFollowup_FULL_PACKAGE_20261010.zip'
reader=DEST/'57_H3_Airfoil_R11_ReaderReview_20261010.zip'
reader_rel=['README_FIRST.md',
 'docs/57_H3_Airfoil_R11_Scientific_Results_and_QA.pdf','docs/R11_SCIENTIFIC_DECISION_AR.md',
 'docs/R11_JOURNAL_SUPPLEMENT_CANDIDATE_NOT_ADMITTED.md','docs/R11_NEW_CHAT_HANDOFF.md',
 'figures/R11_Accuracy_vs_Conditional_D.png','figures/R11_Fold_Paired_B_minus_A.png',
 'figures/R11_Ridge_Collapse_Tradeoff.png','results/R11_B200_SUMMARY.csv',
 'results/R11_B200_RIDGE_SUMMARY.csv','results/R11_FIXED_OOF_PAIRED_CONTRASTS.csv',
 'qa/R11_FINAL_RELEASE_AUDIT.json']
readerfiles=[ROOT/p for p in reader_rel]
assert all(p.is_file() for p in readerfiles)
# Helper writer using fixed zip metadata; manifest verification immediately after creation.
def do_pack(path,bname,paths,readermanifest=False):
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
  for p in sorted(paths,key=lambda p:p.relative_to(ROOT).as_posix()):
   zi=zipfile.ZipInfo(bname+'/'+p.relative_to(ROOT).as_posix(),date_time=(2026,10,10,12,0,0))
   zi.external_attr=0o644<<16;zi.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
  if readermanifest:
   text=''.join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n" for p in sorted(paths,key=lambda p:p.relative_to(ROOT).as_posix()))
   zi=zipfile.ZipInfo(bname+'/READER_SHA256SUMS.txt',date_time=(2026,10,10,12,0,0));zi.external_attr=0o644<<16;zi.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(zi,text)
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  check=z.read(bname+'/READER_SHA256SUMS.txt' if readermanifest else bname+'/R11_SHA256SUMS.txt').decode().splitlines()
  failures=[]
  for line in check:
   hexdigest,rel=line.split('  ',1)
   if hashlib.sha256(z.read(bname+'/'+rel)).hexdigest()!=hexdigest:failures.append(rel)
  assert not failures,failures
 return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'members':len(z.namelist()),'manifest_checks':len(check),'manifest_passed':len(check),'bytes':path.stat().st_size,'zip_crc':'PASS'}

r1=do_pack(full,'57_H3_Airfoil_R11_TargetedFollowup',allfiles)
r2=do_pack(reader,'57_H3_Airfoil_R11_ReaderReview',readerfiles,readermanifest=True)
print(json.dumps({'full':r1,'reader':r2},indent=2))
(DEST/'57_H3_Airfoil_R11_DELIVERY_SHA256_20261010.json').write_text(json.dumps({'full':r1,'reader':r2},indent=2))
