"""Resume only missing R12 B200 runs, preserving already completed per-fold outputs."""
import os,sys,time,json,traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from run_r12_local_bootstrap import ROOT,REPS,worker
out=ROOT/'results'/'local_bootstrap_B200';out.mkdir(exist_ok=True,parents=True)
alljobs=[(rep,fold,200) for rep in REPS for fold in range(10)]
jobs=[z for z in alljobs if not (out/f'{z[0]}_fold{z[1]:02d}_B200_summary.json').exists()]
print('R12 RESUMING',len(jobs),'of',len(alljobs),'tasks',flush=True)
st=time.time();completed=[];errs=[]
with ProcessPoolExecutor(max_workers=4) as pool:
    d={pool.submit(worker,z):z for z in jobs}
    for f in as_completed(d):
        try:
            r=f.result();completed.append(r)
            print('DONE',len(completed),'/',len(jobs),r['representation'],r['fold'],'R',r['R'],
                  'B_SUCCESS',r['B_success'],'B_FAILED',r['B_failed'],'SECONDS',round(r['elapsed_s'],1),'ELAPSED',round(time.time()-st,1),flush=True)
        except Exception:
            error={'task':d[f],'error':traceback.format_exc()};errs.append(error);print('ERROR',error,flush=True)
allpresent=[(z[0],z[1]) for z in alljobs if (out/f'{z[0]}_fold{z[1]:02d}_B200_summary.json').exists()]
status={'all_tasks':len(alljobs),'finished':len(allpresent),'completed_this_run':len(completed),'errors':errs,'elapsed_s':time.time()-st}
(ROOT/'qa'/'R12_LOCAL_BOOTSTRAP_B200_STATUS.json').write_text(json.dumps(status,indent=2))
print('R12 LOCAL FINAL',status,flush=True)
if errs or len(allpresent)!=30:sys.exit(1)
