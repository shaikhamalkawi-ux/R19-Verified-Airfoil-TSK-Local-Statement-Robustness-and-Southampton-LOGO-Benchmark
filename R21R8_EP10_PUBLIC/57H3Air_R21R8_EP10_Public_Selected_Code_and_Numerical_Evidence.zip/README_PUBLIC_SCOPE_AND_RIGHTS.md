# Public research artefact: Project 57 H3Air R21R8-EP10

This is the prepublication author-review research archive, NOT an accepted IEEE Access paper.

Project title: Beyond Prediction Accuracy: Local-Slope Robustness in Takagi–Sugeno Fuzzy Models of Airfoil Self-Noise

Attribution: Ghassan Malkawi; Hussien Alwedyan; Ahmed Elsayed; Abdulwehab A. Ibrahim; Ashraf AlShalalfeh; Rafiq Manna.

Public access has been requested by the manuscript authors' representative. No standalone software-reuse licence is granted in this ZIP; contributors must approve the eventual software licence. No third-party publisher PDFs, private reviewer comments, credentials, or Bristol original HDF5 measurements are in this archive. Source datasets remain attributed at https://doi.org/10.24432/C5VW2C, https://doi.org/10.24432/C5PK67 and https://doi.org/10.5258/SOTON/398169. For official Bristol acoustic observations see https://doi.org/10.5523/bris.30c8q39wi1mxf205flnun3l5rl (noncommercial source terms).

No published Zenodo DOI is asserted. Do not mistake the newly reconstructed 27,998 fitted states for recovered byte-identical original historical model states. Full 28,000-attempt replay archives are not in these selected ZIPs.

The source ZIP does not include third-party IEEE class files and logos; obtain the journal's current approved template from IEEE when recompiling.
