# Additional file 2 - executable code and scalar records

This archive supports the post hoc R11/R12 controls, the R15 statement-robustness calculations, and the R17 Southampton external-geometry methodological replication. It contains code and scalar/tabular records. Large fitted parent states and witness arrays are separated into Additional file 3.

The R17 external source is public Southampton data, DOI 10.5258/SOTON/398169, under Creative Commons Attribution; the exact admitted ZIP and source hash are included under `R17_EXTERNAL/source/`.

These materials do not replace the author-held primary NASA bootstrap training-state archive and do not imply independent physical replication.
