"""Decode lossless-to-source-numeric-precision F5 table transmitted from GitHub R9 pinned snapshot.

The original git CSV contains binary floating point formatting artifacts. The packed
record restores SPL to its recorded 0.001 dB precision and canonical group metadata;
this is NOT a byte-identical source archive. Confirm numerically against pinned GitHub
summary and checksum before admitting to experimental calculations.
"""
from pathlib import Path
import base64,hashlib
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
FREQUENCIES=[200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000]

def load():
    cfg=pd.read_csv(DATA/'group_configurations.csv')
    b64=''.join((DATA/'packed_rows_b64.txt').read_text().split())
    b=np.frombuffer(base64.b64decode(b64,validate=True),dtype=np.uint8).reshape(-1,4)
    assert b.shape == (1503,4)
    fidx=b[:,1]; gidx=b[:,0]
    assert fidx.max()<len(FREQUENCIES) and gidx.max()<len(cfg)
    group_idx=np.arange(len(cfg))
    assert cfg.group_id.tolist()==[f'G{i:03d}' for i in range(1,107)]
    spl=100+((b[:,2].astype(np.uint32)<<8)+b[:,3])/1000
    d=pd.DataFrame({'row_id':np.arange(1,len(b)+1),'frequency_Hz':np.array(FREQUENCIES)[fidx],
                    'group_id':cfg.group_id.to_numpy()[gidx], 'scaled_SPL_dB':spl})
    d=d.merge(cfg,how='left',on='group_id',validate='many_to_one',sort=False)
    d=d[['row_id','frequency_Hz','angle_deg','chord_m','velocity_m_s','displacement_m','scaled_SPL_dB','group_id']]
    assert len(d)==1503 and d.row_id.tolist()==list(range(1,1504))
    counts=d.groupby('group_id').size()
    assert counts.size==106 and counts.min()==8 and counts.max()==19
    assert d.scaled_SPL_dB.between(103,142).all()
    assert (d[['frequency_Hz','chord_m','velocity_m_s','displacement_m']]>0).all().all()
    assert d.groupby('group_id').frequency_Hz.nunique().equals(counts)
    assert d.iloc[0].frequency_Hz==800 and d.iloc[0].group_id=='G024' and abs(d.iloc[0].scaled_SPL_dB-126.201)<1e-10
    assert d.iloc[-1].frequency_Hz==6300 and d.iloc[-1].group_id=='G097' and abs(d.iloc[-1].scaled_SPL_dB-104.204)<1e-10
    return d

if __name__=='__main__':
    d=load(); path=DATA/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv'; d.to_csv(path,index=False,float_format='%.12g')
    print('WROTE',path,'rows',len(d),'groups',d.group_id.nunique(),'counts',d.groupby('group_id').size().agg(['min','max']).to_dict())
    print('COLSUMS', {k:float(d[k].sum()) for k in ['frequency_Hz','angle_deg','chord_m','velocity_m_s','displacement_m','scaled_SPL_dB']})
    print('COLSQSUMS', {k:float(np.square(d[k].to_numpy(float)).sum()) for k in ['frequency_Hz','angle_deg','chord_m','velocity_m_s','displacement_m','scaled_SPL_dB']})
    print('SHA256 reconstructed',hashlib.sha256(path.read_bytes()).hexdigest())
