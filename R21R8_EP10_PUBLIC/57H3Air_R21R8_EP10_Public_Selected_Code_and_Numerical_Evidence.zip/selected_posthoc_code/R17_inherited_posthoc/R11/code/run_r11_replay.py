"""R11 prospective extension of existing post-hoc R10 pilot, preserving frozen R9/R10 source.

This wrapper reuses unmodified R10 model code; it redirects all outputs into new R11
results, with predeclared B and task grid. Counts are clustered bootstrap ATTEMPTS.
Not an external preregistration or independent real-world validation.
"""
from __future__ import annotations
import os,sys,argparse,json,time,hashlib,traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed

OUT=Path(__file__).resolve().parents[1]
R10=Path(__file__).resolve().parents[1]/'input'/'R10_FROZEN_SOURCE'
R10_MODULE=R10/'code'/'controlled_rule_study.py'
TASKS=[(v,r,f) for (v,r) in [('A',10),('B',10),('C',10),('D',10),('D',6),('D',12)] for f in range(10)]

def worker(task):
    from threadpoolctl import threadpool_limits
    import importlib.util
    sys.path.insert(0,str(R10/'code'))
    import controlled_rule_study as r10
    from decode_derived_table import load
    r10.RESULTS=OUT/'results'/'replay_200'
    r10.RESULTS.mkdir(parents=True,exist_ok=True)
    v,R,f,B,overwrite=task
    with threadpool_limits(limits=1):
        rec=r10.run_one(load(),v,f,R,B,overwrite=overwrite)
    return {'variant':v,'R':R,'fold':f,'bootstrap_attempts':B,'elapsed_s':rec['elapsed_s'],
            'bootstrap_success':rec.get('bootstrap_success'),'bootstrap_failed':rec.get('bootstrap_failed'),
            'parent_fit_success':rec['parent_fit_success']}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--bootstrap',type=int,default=200)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--parity',action='store_true',help='R10 B30 one-fold replay for preflight')
    ap.add_argument('--overwrite',action='store_true')
    args=ap.parse_args()
    if args.parity:
        tasks=[('A',10,0,args.bootstrap,args.overwrite),('D',10,0,args.bootstrap,args.overwrite)]
    else:
        tasks=[(*x,args.bootstrap,args.overwrite) for x in TASKS]
    st=time.time();print('R11 TASKS',len(tasks),'B',args.bootstrap,'workers',args.workers,'mode','PARITY' if args.parity else 'FULL',flush=True)
    errors=[];results=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futs=[pool.submit(worker,task) for task in tasks]
        for future in as_completed(futs):
            try:
                z=future.result();results.append(z)
                print('COMPLETE',z['variant'],z['R'],z['fold'],'OK/FAIL',z['bootstrap_success'],z['bootstrap_failed'],'elapsed',round(z['elapsed_s'],1),'total',round(time.time()-st,1),'completed',len(results),'/',len(tasks),flush=True)
            except Exception:
                t=futs.index(future);errors.append({'task':tasks[t],'traceback':traceback.format_exc()});print('ERROR',tasks[t],traceback.format_exc(),flush=True)
    (OUT/'qa'/('R11_B30_PARITY_WORKERS.json' if args.parity else 'R11_B200_RUN_STATUS.json')).write_text(json.dumps({'tasks_requested':tasks,'completed':results,'errors':errors,'runtime_s':time.time()-st,'R10_source_sha256':hashlib.sha256(R10_MODULE.read_bytes()).hexdigest()},indent=2))
    if errors:raise RuntimeError(f'{len(errors)} task failure(s)')
if __name__=='__main__':main()
