"""R10 exploratory, reproducible, *new* controlled TSK diagnostic (does not replace R9).

Factorial split between rule antecedent inputs (F4/F5) and consequent inputs (F4/F5),
held-out group folds, fixed R/h/lambda, matched whole-configuration bootstrapping.
Scientific claims are descriptive/conditional to declared settings; no causal physics.
"""
from __future__ import annotations
import argparse,hashlib,json,math,time,sys
from pathlib import Path
import numpy as np
import pandas as pd
import scipy.linalg
from scipy.special import logsumexp
from scipy.optimize import linear_sum_assignment
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits
from decode_derived_table import load

ROOT=Path(__file__).resolve().parents[1]; RESULTS=ROOT/'results';RESULTS.mkdir(exist_ok=True)
SEEDS=(11,23,47,71,101)
FIT_LAMBDA=0.01
H=1.0
MAX_ITER=2000
TOL=1e-6
FCM_WIDTH_FLOOR=.05
JACCARD=.5
ACTIVATION=.1
VARIANTS={'A':('F4','F4'),'B':('F4','F5'),'C':('F5','F4'),'D':('F5','F5')}

def feature(d,fs):
    cols=['frequency_Hz','angle_deg','chord_m','velocity_m_s']
    if fs=='F5':cols+=['displacement_m']
    X=d[cols].to_numpy(float).copy()
    X[:,0]=np.log10(X[:,0]);
    if fs=='F5':X[:,-1]=np.log10(X[:,-1])
    return X

def fcm(Z,R):
    n,p=Z.shape; z2=(Z*Z).sum(axis=1,keepdims=True)
    best=None;records=[]
    for seed in SEEDS:
        rng=np.random.default_rng(int(seed))
        U=rng.random((n,R))+1e-12;U/=U.sum(axis=1,keepdims=True)
        converged=False;delta=float('inf')
        for it in range(1,MAX_ITER+1):
            UM=U*U
            C=(UM.T@Z)/UM.sum(axis=0)[:,None]
            D=np.maximum(z2+(C*C).sum(axis=1)[None,:]-2*Z@C.T,1e-25)
            inv=1/D;newU=inv/inv.sum(axis=1,keepdims=True)
            delta=float(np.max(np.abs(newU-U)));U=newU
            if delta<TOL:converged=True;break
        UM=U*U;C=(UM.T@Z)/UM.sum(axis=0)[:,None]
        D=np.maximum(z2+(C*C).sum(axis=1)[None,:]-2*Z@C.T,0)
        obj=float(np.sum(UM*D))
        records.append({'seed':seed,'converged':converged,'iters':it,'objective':obj})
        if converged and (best is None or (obj,seed)<(best['obj'],best['seed'])):
            vari=((UM.T@(Z*Z))/UM.sum(0)[:,None])-C*C
            S=np.maximum(np.sqrt(np.maximum(vari,0)),FCM_WIDTH_FLOOR)*H
            best={'C':C,'S':S,'obj':obj,'seed':seed,'iters':it}
    return best,records

def fire(Z,C,S):
    delta=(Z[:,None,:]-C[None,:,:])/S[None,:,:]
    log_a=-0.5*np.sum(delta*delta,axis=2)
    return np.exp(log_a-logsumexp(log_a,axis=1,keepdims=True))

def design(Z,W):
    T=np.column_stack((np.ones(len(Z)),Z))
    return np.einsum('nr,nj->nrj',W,T).reshape(len(Z),-1)

def ridge_fit(P,y,lam=FIT_LAMBDA):
    n,q=P.shape
    A=np.vstack((P/np.sqrt(n),np.sqrt(lam)*np.eye(q)))
    v=np.r_[(y-y.mean())/np.sqrt(n),np.zeros(q)]
    return scipy.linalg.lstsq(A,v,lapack_driver='gelsd',check_finite=False)[0]

def training_model(Xante,Xcons,y,ix,R):
    Xa=Xante[ix];Xc=Xcons[ix];yy=y[ix]
    sa=StandardScaler().fit(Xa);sc=StandardScaler().fit(Xc)
    Za=sa.transform(Xa);Zc=sc.transform(Xc)
    fit,records=fcm(Za,R)
    if fit is None:return None,records
    W=fire(Za,fit['C'],fit['S'])
    P=design(Zc,W)
    beta=ridge_fit(P,yy)
    model={'scante':sa,'sccons':sc,'C':fit['C'],'S':fit['S'],'beta':beta,
           'targetmean':float(np.mean(yy)),'R':R,'fcmseed':fit['seed'],'fcmiters':fit['iters']}
    return model,records

def infer(model,Xa,Xc):
    W=fire(model['scante'].transform(Xa),model['C'],model['S'])
    return model['targetmean']+design(model['sccons'].transform(Xc),W)@model['beta']

def local_full_on_X(model,Xc):
    p=Xc.shape[1];Z=model['sccons'].transform(Xc)
    return model['targetmean']+(np.c_[np.ones(len(Z)),Z]@model['beta'].reshape(-1,p+1).T)

def group_rmse(y,yhat,g):
    d=(y-yhat)**2;unique,inv=np.unique(g,return_inverse=True)
    return float(np.sqrt(np.mean(np.bincount(inv,weights=d)/np.bincount(inv))))

def jaccard_assignment(Wp,Wb,g,threshold=JACCARD):
    _,inv=np.unique(g,return_inverse=True);weights=1/np.bincount(inv)[inv];weights=weights/weights.sum()
    R=Wp.shape[1]; sim=np.empty((R,R),float)
    for r in range(R):
        for s in range(R):
            a=Wp[:,r];b=Wb[:,s]
            sim[r,s]=np.sum(weights*np.minimum(a,b))/np.sum(weights*np.maximum(a,b))
    gain=np.column_stack((sim-threshold,np.zeros((R,R))))
    ii,jj=linear_sum_assignment(-gain)
    out=np.full(R,-1,dtype=int)
    for a,b in zip(ii,jj):
        if b<R and sim[a,b]>=threshold:out[a]=b
    return out,sim

def common_D(a,b,g):
    unique,inv=np.unique(g,return_inverse=True)
    mse=np.bincount(inv,weights=(a-b)**2)/np.bincount(inv)
    return float(np.sqrt(np.mean(mse)))

def bootstrap_model(base,Xante,Xcons,y,g,train_ix,fold,R,rep):
    """Same resampled configuration indices in all variants and R (paired-draw design)."""
    grp=g[train_ix];uni=np.unique(grp);rng=np.random.default_rng(int.from_bytes(hashlib.sha256(f'R10-CONTROL|{fold}|{rep}'.encode()).digest()[:8],'little'))
    positions=[np.flatnonzero(grp==t) for t in uni];draw=rng.integers(0,len(uni),size=len(uni));ix=train_ix[np.concatenate([positions[i] for i in draw])]
    return training_model(Xante,Xcons,y,ix,R)

def run_one(d,variant,fold,R,B,overwrite=False):
    filename=RESULTS/f'{variant}_outer{fold:02d}_R{R:02d}_B{B:03d}.json'
    if filename.exists() and not overwrite:return json.loads(filename.read_text())
    ante,cons=VARIANTS[variant];Xa=feature(d,ante);Xc=feature(d,cons)
    y=d.scaled_SPL_dB.to_numpy(float);g=d.group_id.to_numpy(str)
    tr,te=list(GroupKFold(10).split(Xa,y,g))[fold]
    start=time.time();parent,records=training_model(Xa,Xc,y,tr,R)
    rec={'variant':variant,'antecedent_inputs':ante,'consequent_inputs':cons,'fold':fold,'R':R,'h':H,
         'lambda':FIT_LAMBDA,'bootstrap_attempts':B,'train_rows':len(tr),'train_groups':len(set(g[tr])),
         'test_rows':len(te),'test_groups':len(set(g[te])),'parent_fit_success':parent is not None,
         'fcm_restarts':records,'input_hash_sha256':hashlib.sha256((ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').read_bytes()).hexdigest()}
    if parent is None:
        rec['elapsed_s']=time.time()-start;filename.write_text(json.dumps(rec,indent=2));return rec
    pred=infer(parent,Xa[te],Xc[te]);rec['test_group_rmse_dB']=group_rmse(y[te],pred,g[te]);rec['test_square_error_by_group']={str(k):float(np.mean((y[te][g[te]==k]-pred[g[te]==k])**2)) for k in np.unique(g[te])}
    rec['parent_fcm_iters']=parent['fcmiters'];rec['parent_fcm_seed']=parent['fcmseed']
    Wpar=fire(parent['scante'].transform(Xa[tr]),parent['C'],parent['S'])
    P=design(parent['sccons'].transform(Xc[tr]),Wpar)
    s=np.linalg.svd(P/np.sqrt(len(tr)),compute_uv=False);rec['parent_condition']=float(s[0]/s[-1]);rec['q']=P.shape[1]
    rec['bootstrap_failed']=0;rec['bootstrap_success']=0;rec['pairs']=0;rec['pairs_empty']=0
    match_fracs=[];D=[];Dparent=[];retentions=[];J=[];failed_records=[]
    fullp=local_full_on_X(parent,Xc[tr]);gp=g[tr]
    for rep in range(B):
        boot,blog=bootstrap_model(parent,Xa,Xc,y,g,tr,fold,R,rep)
        if boot is None:
            failed_records.append({'rep':rep,'reason':'FCM_ALL_FIVE_RESTARTS_NONCONVERGENT','fcm':blog})
            continue
        rec['bootstrap_success']+=1
        Wb=fire(boot['scante'].transform(Xa[tr]),boot['C'],boot['S'])
        match,sim=jaccard_assignment(Wpar,Wb,gp)
        match_fracs.append(float(np.mean(match>=0)))
        fullb=local_full_on_X(boot,Xc[tr])
        for r,sid in enumerate(match):
            if sid<0:continue
            rec['pairs']+=1;J.append(float(sim[r,sid]))
            par_support=(Wpar[:,r]>=ACTIVATION)
            both=par_support & (Wb[:,sid]>=ACTIVATION)
            if not both.any():rec['pairs_empty']+=1;continue
            n0=len(np.unique(gp[par_support]));keys=np.unique(gp[par_support]);refrac=[np.mean(both[gp==key][par_support[gp==key]]) for key in keys]
            retentions.append(float(np.mean(refrac)))
            Dparent.append(common_D(fullp[par_support,r],fullb[par_support,sid],gp[par_support]))
            D.append(common_D(fullp[both,r],fullb[both,sid],gp[both]))
    rec['bootstrap_failed']=B-rec['bootstrap_success'];rec['failed_register']=failed_records
    rec['match_fraction_mean']=float(np.mean(match_fracs)) if match_fracs else None
    rec['matched_common_pair_count']=len(D)
    rec['D_parent_median_dB']=float(np.median(Dparent)) if Dparent else None
    rec['D_common_median_dB']=float(np.median(D)) if D else None
    rec['common_support_retention_median']=float(np.median(retentions)) if retentions else None
    rec['matched_jaccard_median']=float(np.median(J)) if J else None
    rec['elapsed_s']=time.time()-start
    filename.write_text(json.dumps(rec,indent=2,allow_nan=False))
    return rec

def aggregate():
    rows=[];grp={}
    for path in RESULTS.glob('?_outer??_R??_B???.json'):
        r=json.loads(path.read_text())
        if not r.get('parent_fit_success'):continue
        rows.append({k:v for k,v in r.items() if k in ['variant','fold','R','bootstrap_attempts','train_groups','test_groups','parent_fcm_iters',
          'parent_condition','test_group_rmse_dB','bootstrap_success','bootstrap_failed','match_fraction_mean','matched_common_pair_count',
          'D_parent_median_dB','D_common_median_dB','common_support_retention_median','elapsed_s']})
        k=(r['variant'],r['R'],r['bootstrap_attempts']);grp.setdefault(k,[]).append(r)
    if not rows:return
    pd.DataFrame(rows).sort_values(['bootstrap_attempts','variant','R','fold']).to_csv(RESULTS/'R10_FOLD_RESULTS.csv',index=False)
    out=[]
    for (v,R,B),rr in sorted(grp.items()):
        mse={key:e for r in rr for key,e in r['test_square_error_by_group'].items()}
        f=lambda x:float(np.median([r[x] for r in rr if r.get(x) is not None])) if any(r.get(x) is not None for r in rr) else None
        out.append({'variant':v,'R':R,'B_per_fold':B,'folds':len(rr),'unique_held_out_groups':len(mse),
          'pooled_config_RMSE_dB':float(np.sqrt(np.mean(list(mse.values())))),
          'median_parent_condition':f('parent_condition'),'bootstrap_success':sum(r['bootstrap_success'] for r in rr),
          'bootstrap_failed':sum(r['bootstrap_failed'] for r in rr),
          'median_fold_match_frac':f('match_fraction_mean'),'median_fold_D_common_dB':f('D_common_median_dB'),
          'median_fold_retention':f('common_support_retention_median'),'matched_pairs':sum(r['pairs'] for r in rr),
          'empty_pairs':sum(r['pairs_empty'] for r in rr)})
    pd.DataFrame(out).to_csv(RESULTS/'R10_AGGREGATED_EXPLORATORY.csv',index=False)
    return pd.DataFrame(out)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--variants',default='A,D');p.add_argument('--rs',default='2,4,6,8,10,12');p.add_argument('--folds',default='0,1');p.add_argument('--bootstrap',type=int,default=8);p.add_argument('--overwrite',action='store_true');args=p.parse_args()
    d=load();vs=args.variants.split(',');Rs=[int(x) for x in args.rs.split(',')];folds=[int(x) for x in args.folds.split(',')]
    with threadpool_limits(limits=1):
        for variant in vs:
            assert variant in VARIANTS
            for R in Rs:
                for fold in folds:
                    r=run_one(d,variant,fold,R,args.bootstrap,args.overwrite)
                    print(f"DONE {variant} R={R} f={fold} P={r['parent_fit_success']} B={r.get('bootstrap_success')} "
                    f"match={r.get('match_fraction_mean')} D={r.get('D_common_median_dB')} "
                    f"test_rmse={r.get('test_group_rmse_dB')} time={r['elapsed_s']:.1f}s",flush=True)
        print('\nAGGREGATE:');print(aggregate().to_string(index=False),flush=True)
