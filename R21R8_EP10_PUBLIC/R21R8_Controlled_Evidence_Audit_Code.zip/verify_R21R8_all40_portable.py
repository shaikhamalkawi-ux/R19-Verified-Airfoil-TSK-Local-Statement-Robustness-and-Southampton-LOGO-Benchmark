#!/usr/bin/env python3
"""Independent verification of 57 H3Air R21R8 newly replayed internal states.

No import of the replay generator and no modification to existing files. The caller
provides the directory containing 40 canonical per-task ZIPs plus their summaries,
and the root of the *original, unchanged* historical R5 results/bootstrap directory.

Example:
  python verify_R21R8_all40_portable.py \
    --archives ./NEW_FULLSTATE_TASK_ARCHIVES \
    --original-bootstrap ./57_H3_Airfoil_R5/results/bootstrap \
    --certificate ./R21R8_FULL40_Completion_Certificate.json \
    --output ./R21R8_REVIEWER_RECHECK.json

The `--task 12` option performs a one-task smoke test. Omit for all 40 tasks.
The numerical PASS does not establish historical source-byte identity, physical
measurement uncertainty, redistribution rights or journal approval.
"""
from __future__ import annotations
import argparse, hashlib, json, zipfile
from io import BytesIO
from pathlib import Path
import numpy as np
import pandas as pd

FAILS={(20, 'relearn', 141),(25, 'relearn', 115)}
ATOL=1e-7;RTOL=1e-9

def sha_file(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
 return h.hexdigest()

def tn(i):return f"{'F4' if i<20 else 'F5'}_fold{(i%20)//2:02d}_{'compact' if i%2==0 else 'reference'}"

def audit_task(i,archives,historical,expected):
 name=tn(i)
 path=archives/(name+'_NEW_STATES_AND_AUDIT.zip');summary=archives/(name+'_summary.json')
 if not path.is_file() or not summary.is_file():raise FileNotFoundError(name+' ZIP or summary missing')
 j=json.loads(summary.read_text()); sha=sha_file(path)
 assert j['task']==name and j['archive_SHA256']==sha and j['verified_attempts']==700 and j['full_task_complete']
 if expected:
  assert expected['sha256']==sha and int(expected['bytes'])==path.stat().st_size
 o={q:np.load(historical/name/(q+'_replicate_results.npz'),allow_pickle=False) for q in ('fixed','relearn')}
 registers={q:pd.read_csv(historical/name/(q+'_replicate_register.csv')).set_index('replicate') for q in ('fixed','relearn')}
 counts={'success':0,'FAILED':0};seen=set();maxes={'predictions':0.0,'coefficients':0.0,'similarities':0.0}
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  rows=[json.loads(x) for x in z.read(name+'_journal.jsonl').decode().splitlines() if x.strip()]
  assert len(rows)==700
  for r in rows:
   branch,rep=r['branch'],int(r['replicate'])
   assert (branch,rep) not in seen;seen.add((branch,rep))
   assert branch in ('fixed','relearn') and 0<=rep<(500 if branch=='fixed' else 200)
   assert r['verified_historical_result'] is True
   reg=registers[branch].loc[rep];old=o[branch];assert int(r['seed'])==int(reg['seed'])==int(old['seeds'][rep])
   status=r['status'];counts[status]+=1
   if status=='FAILED':
    assert (i,branch,rep) in FAILS and str(reg['status'])=='FAILED' and not r.get('new_state_file')
    continue
   assert status=='success' and str(reg['status'])=='success' and r['all_pass'] is True and all(r['checks'].values())
   obj=z.read('NEW_STATE/'+r['new_state_file'])
   assert hashlib.sha256(obj).hexdigest()==r['new_state_SHA256']
   ix=int(r['historical_success_index'])
   with np.load(BytesIO(obj),allow_pickle=False) as a:
    assert int(a['replayed_seed'])==int(r['seed']) and int(a['historical_success_index'])==ix
    assert np.array_equal(a['replay_matches'],old['match'][ix])
    v=a['replay_similarity'];w=old['sim'][ix]
    maxes['similarities']=max(maxes['similarities'],float(np.max(np.abs(v-w))))
    assert np.allclose(v,w,rtol=RTOL,atol=ATOL)
    for q in ('LS','Ridge'):
     v=a[q+'_pred_replay'];w=old[q+'_preds'][ix]
     maxes['predictions']=max(maxes['predictions'],float(np.max(np.abs(v-w))))
     assert np.allclose(v,w,rtol=RTOL,atol=ATOL)
     v=a[q+'_coeff_aligned_replay'];w=old[q+'_coeff'][ix]
     assert np.array_equal(np.isfinite(v),np.isfinite(w))
     keep=np.isfinite(v)
     if keep.any():
      maxes['coefficients']=max(maxes['coefficients'],float(np.max(np.abs(v[keep]-w[keep]))))
      assert np.allclose(v[keep],w[keep],rtol=RTOL,atol=ATOL)
    if branch=='relearn':
     for c,k in [('FCM_seed','fcm_seed'),('fcm_iterations','fcm_iterations')]:
      if c in reg.index and pd.notna(reg[c]):assert int(r[k])==int(reg[c])
  assert seen==({('fixed',j) for j in range(500)}|{('relearn',j) for j in range(200)})
  assert len([x for x in z.namelist() if x.startswith('NEW_STATE/')])==counts['success']
 assert counts['FAILED']==sum(f[0]==i for f in FAILS) and counts['success']==700-counts['FAILED']
 assert j['successful_replays']==counts['success'] and j['reproduced_historical_fcm_failures']==counts['FAILED']
 for v in o.values():v.close()
 return {'task':name,'index':i,'result':'PASS','verified_attempts':700,'new_fitted_states':counts['success'],'reproduced_failures':counts['FAILED'],'sha256':sha,'max_abs':maxes}

def main():
 p=argparse.ArgumentParser();p.add_argument('--archives',type=Path,required=True);p.add_argument('--original-bootstrap',type=Path,required=True);p.add_argument('--certificate',type=Path);p.add_argument('--task',type=int,choices=range(40));p.add_argument('--output',type=Path,default=Path('R21R8_REVIEWER_RECHECK.json'));a=p.parse_args()
 exp={}
 if a.certificate:
  cert=json.loads(a.certificate.read_text());assert cert['verified_full_tasks']==40
  exp={x['task']:x for x in cert['completed_task_archives']}
 ids=[a.task] if a.task is not None else list(range(40))
 rows=[]
 for i in ids:
  r=audit_task(i,a.archives,a.original_bootstrap,exp.get(tn(i)))
  rows.append(r);print('PASS',r['task'],'700 attempts',flush=True)
 out={'scope':'selected task' if a.task is not None else 'all 40','task_count':len(rows),'verified_attempts':sum(x['verified_attempts'] for x in rows),'new_fitted_states':sum(x['new_fitted_states'] for x in rows),'historical_failures':sum(x['reproduced_failures'] for x in rows),'max_abs_pred':max(x['max_abs']['predictions'] for x in rows),'max_abs_coeff':max(x['max_abs']['coefficients'] for x in rows),'max_abs_sim':max(x['max_abs']['similarities'] for x in rows),'all_tasks_pass':True,'task_details':rows,'claim_limit':'New recomputed fitted states, not recovered original Oct 2026 internal fitted-state bytes.'}
 if a.task is None:assert out['verified_attempts']==28000 and out['new_fitted_states']==27998 and out['historical_failures']==2
 a.output.write_text(json.dumps(out,indent=2)+'\n');print('PASS OUTCOME saved',a.output)
if __name__=='__main__':main()
