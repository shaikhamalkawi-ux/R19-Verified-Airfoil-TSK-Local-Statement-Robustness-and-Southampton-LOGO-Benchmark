"""Unmodified solve function from the public AF4 critical_budgets/compute.py."""
import numpy as np
from scipy.linalg import null_space
from scipy.optimize import minimize

def solve(P,b,H,J,M,a,eta):
 base=float(a@b);c=-a/base;k=c@M;K=k@k;e0=1/(K*J)
 assert base!=0 and K>0
 if e0>eta+1e-11:return dict(base=base,eta0=e0,lower=np.inf,upper=np.inf,status='OBJECTIVE_EXCLUDES_ZERO'),None,None,None
 if not e0<eta-1e-11:raise ValueError('near tangency')
 d0=M@k/K;N=null_space(k[None,:]);F=M@N*np.sqrt(eta*J-1/K)
 p0=P@d0;B=P@F;n,m=B.shape;scale=max(abs(p0));p=p0/scale;B=B/scale
 selected=np.unique(np.argsort(-abs(p))[:min(24,n)]);v=np.zeros(m);iterations=0
 bestv=v.copy();bestup=1.;bestlo=0.;bestix=np.array([int(np.argmax(abs(p)))]);bestu=np.array([0.])
 for it in range(30):
  ix=selected;As=np.vstack((B[ix],-B[ix]));ps=np.r_[p[ix],-p[ix]];s=len(ix)
  x0=np.r_[v,max(abs(p+B@v))];jaclin=np.column_stack((-As,np.ones(2*s)))
  def con(x):return np.r_[x[-1]-ps-As@x[:-1],1-x[:-1]@x[:-1]]
  def jac(x):return np.vstack((jaclin,np.r_[-2*x[:-1],0.]))
  res=minimize(lambda x:x[-1],x0,jac=lambda x:np.r_[np.zeros(m),1.],constraints=[{'type':'ineq','fun':con,'jac':jac}],method='SLSQP',options={'ftol':2e-11,'maxiter':160})
  iterations+=int(res.nit);v=res.x[:-1];v=v/max(1.,np.linalg.norm(v))*(1-1e-10)
  pred=p+B@v;up=float(max(abs(pred)))
  if up<bestup:bestup=up;bestv=v.copy()
  mul=np.maximum(res.multipliers[:2*s],0.);mul=mul/max(1.,sum(mul));u=mul[:s]-mul[s:];lo=float(u@p[ix]-np.linalg.norm(B[ix].T@u))
  if lo>bestlo:bestlo=lo;bestix=ix.copy();bestu=u.copy()
  if (bestup-bestlo)*scale<=max(1e-7,5e-7*bestup*scale):break
  new=np.setdiff1d(np.argsort(-abs(pred))[:min(12,n)],selected)
  if not len(new):new=np.setdiff1d(np.argsort(-abs(pred))[:min(len(selected)+24,n)],selected)[:24]
  if not len(new):break
  selected=np.union1d(selected,new)
 d=d0+F@bestv;d+=d0*(1-c@d);cost=d@H@d/J
 if cost>eta-1e-13:
  h=d-d0;d=d0+h*min(1.,np.sqrt((eta*J*(1-1e-10)-1/K)/(h@H@h)))
 u=bestu;ix=bestix;rawlo=float(u@p0[ix]-np.linalg.norm((P[ix]@F).T@u));rawup=float(max(abs(P@d)))
 guard=1e-9*max(1.,rawup,abs(rawlo));lb=max(0.,rawlo-guard);ub=rawup+guard
 assert abs(c@d-1)<1e-10 and d@H@d/J<=eta+1e-12 and np.sum(abs(u))<=1+1e-10 and lb<=ub
 return dict(base=base,eta0=e0,lower=lb,upper=ub,status='BRACKETED',cost=float(d@H@d/J),eq_error=float(abs(c@d-1)),gap=ub-lb,iterations=iterations,cut_rows=len(selected),solver_status=int(res.status)),d,ix,u
