from pathlib import Path
import pandas as pd, numpy as np
import matplotlib.pyplot as plt
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
R=Path(__file__).resolve().parents[1]; F=R/'figures';F.mkdir(exist_ok=True)
S=pd.read_csv(R/'results/EXTERNAL_RESULT_SUMMARY.csv')
fig,ax=plt.subplots(figsize=(7.2,4.2)); ax.bar(S.geometry_id,S.pooled_equal_spectrum_rmse_norm);ax.set_ylabel('Equal-spectrum RMSE (normalized response)');ax.set_title('External per-geometry TSK prediction error');ax.tick_params(axis='x',rotation=18);fig.tight_layout();fig.savefig(F/'F1_EXTERNAL_RMSE.pdf');fig.savefig(F/'F1_EXTERNAL_RMSE.png',dpi=180);plt.close(fig)
C=pd.read_csv(R/'results/statement/INDEPENDENT_PROTECTION_CERTIFICATES.csv'); C['margin']=C.coefficient.abs()/C.joint_upper_bound
fig,ax=plt.subplots(figsize=(7.2,4.2))
for geom,g in C.groupby('geometry_id'):
 ax.scatter(np.arange(len(g)),g.margin,label=geom)
ax.axhline(1,linestyle='--',linewidth=1);ax.set_yscale('log');ax.set_ylabel('|fitted slope| / admissible absolute-change upper bound');ax.set_xlabel('Rule statement within geometry/fold collection');ax.set_title('All 44 external frequency-slope statements are protected at the primary budget');ax.legend(frameon=False,ncol=2);fig.tight_layout();fig.savefig(F/'F2_PROTECTION_MARGINS.pdf');fig.savefig(F/'F2_PROTECTION_MARGINS.png',dpi=180);plt.close(fig)
E=pd.read_csv(R/'results/statement/EPSILON_SENSITIVITY_SUMMARY.csv').sort_values('epsilon_multiplier')
fig,ax=plt.subplots(figsize=(7.2,4.2));ax.plot(E.epsilon_multiplier,E.protected,marker='o',label='Protected from zero');ax.plot(E.epsilon_multiplier,E.reversible,marker='o',label='Strict reversal witness');ax.set_xticks(E.epsilon_multiplier);ax.set_xlabel('Multiplier on the scale-matched pointwise prediction budget');ax.set_ylabel('Frequency-slope statements (out of 44)');ax.set_title('External statement classification sensitivity');ax.legend(frameon=False);fig.tight_layout();fig.savefig(F/'F3_EPSILON_SENSITIVITY.pdf');fig.savefig(F/'F3_EPSILON_SENSITIVITY.png',dpi=180);plt.close(fig)
