# R17 external-geometry replication protocol — locked before model execution

Date: 2026-10-11
Source: University of Southampton dataset DOI 10.5258/SOTON/398169; DataFiles.zip supplied by user.

## Scientific question
Does the statement-robustness phenomenon observed on the NASA NACA 0012 benchmark also occur when the same type of first-order fixed-premise TSK audit is executed independently on other aerofoil geometries? This is a methodological replication, not transfer of fitted coefficients from NACA 0012 and not a claim of cross-geometry prediction.

## Admitted measurements
Only experimental spectra from Figure_3_Data.dat through Figure_14_Data.dat are admitted. Model-prediction columns in the source archive are excluded from fitting and evaluation. Published response is SPL/SPL_expt,max and is treated as a dimensionless normalized response, not dB.

Metadata mapping follows the test-case table in Lau et al., Wind Energy 20(2):233–252, DOI 10.1002/we.2003, and the authors' Southampton dataset. The canonical extraction contains 343 frequency rows in 38 spectra from seven aerofoils.

## Primary geometries
Primary external replication requires >=8 complete spectra so that four outer grouped folds and three inner grouped folds can be executed. Four geometries qualify a priori:
- RisoB1-15: 8 spectra
- RisoB1-18: 8 spectra
- Aerofoil-18: 8 spectra
- Aerofoil-21: 8 spectra

NACA643-418 (3 spectra), NACA0012 (2), and DU96-180 (1) are retained in the canonical table but excluded from model-based primary validation because their spectrum counts are too small for the declared nested design.

## Inputs and holdout unit
Each qualifying geometry is fit separately. Inputs are log10(frequency_Hz), effective angle of attack, and boundary-layer trip indicator. Chord and free-stream velocity are constant within each qualifying geometry and are excluded rather than used as zero-variance inputs. The holdout group is the complete spectrum defined by geometry, trip state, and angle. No frequency row from a held-out spectrum enters its training or inner validation partitions.

## TSK model and tuning
Per outer training set:
- outer GroupKFold: 4 folds over 8 spectra;
- inner GroupKFold: 3 folds over the six outer-training spectra;
- fuzzy c-means: m=2; starts 11,23,47,71,101; tol 1e-6; max_iter 2000;
- candidate rule counts R in {2,4,6};
- Gaussian width h in {0.75,1,1.5}; floor 0.05 in standardized coordinates;
- ridge lambda in {1e-6,1e-4,1e-2,1,100}; all consequent coefficients penalized;
- one-SE selection: smallest R whose best inner equal-spectrum RMSE is within one empirical inner-fold SE of the minimum-error candidate.

Prediction error is equal-spectrum RMSE on the published normalized response. It is not comparable numerically with NASA dB RMSE.

## Statement robustness endpoint
Primary cross-domain statement: sign of the local log-frequency slope. Antecedents and preprocessing are frozen at each selected outer parent model. For each local rule, compute whether a strict sign reversal is feasible while:
1) every training prediction change is bounded by epsilon; and
2) the original ridge objective rises by at most eta=1%.

To avoid importing the NASA 0.1-dB physical unit into a dimensionless response, epsilon is scale matched. Let rho = 0.1 / SD_NASA, where SD_NASA is the population SD of the inherited 1503 NASA scaled-SPL targets. For each external outer fold, epsilon = rho * SD(y_train), using training targets only. The fixed NASA reference value is SD_NASA=6.896361277488791 dB, hence rho=0.014500398... .

Primary reversal target uses gamma=0.001; equal-magnitude reversal gamma=1 is secondary. Held-out inputs and targets are not used to construct witnesses. Held-out transport reports whether the same epsilon is respected on all outer-test rows.

## Sensitivity
For the frequency-slope statement only, repeat classification at 0.5x and 2x the scale-matched epsilon with eta fixed at 1%. These are sensitivity analyses, not model selection criteria.

## Admission / rejection gates
- Reject any spectrum whose metadata cannot be mapped to the published test-case table.
- Do not infer missing absolute SPL values from normalized data.
- Do not combine model predictions shipped in DataFiles.zip with measurements as if they were observations.
- Do not call the four datasets independent experimental campaigns; multiple geometries share sources/facilities and published normalization.
- Do not claim cross-geometry prediction because models are fit separately by geometry.
- Do not promote results to the manuscript unless all four primary geometries complete the declared outer folds and all statement witnesses pass explicit feasibility/objective verification.
