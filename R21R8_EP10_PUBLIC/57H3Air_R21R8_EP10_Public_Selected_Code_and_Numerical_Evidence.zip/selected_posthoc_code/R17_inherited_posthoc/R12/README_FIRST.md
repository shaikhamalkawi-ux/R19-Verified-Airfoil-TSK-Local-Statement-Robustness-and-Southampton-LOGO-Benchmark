# 57 H3 — NASA Airfoil | R12 nested-tuning and dimensionless-coordinate sensitivity

**Status:** `R12_NUMERICAL_COMPLETE_QA_PASS_AUTHOR_REVIEW_ONLY`  
**Date:** 10 October 2026  
**Scientific lineage:** R9 LOCKED / R10 frozen pilot / R11 frozen B200 follow-up / **R12 additional post hoc analysis**.  
**No R9 scientific result, equation, table, plot, conclusion, GitHub release, Zenodo record or journal submission has been altered by this work.**

## Purpose

Complete two gaps identified in R11 without changing the original study:

1. **Independent inner grouped tuning** of h (Gaussian width multiplier) and lambda (full-consequent ridge penalty) for each rule count R in {2,4,6,8,10,12}, under exactly ten external configuration-held-out folds.
2. **A bounded, information-preserving aerodynamic-coordinate sensitivity** using `log10(f delta*/U)` or `log10(pi*f*c/U)` in place of original `log10(f)`, while retaining alpha, chord, velocity and log10(displacement thickness). This is not new data or physical-model validation.

A third analysis repeated **200 whole-configuration bootstrap attempts per outer fold per representation** on each one-SE-selected TSK model to report conditional local-rule disagreement, rule matching and support retention on the same output scale.

## Numerical and scientific constraints

- 1,503 rows; 106 groups determined by observed (angle, chord, velocity), 8–19 frequency rows per group.
- Outer GroupKFold=10; inner GroupKFold=5; no configuration appears in training and held-out portions of the same split.
- FCM m=2, seeds 11/23/47/71/101, max_iter=2000, tol=1e-6; Gaussian width floor 0.05 in standardized coordinates; h in {0.75,1,1.5}; lambda in {1e-6,1e-4,1e-2,1,100}; all local consequent coefficients penalized.
- 3 representations × 10 outer folds × 6 rule counts × 3 widths × 5 penalties = 2,700 screened hyperparameter rows; 900 FCM inner fits (899 converged, one failed); 179 of 180 outer fold-by-rule models evaluable. Strouhal R8 is **incomplete** because one inner FCM attempt failed; never silently impute its remaining 11 held-out groups or report a full-cohort score.
- All 30 one-SE and all 30 minimum-error selected outer results include the full 106 configuration groups.
- Group error is sqrt(mean of per-group MSE), NOT mean of group RMSE; training and validation group weights differ deliberately.
- 3 representations × 10 folds × 200 whole-group draws = 6,000 new bootstrap attempts, 6,000 successful. 46,402 conditional, dependent, matched rule pairs. One-SE models only in this branch.
- Matched local D on common relative support is **not** an outcome prediction RMSE; unmatched rules have no D and are not recorded as zero. Jaccard matching threshold 0.5 and joint normalized firing threshold 0.1 are modeling criteria, not physical validity thresholds.

## Main numerical results

| Representation | One-SE error Egrp | Minimum-inner-error Egrp | Local D common (one-SE, dB) | Match fraction |
|---|---:|---:|---:|---:|
| Original log frequency | 4.166475 | 4.069013 | 11.506165 | 0.758250 |
| Log displacement Strouhal | 4.221820 | 4.143805 | 11.446034 | 0.710875 |
| Log reduced frequency | 4.111824 | 4.083614 | 11.047333 | 0.688958 |

R12 **reproduces the R9 published R9 one-SE and minimum-error TSK values to three decimal places**, and one-SE original rule choices (8 once, 10 seven times, 12 twice). This is numerical-protocol parity, not evidence of an external replicate.

At one-SE, log-reduced-frequency differs from the original by -0.054651 dB (conditional 2.5–97.5% fixed-OOF reweighting: [-0.373025, +0.229248]), and log-Strouhal by +0.055345 dB ([-0.233859, +0.338482]). **Both ranges include zero.** Log-reduced-frequency improves per-group squared loss for only 38 of 106 configurations, and for 5 of 10 outer-fold RMSEs; no general predictive superiority claim is admitted.

Numerically smaller local D values occur alongside **lower rule match fractions**, preventing a conclusion that either coordinate system makes the full rule base more reproducible. Per-R comparisons are recorded separately: log-k at R8 is lower RMSE than the original at R8, but the direction changes for R10 and R12; selecting R based on outer test scores would be leakage.

## Independent auditing and report

- `qa/R12_INDEPENDENT_AGGREGATE_AUDIT.json` — 653/653 PASS.
- `qa/R12_LOCAL_BOOTSTRAP_INDEPENDENT_AUDIT.json` — 483/483 PASS.
- Combined audited controls: 1,136/1,136 PASS at the stated numerical-record level. Full independent rerunning of all 6,000 bootstrap fits was **not** performed a second time; the checks independently re-evaluated saved records.
- `docs/57_H3_Airfoil_R12_Scientific_Results_and_Reproducibility.pdf` — 5-page LaTeX technical report, **not** a revised R9 paper.
- `docs/R12_SCIENTIFIC_DECISION_AR.md` — Arabic interpretation and author decision.
- `results/R12_NESTED_REPRESENTATION_SUMMARY.csv`, `results/R12_TUNED_RULE_COUNT_SUMMARY.csv`, `results/R12_B200_LOCAL_SUMMARY.csv` — central tabulated endpoints.
- `results/per_fold/` and `results/local_bootstrap_B200/` — full audit records; `figures/` — the independent plots.
- `inputs/R10_FROZEN_CODE/` — exact inherited R10 fitting module and helpers. `inputs/R11_FROZEN_FULL_PACKAGE.zip` is an unchanged historical baseline including original R10 and R9 held material; its SHA-256 is in the lineage manifest.

## Replay in a clean extraction

Required Python packages/versions from local execution are in `requirements_R12_observed.txt`. Use a machine with >=4 GB RAM and a compatible numerical environment.

**Record audit only (fast, does not retrain):**

```bash
python code/audit_aggregate_r12.py
python code/audit_r12_local_bootstrap.py
python code/conditional_perR_sensitivities.py
python code/make_r12_figures.py
python code/build_r12_report.py  # requires pdflatex
```

**Re-fit from data (slower; modifies ONLY the new extracted R12 result files):**

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/run_r12_nested.py --workers 4
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/run_r12_local_bootstrap.py --bootstrap 200 --workers 4
python code/audit_aggregate_r12.py
python code/audit_r12_local_bootstrap.py
```

The bootstrap script rebuilds the R12 one-SE models and resamples the same 106 configurations under fixed draw identities. Original UCI source byte-identical acquisition remains unverified. This package must not be misdescribed as an external lab replication, a new algorithm, a causal acoustics study, or a new journal manuscript.

## Publication and rights gate

No code licence, public Zenodo DOI, R12 GitHub commit/tag, independent new-airfoil data, or final author approval is claimed. User/author approval is required for new public publication or replacement of R9 manuscript conclusions. The UCI dataset is under CC BY 4.0 with required attribution: Brooks, Pope and Marcolini (1989), UCI Airfoil Self-Noise, DOI 10.24432/C5VW2C. This dataset licence does not automatically license the project's authored code.
