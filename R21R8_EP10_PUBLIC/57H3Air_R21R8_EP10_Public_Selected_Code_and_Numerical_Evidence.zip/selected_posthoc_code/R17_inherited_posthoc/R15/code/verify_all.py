"""One-command frozen-array verification. No fitting and no new optimization."""
from pathlib import Path
import os,sys,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def manifest_check():
 p=ROOT/'MANIFEST_SHA256.json'
 if not p.exists():return
 m=json.loads(p.read_text());bad=[]
 for rel,h in m.items():
  f=ROOT/rel
  if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=h:bad.append(rel)
 if bad:raise RuntimeError(('Manifest mismatch',bad))
 print(f'Manifest: {len(m)}/{len(m)} PASS',flush=True)

def main():
 manifest_check()
 env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
 for sub in ['', 'budget','narrow']:
  subprocess.run([sys.executable,str(ROOT/'code/verify_results.py'),'--results',str(ROOT/'results'/sub)],env=env,check=True)
 subprocess.run([sys.executable,str(ROOT/'code/test_controls.py')],env=env,check=True)
 subprocess.run([sys.executable,str(ROOT/'code/summarize.py')],env=env,check=True,stdout=subprocess.DEVNULL)
 reports=[json.loads((ROOT/'results'/s/'INDEPENDENT_VERIFICATION.json').read_text()) for s in ['', 'budget','narrow']]
 c=json.loads((ROOT/'qa/SYNTHETIC_AND_INVARIANCE_CONTROLS.json').read_text())
 summary={'status':'PASS','numerical_record_checks':sum(x['checks'] for x in reports),'numerical_record_passed':sum(x['passed'] for x in reports),'synthetic_unit_checks':c['checks'],'synthetic_unit_passed':c['passed'],'unresolved_record_checks':sum(x['unresolved'] for x in reports),'scope':'Stored finite-model numerical verification; not interval arithmetic, retraining, or physical replication'}
 (ROOT/'qa/VERIFY_ALL.json').write_text(json.dumps(summary,indent=2))
 manifest_check()
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
