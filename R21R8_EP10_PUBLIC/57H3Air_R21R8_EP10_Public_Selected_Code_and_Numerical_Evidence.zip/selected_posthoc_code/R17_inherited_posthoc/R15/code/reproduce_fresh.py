"""Recompute all declared optimizations from copied inputs, then compare arrays.
No model training is performed: frozen R14 parent states are the admitted input.
"""
from pathlib import Path
import tempfile,shutil,subprocess,os,sys,json,hashlib
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def main():
 base=Path(tempfile.mkdtemp(prefix='h3_r15_fresh_'))
 for d in ['code','inputs']:shutil.copytree(ROOT/d,base/d)
 (base/'qa').mkdir(exist_ok=True)
 env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
 specs=[('',[]),('budget',['--epsilons','.025','.05','.2','.5','--gammas','0','.001']),('narrow',['--families','AIRFOIL_SAME_R_H1'])]
 runs=[];reports=[]
 try:
  for sub,args in specs:
   dest=base/'results'/sub;dest.mkdir(parents=True,exist_ok=True)
   log=open(ROOT/'qa'/f'fresh_{sub or "primary"}.log','w')
   proc=subprocess.Popen([sys.executable,str(base/'code/run_joint.py'),'--output',str(dest),*args],env=env,stdout=log,stderr=subprocess.STDOUT)
   runs.append((sub,proc,log))
  for sub,proc,log in runs:
   ret=proc.wait();log.close()
   if ret:raise RuntimeError(f'fresh {sub} exit {ret}; inspect log')
   subreport={'branch':sub or 'primary','csv_files':0,'arrays':0,'max_abs_array_difference':0.,'max_abs_numeric_csv_difference':0.,'nonnumeric_parity':True}
   for original in sorted((ROOT/'results'/sub).glob('*_JOINT.csv')):
    a=pd.read_csv(original);b=pd.read_csv(base/'results'/sub/original.name)
    assert a.shape==b.shape and list(a.columns)==list(b.columns)
    for c in a:
     if pd.api.types.is_numeric_dtype(a[c]):
      av=a[c].to_numpy(dtype=float);bv=b[c].to_numpy(dtype=float)
      assert np.array_equal(np.isnan(av),np.isnan(bv)) and np.array_equal(np.isposinf(av),np.isposinf(bv))
      ix=np.isfinite(av)&np.isfinite(bv)
      delta=float(np.max(abs(av[ix]-bv[ix]))) if ix.any() else 0.
      subreport['max_abs_numeric_csv_difference']=max(subreport['max_abs_numeric_csv_difference'],delta)
      assert np.allclose(av,bv,rtol=1e-9,atol=1e-9,equal_nan=True),(original,c,delta)
     else:assert a[c].fillna('NA').tolist()==b[c].fillna('NA').tolist(),(original,c)
    subreport['csv_files']+=1
   for original in sorted((ROOT/'results'/sub).glob('*_WITNESSES.npz')):
    a=np.load(original,allow_pickle=False);b=np.load(base/'results'/sub/original.name,allow_pickle=False);assert a.files==b.files
    for key in a.files:
     av=a[key];bv=b[key];delta=float(np.max(abs(av-bv))) if av.size else 0.
     subreport['max_abs_array_difference']=max(subreport['max_abs_array_difference'],delta)
     assert np.allclose(av,bv,rtol=1e-9,atol=1e-9),(original,key,delta)
     subreport['arrays']+=1
   p=subprocess.run([sys.executable,str(base/'code/verify_results.py'),'--results',str(base/'results'/sub)],env=env,capture_output=True,text=True)
   (ROOT/'qa'/f'fresh_verify_{sub or "primary"}.log').write_text(p.stdout+p.stderr)
   assert p.returncode==0
   subreport['fresh_independent_checks']=json.loads((base/'results'/sub/'INDEPENDENT_VERIFICATION.json').read_text())['checks']
   reports.append(subreport)
  report={'status':'PASS','scope':'Fresh re-solving of frozen-matrix LP/QP problems, NOT a retraining or new observations','branches':reports,'csv_files':sum(x['csv_files'] for x in reports),'arrays':sum(x['arrays'] for x in reports),'temp_removed':True}
  (ROOT/'qa/FRESH_EXECUTION_PARITY.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
 finally:shutil.rmtree(base,ignore_errors=True)
if __name__=='__main__':main()
