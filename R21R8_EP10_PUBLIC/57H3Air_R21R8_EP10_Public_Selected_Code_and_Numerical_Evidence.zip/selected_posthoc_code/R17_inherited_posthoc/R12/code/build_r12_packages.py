"""Issue R12 full, reader and new-chat archives with integrity controls.
No R9/R10/R11 scientific artifact is changed.
"""
from pathlib import Path
import hashlib,json,zipfile,shutil,tempfile,os
R=Path(__file__).resolve().parents[1]
ROOT=R.parent
FULL=ROOT/'57_H3_Airfoil_R12_NestedTuning_FULL_PACKAGE_20261010.zip'
READER=ROOT/'57_H3_Airfoil_R12_ReaderReview_20261010.zip'
HANDOFF=ROOT/'57_H3_Airfoil_R12_NewChat_Transfer_20261010.zip'
PDF=ROOT/'57_H3_Airfoil_R12_Scientific_Results_and_Reproducibility.pdf'
AR=ROOT/'57_H3_Airfoil_R12_SCIENTIFIC_DECISION_AR.md'
shutil.copyfile(R/'docs'/'57_H3_Airfoil_R12_Scientific_Results_and_Reproducibility.pdf',PDF)
shutil.copyfile(R/'docs'/'R12_SCIENTIFIC_DECISION_AR.md',AR)

exclude_suffix={'.aux','.log','.out','.toc','.pyc'}
files=[]
for p in R.rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(R).as_posix()
    if '__pycache__' in p.parts:continue
    if rel.startswith('logs/') or rel.startswith('qa/report_render/') :continue
    if p.suffix in exclude_suffix:continue
    if rel=='R12_SHA256SUMS.txt':continue
    files.append(p)
files.sort(key=lambda x:x.relative_to(R).as_posix())
manifest_lines=[]
for p in files:
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    manifest_lines.append(f'{digest}  {p.relative_to(R).as_posix()}')
(R/'R12_SHA256SUMS.txt').write_text('\n'.join(manifest_lines)+'\n')
files.append(R/'R12_SHA256SUMS.txt')

def build_zip(path,rel_src,arcbase=''):
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for src,dest in rel_src:
            # Zip timestamps deliberately normalized for fixed-content hashing on rebuild
            info=zipfile.ZipInfo(arcbase+dest,date_time=(2026,10,10,12,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            z.writestr(info,Path(src).read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

full_entries=[(p,p.relative_to(R).as_posix()) for p in files]
build_zip(FULL,full_entries,arcbase=R.name+'/')
reader_list=[
  'README_FIRST.md','docs/57_H3_Airfoil_R12_Scientific_Results_and_Reproducibility.pdf',
  'docs/R12_SCIENTIFIC_DECISION_AR.md','docs/R12_NEW_CHAT_HANDOFF.md',
  'results/R12_NESTED_REPRESENTATION_SUMMARY.csv','results/R12_TUNED_RULE_COUNT_SUMMARY.csv',
  'results/R12_B200_LOCAL_SUMMARY.csv','results/R12_B200_FOLD_PAIRED_LOCAL_DIFFERENCES.csv',
  'results/R12_FIXED_OOF_PAIRED_REPRESENTATION_CONTRASTS.csv',
  'results/R12_FIXED_R_CONDITIONAL_PAIRED_SENSITIVITIES.csv',
  'qa/R12_INDEPENDENT_AGGREGATE_AUDIT.json', 'qa/R12_LOCAL_BOOTSTRAP_INDEPENDENT_AUDIT.json',
  'qa/R12_INHERITED_LINEAGE_SHA256.json',
  'qa/R12_CLEAN_EXTRACT_REPLAY_QA.json',
  'figures/R12_Accuracy_vs_Local_Disagreement.pdf','figures/R12_Nested_Representation_RMSE.pdf',
  'figures/R12_Fold_Conditional_Differences.pdf','figures/R12_Tuned_RuleCount_RMSE.pdf',
  'R12_SHA256SUMS.txt']
assert all((R/x).exists() for x in reader_list)
build_zip(READER,[(R/x,x) for x in reader_list])
sha_report={'date':'2026-10-10','R12_FULL_ZIP_SHA256':sha(FULL),'R12_READER_ZIP_SHA256':sha(READER),
            'R12_STANDALONE_PDF_SHA256':sha(PDF),'R12_ARABIC_DECISION_SHA256':sha(AR),
            'R12_FULL_MANIFEST_ENTRY_COUNT':len(files)-1,
            'lineage':'R9 preserved; R10 and R11 preserved; R12 separate author-review evidence'}
( ROOT/'57_H3_Airfoil_R12_DELIVERY_SHA256_20261010.json').write_text(json.dumps(sha_report,indent=2))
transfer=[(FULL,FULL.name),(PDF,PDF.name),(AR,AR.name),(ROOT/'57_H3_Airfoil_R12_DELIVERY_SHA256_20261010.json','R12_DELIVERY_SHA256_20261010.json'),
          (R/'docs'/'R12_NEW_CHAT_HANDOFF.md','COPY_THIS_TO_NEW_CHAT.md')]
build_zip(HANDOFF,transfer)
sha_report['R12_TRANSFER_ZIP_SHA256']=sha(HANDOFF)
( ROOT/'57_H3_Airfoil_R12_DELIVERY_SHA256_20261010.json').write_text(json.dumps(sha_report,indent=2))

# Check each inner manifest against actual bytes in full ZIP and reader snippets.
with zipfile.ZipFile(FULL) as z:
    assert z.testzip() is None
    prefix=R.name+'/'
    mf=z.read(prefix+'R12_SHA256SUMS.txt').decode()
    checked=0
    for line in mf.splitlines():
        v,relative=line.split('  ',1)
        assert hashlib.sha256(z.read(prefix+relative)).hexdigest()==v,(relative,v)
        checked+=1
    assert checked==len(files)-1
    nested=z.read(prefix+'inputs/R11_FROZEN_FULL_PACKAGE.zip')
    assert hashlib.sha256(nested).hexdigest()=='5fd23dcc76126c437a0b8e5622e5100aa1923f4302ac1636cb6808442eece59a'
for zipfile_path in [FULL,READER,HANDOFF]:
    with zipfile.ZipFile(zipfile_path) as z: assert z.testzip() is None
print('R12 DELIVERY MANIFEST',checked,'/',checked,'PASS')
for f in [PDF,AR,FULL,READER,HANDOFF]:print('DELIVERED',f.name,'bytes',f.stat().st_size,'sha256',sha(f))
