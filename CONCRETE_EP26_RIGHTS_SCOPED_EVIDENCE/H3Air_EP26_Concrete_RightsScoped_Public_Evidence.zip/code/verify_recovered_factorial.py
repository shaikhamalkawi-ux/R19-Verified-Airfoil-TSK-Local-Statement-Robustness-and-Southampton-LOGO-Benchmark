"""Read-only source/split/prediction audit and new LP/QP checks. Distinguish archived and newly replayed cells."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import numpy as np,csv,json,hashlib
from scipy.special import logsumexp
from scipy.optimize import linprog
from sklearn.model_selection import GroupKFold
from sklearn.ensemble import ExtraTreesRegressor
from original_r17_optimization_core import minimum_cost
from read_uci_xls_biff8 import parse_ole_workbook,parse_numeric_cells
R=Path(__file__).resolve().parents[1]; O=R/'verification';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={'official':'Concrete_UCI_Official_1030x9.csv','rounded':'Concrete_pyFUME_Rounded1030.csv','high':'Concrete_RuleKit_HighPrecision1030.csv'}
A={k:np.loadtxt(R/'data'/v,delimiter=',',skiprows=1) for k,v in files.items()}
raw=R/'provenance/Concrete_Data.xls';assert sha(raw)=='710076c66b9ca3f8050e7942f3dcbdbe04013534daeb0077ffd3079a52d8e0c4'
sheets=parse_numeric_cells(parse_ole_workbook(raw));official=np.array([[sheets['Sheet1'][(i,j)] for j in range(9)] for i in range(1,1031)]);assert np.array_equal(official,A['official'])
def groups(x):
 keys=[tuple(r[:7]) for r in x];lookup={v:i for i,v in enumerate(sorted(set(keys)))};return np.array([lookup[k] for k in keys])
G={'original':groups(A['official']),'rounded':groups(A['rounded'])}
assert len(set(G['original']))==428 and len(set(G['rounded']))==427
splits={k:list(GroupKFold(5).split(A['official'][:,:8],groups=g)) for k,g in G.items()}
F={k:np.empty(1030,dtype=int) for k in G}
for k in G:
 for i,(tr,te) in enumerate(splits[k]):F[k][te]=i
assert sum(F['original']!=F['rounded'])==792
expected={'official_original':(8.1278,5.1074,10),'rounded_original':(8.1282,5.1308,10),'official_rounded':(8.1892,4.9530,8),'rounded_rounded':(8.1895,5.0047,8),'high_original':(8.1278,5.1200,10),'high_rounded':(8.1892,4.9643,8)}
rows=[];dec=[];details=[];maxerr=0.;nnew=0;cross=0
for cell,(t0,e0,w0) in expected.items():
 val,group=cell.split('_');X=A[val][:,:8];y=A[val][:,8];g=G[group];yt=np.full(1030,np.nan);ye=yt.copy();seen=np.zeros(1030,int);count={};kind='new replay' if cell in ('official_rounded','rounded_original') else 'historical saved state'
 for k,(tr,te) in enumerate(splits[group]):
  p=R/'runs'/cell/f'fold{k:02d}_state.npz'
  with np.load(p) as z:d={n:z[n] for n in z.files}
  assert np.array_equal(d['tr'],tr) and np.array_equal(d['te'],te) and not set(g[tr])&set(g[te]);assert np.array_equal(d['Xtrain'],X[tr]) and np.array_equal(d['Xtest'],X[te]) and np.array_equal(d['ytrain'],y[tr]) and np.array_equal(d['ytest'],y[te]);assert np.array_equal(d['gtrain'],g[tr]) and np.array_equal(d['gtest'],g[te]);assert str(d['source_csv_sha256'])==sha(R/'data'/files[val]);seen[te]+=1
  if cell=='rounded_original':
   keys={tuple(x) for x in X[tr]};cross+=sum(tuple(x) in keys for x in X[te])
  def design(xx):
   zz=(xx-d['mean'])/d['scale'];l=-.5*(((zz[:,None,:]-d['C'])/d['S'])**2).sum(2);w=np.exp(l-logsumexp(l,axis=1,keepdims=True));return (w[:,:,None]*np.c_[np.ones(len(zz)),zz][:,None,:]).reshape(len(zz),-1)
  P,Pt=design(X[tr]),design(X[te]);b=d['beta'];lam=float(d['lam']);n=len(tr);H=P.T@P/n+lam*np.eye(len(b));J=float(np.mean((y[tr]-float(d['offset'])-P@b)**2)+lam*(b@b));res=P.T@(P@b-(y[tr]-float(d['offset'])))/n+lam*b
  assert np.max(abs(res))<1e-10;assert abs(J-float(d['J']))<1e-9;assert int(d['R'])==2
  et=ExtraTreesRegressor(n_estimators=160,max_features=float(d['et_mf']),min_samples_leaf=int(d['et_leaf']),min_samples_split=2,bootstrap=False,random_state=23,n_jobs=1).fit(X[tr],y[tr]);yp=Pt@b+float(d['offset']);ep=et.predict(X[te]);err=max(np.max(abs(P-d['P'])),np.max(abs(Pt-d['Pt'])),np.max(abs(yp-d['ytpred'])),np.max(abs(ep-d['etpred'])),np.max(abs(H-d['H'])));assert err<1e-8,(cell,k,err);maxerr=max(maxerr,float(err));yt[te]=yp;ye[te]=ep
  # Independently re-evaluate selected candidate from recorded training-only tables.
  with open(R/'runs'/cell/f'fold{k:02d}_TSK_candidates.csv') as f:ts=list(csv.DictReader(f))
  v=[r for r in ts if int(r['valid'])];key=lambda r:(float(r['score']),int(r['R']),abs(float(r['h'])-1),float(r['lambda']));best=min(v,key=key);bound=float(best['score'])+float(best['foldscore_se']);sel=min((r for r in v if float(r['score'])<=bound+1e-12),key=lambda r:(int(r['R']),float(r['score']),abs(float(r['h'])-1),float(r['lambda'])));assert (int(sel['R']),float(sel['h']),float(sel['lambda']))==(int(d['R']),float(d['h']),lam)
  with open(R/'runs'/cell/f'fold{k:02d}_ET_candidates.csv') as f:etrows=list(csv.DictReader(f))
  es=min(etrows,key=lambda r:(float(r['score']),int(r['min_samples_leaf']),float(r['max_features'])));assert len(etrows)==12 and len(ts)==27;assert (float(es['max_features']),int(es['min_samples_leaf']))==(float(d['et_mf']),int(d['et_leaf']))
  details.append(dict(cell=cell,fold=k,lineage=kind,sha256=sha(p),max_array_difference=float(err),stationarity_inf=float(np.max(abs(res)))))
  # Independent signed-row support LP, residual-corrected dual upper bound for zero-contact exclusion.
  B=np.r_[P,-P];smin=np.linalg.svd(P,compute_uv=False)[-1];sig=np.std(y[tr]);assert smin>0
  for feature,j0 in [('age',7),('water',3)]:
   for rule in range(2):
    j=rule*9+j0+1;c=np.eye(len(b))[j];sol=linprog(-c,A_ub=B,b_ub=np.ones(len(B)),bounds=[(None,None)]*len(b),method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9});assert sol.success
    u=sol.x/max(1,np.max(abs(P@sol.x)));lo=u[j];mu=np.maximum(0,-sol.ineqlin.marginals);up=float(mu.sum()+np.sqrt(n)*np.linalg.norm(B.T@mu-c)/smin);assert lo>0 and up>=lo-1e-7
    strict=-1.001*b[j];crit=abs(strict)/lo;v=u*strict/lo;crit_obj=float(v@H@v/J)
    for frac in (.01,.025,.05):
     eps=frac*sig;cls='protected' if eps*up<abs(b[j])-1e-8 else 'unresolved';cost=held=trmax=None
     if cls=='unresolved' and crit<=eps and crit_obj<=.01:
      # Rebuild original-budget minimum-cost witness, not an LP witness selected using heldout data.
      q=minimum_cost(P,H,J,j,strict,eps,initial=v)
      assert q['status']=='optimal',(cell,k,j,q['status']);delta=q['d'];cost=float(delta@H@delta/J);held=float(np.max(abs(Pt@delta)));trmax=float(np.max(abs(P@delta)));assert cost<=.01+1e-7 and trmax<=eps+1e-7 and abs(delta[j]-strict)<1e-6;cls='reversible';assert held>eps
      np.savez_compressed(O/f'{cell}_fold{k:02d}_{feature}_rule{rule}_eps{frac}.npz',delta=delta,critical_delta=v,lp_mu=mu,lp_support_vector=u,coef_index=j,eps=eps,relative_cost=cost,max_heldout=held,critical_budget=crit,critical_objective=crit_obj)
     assert cls!='unresolved',(cell,k,j,frac,eps*up,abs(b[j]),crit_obj)
     dec.append(dict(cell=cell,fold=k,rule=rule,feature=feature,budget_fraction=frac,status=cls,epsilon=float(eps),beta=float(b[j]),unit_LP_lower=float(lo),unit_LP_upper=up,critical_strict_fraction=float(crit/sig),critical_objective_fraction=crit_obj,relative_objective=cost,max_train=trmax,max_heldout=held))
     count[feature,frac,cls]=count.get((feature,frac,cls),0)+1
 assert (seen==1).all()
 def rmse(p):
  return float(np.sqrt(np.mean(np.bincount(g,weights=(y-p)**2)/np.bincount(g))))
 t,e=rmse(yt),rmse(ye); assert abs(t-t0)<=.00005 and abs(e-e0)<=.00005,(cell,t,e,t0,e0);assert count['age',.05,'protected']==10 and count['water',.05,'protected']==w0
 rows.append(dict(cell=cell,lineage=kind,groups=len(set(g)),TSK=t,ET=e,age_protected=count['age',.05,'protected'],water_protected=count['water',.05,'protected'])); print(rows[-1],flush=True)
np.testing.assert_equal(cross,12)
main=[d for d in dec if not d['cell'].startswith('high_')];rev=[d for d in main if d['status']=='reversible'];assert len(main)==240 and len(rev)==4 and all(r['fold'] in [2,4] and r['rule']==0 and r['feature']=='water' for r in rev)
cr=[d['critical_strict_fraction'] for d in rev];assert round(min(cr),6)==.028890 and round(max(cr),6)==.035907,(min(cr),max(cr))
for name,rr in [('six_scenarios.csv',rows),('all_360_decisions.csv',dec),('all_30_states.csv',details)]:
 with (O/name).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rr[0].keys());w.writeheader();w.writerows(rr)
summary=dict(status='PASS',archived_states=20,new_replayed_states=10,models_checked=30,decisions_checked=len(dec),factorial_decisions=len(main),factorial_protected=len(main)-len(rev),factorial_reversed=len(rev),critical_strict_fraction_min=min(cr),critical_strict_fraction_max=max(cr),fold_assignment_changes=792,rounded_input_overlap_count=cross,max_state_array_difference=maxerr,source_xls_sha256=sha(raw),rows=rows,original_EP9_missing_states_reconstructed_not_recovered=True)
(O/'verification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
