# Bristol independent-source audit — public code and aggregate evidence

Reproduction code and aggregate expected checks for Supplement S31 (Tables S35–S36). This is not a public raw-data deposit.

1. Download the original archive from https://data.bris.ac.uk/datasets/30c8q39wi1mxf205flnun3l5rl/30c8q39wi1mxf205flnun3l5rl.zip . See `SOURCE_PROVENANCE.json` for the exact checked identity and licence. The supplied source archive is 68,279,376 bytes and the embedded provider manifest has 59 matched file digests.
2. Use Python 3.13.5 and install `requirements.txt` into a virtual environment.
3. Run `python reproduce.py --source-zip /path/to/30c8q39wi1mxf205flnun3l5rl.zip --work new_private_run --workers 4` (the output directory must not exist). The scripts first admit the source, then fit both nested protocols and compute the finite-input sign certificates. The independent verifier reconstructs all saved designs, checks candidate selection and replays selected Extra Trees and all certificate records. `check_expected.py` checks the generated aggregate outcomes.

All nine outer folds, 37 inner folds, 272 budget-statement tests and 47 strict witnesses were verified. A fresh end-to-end run during preparation of this supplement reproduced all 100 saved result files byte-for-byte. The expected CSVs are aggregate summaries, not training data. Keep generated source-derived data private unless their use and redistribution have been cleared. See `RIGHTS_AND_ATTRIBUTION.md` and `PUBLIC_RELEASE_SCOPE.md`.

The experiment tests whether the fixed-antecedent numerical audit can be replicated after separate refitting on independent measurements. It is not a NASA-to-Bristol predictor transfer or an independent replication of the bootstrap antecedent-relearning study. No physical sign or future deployment guarantee is claimed.
