# H3Air EP26 - Concrete factorial: rights-scoped public evidence

This is a public subset of the controlled EP26 recovery/replay archive. The six scenario results, 360 decisions, 30 selected model records and six saved witness files are preserved. Four factorial strict-reversal alternatives all exceed their held-out input prediction budget. The 20 recovered historical states and ten replayed states are distinguished in `verification/all_30_states.csv`. This is not the missing original EP9 archive.

Ten official-input NPZ states are preserved byte-for-byte. Twenty mirror-input states retain original project-derived parameters, splits, model predictions and summary arrays; six input/target/design arrays are excluded from each. The original private archive is unchanged. `PUBLIC_PROJECTION_MANIFEST.json` records each projection and original hash. All six omitted arrays reconstructed exactly from the previously verified normalized inputs in a local projection check; this is not a fresh model-fitting or independent source download.

## Reproduction
1. Check `sha256sum -c SHA256SUMS.txt` in the extracted folder.
2. Install the pinned dependencies in `requirements.txt` (Python 3.13.5).
3. In a separate working copy run `python code/restore_public_inputs.py` to obtain the two pinned mirror source files directly from their providers, verify Git blob SHA-1, and produce the normalized CSVs. The script refuses a mismatched normalized SHA-256. It then restores the six omitted arrays to the projected state files. Rehydrated NPZ archive byte hashes may differ; they are not historical originals.
4. In that working copy run `python -B code/verify_recovered_factorial.py` to independently re-evaluate stored models and decisions. This rewrites verification outputs. It is not a full rerun of the nested fitting grid for the historical states. The full EP26 controlled archive remains separate.

Rights and attribution: see `LICENSE_SCOPE.md`.
