"""Plots use newly admitted R11 results. One figure per plot, default Matplotlib palette."""
from pathlib import Path
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]
OUT=R/'figures';OUT.mkdir(exist_ok=True)
x=pd.read_csv(R/'results'/'R11_B200_SUMMARY.csv')
f=pd.read_csv(R/'results'/'R11_B200_FOLD_RESULTS.csv')

# Accuracy / local D diagram is deliberately NOT a one-dimensional ranking.
fig,ax=plt.subplots(figsize=(7.2,4.7))
for _,z in x.iterrows():
 label=f"{z['variant']}/R={int(z['R'])}"
 ax.scatter(z.group_RMSE_dB,z.median_fold_D_common_dB,s=30+105*z.median_fold_match_fraction)
 ax.annotate(label,(z.group_RMSE_dB,z.median_fold_D_common_dB),xytext=(5,4),textcoords='offset points',fontsize=8)
ax.set_xlabel('Held-out equal-configuration RMSE (dB; lower is better)')
ax.set_ylabel('Median fold matched local D on common support (dB)')
ax.set_title('R11: accuracy and conditional local-rule disagreement')
ax.grid(alpha=.25);fig.tight_layout()
for ext in ['pdf','png']:
 fig.savefig(OUT/f'R11_Accuracy_vs_Conditional_D.{ext}',dpi=200,metadata={'Creator':'57 H3 R11 numerical analysis'})
plt.close(fig)

# Paired AB within-fold differences fixed training hyperparameters.
a=f[(f.variant=='A')&(f.R==10)].set_index('fold').sort_index()
b=f[(f.variant=='B')&(f.R==10)].set_index('fold').sort_index()
assert len(a)==len(b)==10
err=b.test_group_RMSE_dB.to_numpy()-a.test_group_RMSE_dB.to_numpy()
diff=b.D_common_dB.to_numpy()-a.D_common_dB.to_numpy()
fig,ax=plt.subplots(figsize=(6.7,4.7))
ax.scatter(err,diff)
for fold,(u,v) in enumerate(zip(err,diff)):
 ax.annotate(str(fold),(u,v),xytext=(4,3),textcoords='offset points',fontsize=8)
ax.axvline(0,linewidth=.8,linestyle='--');ax.axhline(0,linewidth=.8,linestyle='--')
ax.set_xlabel('B − A held-out fold RMSE (dB; negative favors B)')
ax.set_ylabel('B − A fold median D-common (dB; positive means more disagreement)')
ax.set_title('R11: shared-premise input-role contrast (200 draws per fold)')
ax.grid(alpha=.2);fig.tight_layout()
for ext in ['pdf','png']:
 fig.savefig(OUT/f'R11_Fold_Paired_B_minus_A.{ext}',dpi=200,metadata={'Creator':'57 H3 R11 numerical analysis'})
plt.close(fig)

# Ridge sweep in the same antecedents and matching per lambda within folds.
p=R/'results'/'R11_B200_RIDGE_SUMMARY.csv'
if p.exists():
 t=pd.read_csv(p).sort_values('lambda')
 fig,ax=plt.subplots(figsize=(6.7,4.7))
 ax.plot(t.group_RMSE_dB,t.median_fold_D_common_dB,marker='o',linestyle='-')
 for _,q in t.iterrows():
  ax.annotate(f"λ={q['lambda']:g}",(q.group_RMSE_dB,q.median_fold_D_common_dB),xytext=(6,4),textcoords='offset points',fontsize=9)
 ax.set_xlabel('Equal-configuration RMSE (dB; lower is better)')
 ax.set_ylabel('Matched local D on common support (dB)')
 ax.set_title('R11: ridge shrinkage is not automatically stability')
 ax.grid(alpha=.2);fig.tight_layout()
 for ext in ['pdf','png']:
  fig.savefig(OUT/f'R11_Ridge_Collapse_Tradeoff.{ext}',dpi=200,metadata={'Creator':'57 H3 R11 numerical analysis'})
 plt.close(fig)
print('figures:',*[str(f.name) for f in sorted(OUT.glob('R11*'))],sep='\n')
