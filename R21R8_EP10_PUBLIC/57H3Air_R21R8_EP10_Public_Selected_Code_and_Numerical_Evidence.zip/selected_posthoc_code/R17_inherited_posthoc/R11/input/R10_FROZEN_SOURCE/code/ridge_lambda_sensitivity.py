"""Supplementary fixed-R, fixed-h penalty sweep with identical FCM antecedents per bootstrap draw.
Exploratory; independent of published R9 model-selection results.
"""
from __future__ import annotations
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np,pandas as pd
import scipy.linalg
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits
from controlled_rule_study import ROOT,feature,fcm,fire,design,jaccard_assignment,common_D,VARIANTS
from decode_derived_table import load

RS=[6,10,12];LAMBDAS=(1e-6,1e-4,1e-2,1,100.)
OUT=ROOT/'results'/'penalty_sensitivity';OUT.mkdir(parents=True,exist_ok=True)

def fit_antecedents(xa,xc,y,R,ix):
 sa=StandardScaler().fit(xa[ix]);sc=StandardScaler().fit(xc[ix]);Z=sa.transform(xa[ix]);
 ff,record=fcm(Z,R)
 if ff is None:return None,record
 W=fire(Z,ff['C'],ff['S']);P=design(sc.transform(xc[ix]),W)
 U,s,Vt=scipy.linalg.svd(P/np.sqrt(len(ix)),full_matrices=False,check_finite=False)
 a=U.T@((y[ix]-np.mean(y[ix]))/np.sqrt(len(ix)))
 return {'ante':sa,'con':sc,'fit':ff,'W':W,'s':s,'Vt':Vt,'a':a,'ymean':float(np.mean(y[ix])),'R':R},record

def beta(mod,lam):
 s=mod['s'];return mod['Vt'].T@((s/(s*s+lam))*mod['a'])

def local(mod,xx,lam):
 z=mod['con'].transform(xx)
 return mod['ymean']+np.column_stack((np.ones(len(z)),z))@beta(mod,lam).reshape(mod['R'],-1).T

def group_error(y,yp,g):
 keys=np.unique(g);return {str(u):float(np.mean((y[g==u]-yp[g==u])**2)) for u in keys}

def run_variant(d,variant,R,fold,B):
 dest=OUT/f'{variant}_R{R:02d}_fold{fold:02d}_B{B:03d}.json'
 if dest.exists():return json.loads(dest.read_text())
 g=d.group_id.to_numpy(str);y=d.scaled_SPL_dB.to_numpy(float)
 ante,cons=VARIANTS[variant];xa=feature(d,ante);xc=feature(d,cons)
 tr,te=list(GroupKFold(10).split(xa,y,g))[fold]
 st=time.time();p,logs=fit_antecedents(xa,xc,y,R,tr)
 rec={'variant':variant,'R':R,'fold':fold,'bootstrap_attempts':B,'parent_success':p is not None,'bootstrap_fails':0}
 if p is None:
  dest.write_text(json.dumps(rec,indent=2));return rec
 Wp=p['W'];Wp_localX=local;gz=g[tr]
 grp=np.unique(gz);grpidx=[np.flatnonzero(gz==u) for u in grp]
 for lam in LAMBDAS:
  Wt=fire(p['ante'].transform(xa[te]),p['fit']['C'],p['fit']['S'])
  pred=p['ymean']+design(p['con'].transform(xc[te]),Wt)@beta(p,lam)
  rec[f'mse_by_group_{lam:g}']=group_error(y[te],pred,g[te])
 metrics={lam:{'D':[],'parent_D':[],'retained':[],'pairs':0,'empty':0} for lam in LAMBDAS}
 frac=[];fails=[]
 for b in range(B):
  seed=int.from_bytes(hashlib.sha256(f'R10-LAMBDA|{fold}|{b}'.encode()).digest()[:8],'little')
  rng=np.random.default_rng(seed);draw=rng.integers(0,len(grp),size=len(grp))
  ix=tr[np.concatenate([grpidx[j] for j in draw])]
  c,log=fit_antecedents(xa,xc,y,R,ix)
  if c is None:
   fails.append(b);continue
  Wb=fire(c['ante'].transform(xa[tr]),c['fit']['C'],c['fit']['S'])
  a,sim=jaccard_assignment(Wp,Wb,gz);frac.append(float(np.mean(a>=0)))
  pl={lam:local(p,xc[tr],lam) for lam in LAMBDAS}
  bl={lam:local(c,xc[tr],lam) for lam in LAMBDAS}
  for r,s in enumerate(a):
   if s<0:continue
   pp=Wp[:,r]>=.1;common=pp&(Wb[:,s]>=.1)
   for lam in LAMBDAS:
    m=metrics[lam];m['pairs']+=1
    if not common.any():m['empty']+=1;continue
    m['D'].append(common_D(pl[lam][common,r],bl[lam][common,s],gz[common]))
    m['parent_D'].append(common_D(pl[lam][pp,r],bl[lam][pp,s],gz[pp]))
    retain=[np.mean(common[gz==u][pp[gz==u]]) for u in np.unique(gz[pp])]
    m['retained'].append(float(np.mean(retain)))
 rec['bootstrap_fails']=len(fails);rec['failed_indices']=fails;rec['match_fraction_mean']=float(np.mean(frac)) if frac else None
 for lam in LAMBDAS:
  m=metrics[lam]
  rec[f'lambda_{lam:g}']={'D_common_median':float(np.median(m['D'])) if m['D'] else None,
    'D_parent_median':float(np.median(m['parent_D'])) if m['parent_D'] else None,
    'median_retention':float(np.median(m['retained'])) if m['retained'] else None,
    'pairs':m['pairs'],'empty_pairs':m['empty']}
 rec['elapsed_s']=time.time()-st
 dest.write_text(json.dumps(rec,indent=2));return rec

def aggregate():
 raw=[]
 for path in OUT.glob('*_B*.json'):
  x=json.loads(path.read_text());
  if not x.get('parent_success'):continue
  raw.append(x)
 rows=[]
 for (var,R,lam,B),l in pd.DataFrame([(r['variant'],r['R'],lam,r['bootstrap_attempts'],r) for r in raw for lam in LAMBDAS],columns=['v','r','lam','B','rec']).groupby(['v','r','lam','B']):
  rlist=l.rec.tolist();gerrs={k:v for r in rlist for k,v in r[f'mse_by_group_{lam:g}'].items()}
  mm=[r[f'lambda_{lam:g}']['D_common_median'] for r in rlist if r[f'lambda_{lam:g}']['D_common_median'] is not None]
  rows.append({'variant':var,'R':R,'lambda':lam,'folds':len(rlist),'groups':len(gerrs),'B_per_fold':B,
   'pooled_config_RMSE_dB':float(np.sqrt(np.mean(list(gerrs.values())))),
   'median_fold_D_common_dB':float(np.median(mm)) if mm else None,
   'median_fold_match_fraction':float(np.median([r['match_fraction_mean'] for r in rlist if r.get('match_fraction_mean') is not None])),
   'matched_pairs':sum(r[f'lambda_{lam:g}']['pairs'] for r in rlist),
   'bootstrap_failed':sum(r['bootstrap_fails'] for r in rlist)})
 out=pd.DataFrame(rows).sort_values(['variant','R','lambda']);out.to_csv(OUT/'R10_LAMBDA_SWEEP_SUMMARY.csv',index=False)
 return out

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--variants',default='D');ap.add_argument('--rs',default='6,10,12');ap.add_argument('--folds',default='0,1,2,3,4,5,6,7,8,9');ap.add_argument('--bootstrap',type=int,default=30);a=ap.parse_args()
 d=load()
 with threadpool_limits(1):
  for v in a.variants.split(','):
   for R in [int(x) for x in a.rs.split(',')]:
    for f in [int(x) for x in a.folds.split(',')]:
     r=run_variant(d,v,R,f,a.bootstrap)
     print('DONE',v,R,f,'success',r.get('parent_success'),'failed',r.get('bootstrap_fails'),'time',round(r.get('elapsed_s',0),1),flush=True)
  print('\nAGGREGATE:');print(aggregate().to_string(index=False),flush=True)
