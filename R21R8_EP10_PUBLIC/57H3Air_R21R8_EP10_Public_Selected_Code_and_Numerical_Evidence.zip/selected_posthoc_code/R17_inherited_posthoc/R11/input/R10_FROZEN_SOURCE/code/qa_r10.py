"""Independent executable integrity & mathematical checks for R10 exploratory extension."""
import hashlib,json,base64,sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.linalg import norm
from sklearn.model_selection import GroupKFold
from decode_derived_table import load
from controlled_rule_study import feature,fcm,fire,design,training_model,infer,local_full_on_X,jaccard_assignment,common_D,VARIANTS
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def gate(name,test,detail=None):
    result=bool(test);checks.append({'name':name,'PASS':result,'detail':detail});print(('PASS' if result else 'FAIL'),name,detail or '')
    if not result:raise AssertionError(name)
d=load()
gate('n_rows_1503',len(d)==1503)
gate('n_groups_106',d.group_id.nunique()==106)
gate('group_size_8_19',d.groupby('group_id').size().agg(['min','max']).tolist()==[8,19])
gate('row_ids_unique_sequential',(d.row_id.to_numpy()==np.arange(1,1504)).all())
gate('group_metadata_const',bool((d.groupby('group_id')[['angle_deg','chord_m','velocity_m_s','displacement_m']].nunique()==1).all().all()))
cols=['frequency_Hz','angle_deg','chord_m','velocity_m_s','displacement_m','scaled_SPL_dB']
source_sums=[4338230,10193.799999999901,205.2319999999972,76443.7000000002,16.743240227999987,187628.42199999982]
source_sq=[27449736300,121743.8399999994,41.166369279998726,4252235.990000023,0.44625654273205273,23494253.330601986]
gate('all_6_source_column_sums_numeric_parity',np.allclose(d[cols].sum().to_numpy(float),source_sums,rtol=2e-13,atol=1e-9))
gate('all_6_source_column_square_sums_numeric_parity',np.allclose((d[cols]**2).sum().to_numpy(float),source_sq,rtol=2e-13,atol=1e-9))
bytes_=base64.b64decode(''.join((ROOT/'data'/'packed_rows_b64.txt').read_text().split()))
h=2166136261
for b in bytes_: h=((h^b)*16777619)&0xffffffff
gate('GitHub_packed_row_FNV32_parity',h==2994833655,hex(h))
gate('GitHub_first_row',d.iloc[0].group_id=='G024' and np.isclose(d.iloc[0].scaled_SPL_dB,126.201))
gate('GitHub_last_row',d.iloc[-1].group_id=='G097' and np.isclose(d.iloc[-1].scaled_SPL_dB,104.204))
folds=list(GroupKFold(10).split(feature(d,'F4'),d.scaled_SPL_dB,d.group_id))
gate('outer_10_splits',len(folds)==10)
gate('each_configuration_test_once',sorted(np.concatenate([te for tr,te in folds]).tolist())==list(range(1503)))
gate('outer_group_disjoint',all(set(d.group_id.iloc[tr]).isdisjoint(d.group_id.iloc[te]) for tr,te in folds))
X=feature(d,'F5');y=d.scaled_SPL_dB.to_numpy(float);tr,te=folds[0]
from threadpoolctl import threadpool_limits
with threadpool_limits(limits=1):
    M,restarts=training_model(X,X,y,tr,2)
    gate('FCM_5_restart_records',len(restarts)==5)
    gate('TSK_parent_converged',M is not None)
    W=fire(M['scante'].transform(X[tr]),M['C'],M['S'])
    gate('normalized_firing_nonnegative',np.isfinite(W).all() and W.min()>=0)
    gate('normalized_firing_sums_one',np.allclose(W.sum(axis=1),1,atol=1e-12))
    yp=infer(M,X[tr],X[tr]);local=local_full_on_X(M,X[tr])
    gate('TSK_global_equal_weighted_local',np.allclose(yp,(W*local).sum(axis=1),atol=1e-9))
    match,sim=jaccard_assignment(W,W,d.group_id.to_numpy(str)[tr]);gate('identical_rule_memberships_match',np.all(match==np.arange(2)) and np.allclose(np.diag(sim),1.))
    gate('identical_local_D_zero',np.isclose(common_D(local[:,0],local[:,0],d.group_id.to_numpy(str)[tr]),0))
    order=np.array([1,0]);swap={'scante':M['scante'],'sccons':M['sccons'],'C':M['C'][order],
          'S':M['S'][order],'beta':M['beta'].reshape(2,6)[order].ravel(),'targetmean':M['targetmean']}
    gate('rule_permutation_invariance',np.allclose(infer(M,X[te],X[te]),infer(swap,X[te],X[te]),atol=1e-9))
    gate('constant_R2_width_1_lambda_0p01',np.all(np.isfinite(infer(M,X[te],X[te]))))
report={'project':'57 H3 Airfoil','label':'R10 exploratory control QA','source_github_commit':'6c537312da0388a0c9a2784ee175be95f8657747',
        'original_GitHub_numeric_csv_SHA256':'1d3433fe4fc65073b0cf858809dff9906db237dd6460b1e319e33fc2d98f1588',
        'reconstructed_numeric_csv_SHA256':hashlib.sha256((ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').read_bytes()).hexdigest(),
        'cross_transport':'numeric parity; not byte-identical', 'checks':checks,'passed':sum(x['PASS'] for x in checks),'total':len(checks)}
(ROOT/'qa'/'R10_QA_REPORT.json').write_text(json.dumps(report,indent=2))
print('R10 QA:',report['passed'],'/',report['total'],'PASS')
