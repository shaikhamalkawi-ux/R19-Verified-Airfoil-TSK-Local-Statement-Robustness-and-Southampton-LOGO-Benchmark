import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import json,hashlib,itertools,urllib.parse,argparse
from pathlib import Path
import numpy as np,pandas as pd,h5py
from scipy.linalg import svd,cholesky,solve_triangular
from scipy.optimize import linprog
from sklearn.model_selection import GroupKFold,LeaveOneGroupOut
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import ExtraTreesRegressor
from concurrent.futures import ProcessPoolExecutor
import common as c
from solver import solve as solve_ball
ROOT=Path(__file__).resolve().parent
ETA=.01;GAMMA=.001

def extract(raw,out):
 root=next(raw.glob('*/.info.json')).parent;meta=json.loads((root/'.info.json').read_text());checks=[]
 def visit(x):
  if isinstance(x,dict):
   if 'sha1' in x:
    p=root.parent/urllib.parse.unquote(x['id']);a=p.read_bytes();s=hashlib.sha1(a).hexdigest();checks.append(dict(file=str(p.relative_to(root)),bytes=len(a),sha1=s,expected=x['sha1'],match=s==x['sha1'],sha256=hashlib.sha256(a).hexdigest()))
   for v in x.values():visit(v)
  elif isinstance(x,list):
   for v in x:visit(v)
 visit(meta['hasPart']);assert len(checks)==59 and all(r['match'] for r in checks);pd.DataFrame(checks).to_csv(out/'source_inventory.csv',index=False)
 rec=[];inv=[]
 for p in sorted(root.glob('NACA*/*ff_sound.h5')):
  with h5py.File(p,'r') as h:a=h['angles'][:].ravel();f=h['f'][:];y=h['spl'][:]
  assert f.shape==y.shape==(len(a),12) and np.isfinite(y).all() and np.isfinite(f).all() and np.all(f>0) and np.all(f==f[0]) and np.all(np.diff(f[0])>0) and len(set(a))==len(a)
  geo=p.parent.name
  with h5py.File(p.with_name(p.name.replace('_ff_sound','_effective_AoA')),'r') as h:aa=h['angles'][:].ravel()
  inv.append(dict(geometry=geo,spectra=len(a),rows=y.size,angle_min=a.min(),angle_max=a.max(),spl_min=y.min(),spl_max=y.max(),effective_angle_key_match=bool(np.array_equal(a,aa)),effective_missing_in_spl=','.join(map(str,sorted(set(aa)-set(a)))),spl_missing_in_effective=','.join(map(str,sorted(set(a)-set(aa))))))
  for i,angle in enumerate(a):
   for j,freq in enumerate(f[i]):rec.append(dict(row_id=len(rec)+1,geometry=geo,group=f'{geo}|{angle:+.0f}',angle_deg=angle,frequency_Hz=freq,spl_dB=y[i,j],source_file=str(p.relative_to(root)),source_angle_index=i,source_band_index=j))
 d=pd.DataFrame(rec);assert len(d)==1464 and d.group.nunique()==122 and d.geometry.nunique()==4 and d.groupby('group').size().eq(12).all();d.to_csv(out/'canonical_private.csv',index=False);pd.DataFrame(inv).to_csv(out/'data_inventory.csv',index=False);return d

def fit_task(arg):
 prot,fold,tr,te,d,out=arg;fd=Path(out)/f'{prot}_{fold:02}';fd.mkdir(exist_ok=True)
 X=np.column_stack((np.log10(d.frequency_Hz),d.angle_deg));y=d.spl_dB.to_numpy();g=d.group.to_numpy();geo=d.geometry.to_numpy();assert not set(g[tr])&set(g[te])
 if prot=='LOGO':
  assert not set(geo[tr])&set(geo[te]);inner=list(LeaveOneGroupOut().split(X[tr],y[tr],geo[tr]))
 else:inner=list(GroupKFold(5).split(X[tr],y[tr],g[tr]))
 nr=len(inner);counts=[];tsk=[];et=[];logs=[];splitrows=[];params=list(itertools.product((1,3,5),(.7,1.),(12,None)))
 for ii,(it,iv) in enumerate(inner):
  t,v=tr[it],tr[iv];assert not set(g[t])&set(g[v]);assert prot!='LOGO' or not set(geo[t])&set(geo[v]);counts.append(len(np.unique(g[v])))
  for role,idx in [('train',t),('validation',v)]:splitrows.extend(dict(inner=ii,role=role,row_id=int(d.row_id.iloc[i]),group=g[i]) for i in idx)
  sc=StandardScaler().fit(X[t]);A=sc.transform(X[t]);V=sc.transform(X[v]);ym=y[t].mean();yc=y[t]-ym
  for R in c.RS:
   f,info=c.fcm(A,R);logs.extend(dict(inner=ii,R=R,**r) for r in info)
   if f is None:continue
   for h in c.HS:
    W,_=c.fire(A,f['C'],h*f['S']);WV,_=c.fire(V,f['C'],h*f['S']);P=c.design(A,W);Q=c.design(V,WV);U,s,Vh=svd(P/np.sqrt(len(t)),full_matrices=False);p=U.T@(yc/np.sqrt(len(t)))
    for lam in c.LAMBDAS:
     b=Vh.T@((s/(s*s+lam))*p);tsk.append(dict(kind='Ridge',R=R,h=h,**{'lambda':lam},inner=ii,rmse=c.group_rmse(y[v],ym+Q@b,g[v])))
  for k,(leaf,mf,depth) in enumerate(params):
   m=ExtraTreesRegressor(n_estimators=400,random_state=c.SEED,n_jobs=1,bootstrap=False,min_samples_leaf=leaf,max_features=mf,max_depth=depth).fit(X[t],y[t]);et.append(dict(candidate=k,inner=ii,rmse=c.group_rmse(y[v],m.predict(X[v]),g[v])))
 pd.DataFrame(splitrows).to_csv(fd/'inner_splits.csv',index=False);pd.DataFrame(tsk).to_csv(fd/'tsk_candidates.csv',index=False);pd.DataFrame(et).to_csv(fd/'et_candidates.csv',index=False);pd.DataFrame(logs).to_csv(fd/'fcm_restarts.csv',index=False)
 agg=[]
 for (R,h,lam),gg in pd.DataFrame(tsk).groupby(['R','h','lambda']):
  if len(gg)!=nr:continue
  vals=gg.sort_values('inner').rmse.to_numpy();agg.append(dict(kind='Ridge',R=int(R),h=float(h),**{'lambda':float(lam)},score=float(np.sqrt(np.average(vals**2,weights=counts))),se=float(vals.std(ddof=1)/np.sqrt(nr))))
 assert agg;sel=c.sel_tsk(agg,'Ridge','oneSE');pd.DataFrame(agg).to_csv(fd/'tsk_aggregate.csv',index=False)
 etagg=[]
 for k,gg in pd.DataFrame(et).groupby('candidate'):
  vals=gg.sort_values('inner').rmse.to_numpy();assert len(vals)==nr;etagg.append((float(np.sqrt(np.average(vals**2,weights=counts))),int(k)))
 etscore,k=min(etagg);leaf,mf,depth=params[k];m=ExtraTreesRegressor(n_estimators=400,random_state=c.SEED,n_jobs=1,bootstrap=False,min_samples_leaf=leaf,max_features=mf,max_depth=depth).fit(X[tr],y[tr]);etp=m.predict(X[te])
 sc=StandardScaler().fit(X[tr]);A=sc.transform(X[tr]);B=sc.transform(X[te]);f,outerlogs=c.fcm(A,sel['R']);assert f is not None;C=f['C'];S=f['S']*sel['h'];W,_=c.fire(A,C,S);Wt,_=c.fire(B,C,S);P=c.design(A,W);Pt=c.design(B,Wt);ym=y[tr].mean();b=c.coef_lstsq(P,y[tr]-ym,sel['lambda']);yp=ym+Pt@b
 pd.DataFrame(dict(row_id=d.row_id.iloc[te].to_numpy(),group=g[te],geometry=geo[te],angle=d.angle_deg.iloc[te].to_numpy(),y=y[te],tsk=yp,extra_trees=etp)).to_csv(fd/'predictions.csv',index=False);np.savez_compressed(fd/'state.npz',tr=tr,te=te,scaler_mean=sc.mean_,scaler_scale=sc.scale_,C=C,S=S,beta=b,P=P,Pt=Pt,ytrain=y[tr],offset=ym,lam=sel['lambda'])
 rec=dict(protocol=prot,fold=fold,train_rows=len(tr),test_rows=len(te),train_groups=len(set(g[tr])),test_groups=len(set(g[te])),heldout_geometries=sorted(set(geo[te])),selection=sel,outer_fcm_restarts=outerlogs,et=dict(score=etscore,candidate=k,min_samples_leaf=leaf,max_features=mf,max_depth=depth),tsk_rmse=c.group_rmse(y[te],yp,g[te]),et_rmse=c.group_rmse(y[te],etp,g[te]),complete_tsk_candidates=len(agg),all_tsk_candidates=90)
 (fd/'fit.json').write_text(json.dumps(rec,indent=2));print('FIT',prot,fold,sel['R'],sel['lambda'],rec['tsk_rmse'],rec['et_rmse'],flush=True);audit_state(fd);return rec

def audit_state(fd):
 z=np.load(fd/'state.npz',allow_pickle=False);P,Pt,b=z['P'],z['Pt'],z['beta'];y=z['ytrain']-float(z['offset']);lam=float(z['lam']);n,q=P.shape;H=P.T@P/n+lam*np.eye(q);J=np.mean((P@b-y)**2)+lam*b@b;M=solve_triangular(cholesky(H,lower=True).T,np.eye(q));G=np.linalg.solve(H,np.eye(q));assert np.max(abs(H@b-P.T@y/n))<1e-9
 rows=[];ev={}
 def check_target(U,a,scale,eps):
  c0=-a/(scale*float(a@b));v=G@c0;K=c0@v;e0=1/(K*J);room=ETA*J-1/K
  if e0>ETA+1e-10:return ('OBJ',e0,None,None,None,None,None)
  if room<=0:return ('UNRESOLVED',e0,None,None,None,None,None)
  d0=v/K;nn=len(U);lp=linprog(np.r_[np.zeros(q),1.],A_ub=np.column_stack([np.vstack([U,-U]),-np.ones(2*nn)]),b_ub=np.zeros(2*nn),A_eq=np.r_[c0,0.][None,:],b_eq=[1.],bounds=[(None,None)]*q+[(0,None)],method='highs',options={'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
  if not lp.success:return ('UNRESOLVED',e0,None,None,None,None,None)
  d=lp.x[:-1];du=-lp.ineqlin.marginals;u=du[:nn]-du[nn:];u/=max(1.,sum(abs(u)));ix=np.flatnonzero(u);u=u[ix];d+=d0*(1-c0@d);h=d-d0;d=d0+h*min(1.,np.sqrt(room*(1-1e-9)/max(h@H@h,1e-300)))
  def bounds(d,ix,u):
   ad=U[ix].T@u;tangent=G@ad-v*(c0@G@ad)/K;rawlo=ad@d0-np.sqrt(room*max(0,tangent@H@tangent));rawup=max(abs(U@d));guard=1e-9*max(1,abs(rawlo),rawup);return max(0.,rawlo-guard),rawup+guard
  lo,up=bounds(d,ix,u)
  if lo<=eps<=up:
   try:
    alt,dd,ii,uu=solve_ball(U,b*scale,H,J,M,a,ETA)
    if alt['status']=='BRACKETED':
     if alt['upper']<up:d=dd
     if alt['lower']>lo:ix,u=ii,uu
     lo,up=bounds(d,ix,u)
   except Exception:pass
  if not(np.isfinite(d).all() and abs(c0@d-1)<1e-8 and d@H@d/J<=ETA+1e-10 and sum(abs(u))<=1+1e-10 and lo<=up+1e-10):return ('UNRESOLVED',e0,None,None,None,None,None)
  return ('BOUNDED',e0,lo,up,d,ix,u)
 def classify(U,j,eps,stem):
  a=np.eye(q)[j];rec=dict(zero_eta0=None,zero_lower=None,zero_upper=None,status='UNRESOLVED',witness_train=None,witness_test=None,witness_eta=None)
  if abs(b[j])<1e-12:return rec
  st,e0,lo,up,d,ix,u=check_target(U,a,1.,eps);rec.update(zero_eta0=e0,zero_lower=lo,zero_upper=up)
  if st=='OBJ':rec['status']='PROTECTED_OBJECTIVE';return rec
  if st=='BOUNDED':
   ev.update({stem+'_zero_d':d,stem+'_zero_ix':ix,stem+'_zero_u':u})
   if lo>eps:rec['status']='PROTECTED_BOUND';return rec
   w=d*(1+GAMMA)
   if not(max(abs(U@w))<eps-1e-10 and w@H@w/J<ETA-1e-10):w=check_target(U,a,1+GAMMA,eps)[4]
   if w is not None:
    train=max(abs(P@w));test=max(abs(Pt@w));eta=(np.mean((P@(b+w)-y)**2)+lam*((b+w)@(b+w))-J)/J
    if max(abs(U@w))<=eps-1e-10 and eta<=ETA+1e-10 and abs((b[j]+w[j])/b[j]+GAMMA)<1e-8:
     rec.update(status='STRICT_REVERSAL',witness_train=float(train),witness_test=float(test),witness_eta=float(eta));ev[stem+'_strict']=w
  return rec
 for eps in (.1,1.):
  for r in range(q//3):
   for k,feature in [(1,'log10_frequency'),(2,'geometric_angle')]:
    j=3*r+k;stem=f'e{eps:g}_r{r:02}_k{k}';old=classify(P,j,eps,stem+'_train');rec=dict(epsilon=eps,rule=r,feature=feature,j=j,base=b[j],**{f'train_{k}':v for k,v in old.items()})
    if old['status'].startswith('PROTECTED'):joint=dict(status='PROTECTED_SUBSET',zero_eta0=None,zero_lower=None,zero_upper=None,witness_train=None,witness_test=None,witness_eta=None)
    elif old['status']=='STRICT_REVERSAL' and old['witness_test']<=eps:joint=dict(old);joint['status']='ORIGINAL_WITNESS_RETAINED'
    else:joint=classify(np.vstack([P,Pt]),j,eps,stem+'_joint')
    rec.update({f'joint_{k}':v for k,v in joint.items()});rows.append(rec)
 pd.DataFrame(rows).to_csv(fd/'slope_audit.csv',index=False);np.savez_compressed(fd/'slope_evidence.npz',**ev);print('AUDIT',fd.name,pd.DataFrame(rows).groupby(['epsilon','train_status']).size().to_dict(),flush=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--raw',type=Path,default=ROOT/'raw');ap.add_argument('--out',type=Path,default=ROOT/'results');ap.add_argument('--workers',type=int,default=4);args=ap.parse_args();args.out.mkdir(exist_ok=True,parents=True);d=extract(args.raw,args.out);tasks=[];geo=d.geometry.to_numpy();g=d.group.to_numpy()
 for fold,(tr,te) in enumerate(LeaveOneGroupOut().split(d,d.spl_dB,geo)):tasks.append(('LOGO',fold,tr,te,d,args.out))
 ix=np.flatnonzero(geo=='NACA 0012')
 for fold,(tr,te) in enumerate(GroupKFold(5).split(d.iloc[ix],d.spl_dB.iloc[ix],g[ix])):tasks.append(('NACA0012',fold,ix[tr],ix[te],d,args.out))
 with ProcessPoolExecutor(max_workers=args.workers) as pool:records=list(pool.map(fit_task,tasks))
 (args.out/'fit_summary.json').write_text(json.dumps(records,indent=2));print('COMPLETE',len(records),flush=True)
if __name__=='__main__':main()
