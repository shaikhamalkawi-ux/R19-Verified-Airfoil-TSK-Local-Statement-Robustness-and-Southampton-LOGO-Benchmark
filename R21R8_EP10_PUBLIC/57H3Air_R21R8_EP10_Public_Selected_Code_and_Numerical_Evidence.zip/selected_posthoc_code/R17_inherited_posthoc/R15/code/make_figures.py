from pathlib import Path
import numpy as np,pandas as pd
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams['pdf.fonttype']=42

def save(fig,name):
 fig.tight_layout()
 fig.savefig(OUT/(name+'.pdf'),metadata={'CreationDate':None,'ModDate':None})
 fig.savefig(OUT/(name+'.png'),dpi=190)
 plt.show();plt.close(fig)

counts=pd.read_csv(ROOT/'results/reporting/FEATURE_SIGN_COUNTS.csv').set_index('feature')
order=['log10_frequency','angle','chord','velocity','log10_displacement']
labels=['Log frequency','Angle of attack','Chord length','Free-stream velocity','Log displacement thickness']
a=counts.loc[order,'SIGN_PROTECTED_POINTWISE'].to_numpy();b=counts.loc[order,'FEASIBLE_REVERSAL'].to_numpy();y=np.arange(5)
fig,ax=plt.subplots(figsize=(7.5,4.2));ax.barh(y,a,label='Sign protected');ax.barh(y,b,left=a,label='Feasible sign reversal');ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlim(0,118)
for i in y:
 ax.text(a[i]/2,i,str(a[i]),va='center',ha='center')
 ax.text(a[i]+b[i]/2,i,str(b[i]),va='center',ha='center')
ax.set_xlabel('Local slopes (102 per feature; dependent model components)');ax.set_title('Joint-budget statement audit: 510 slopes, no unresolved cases');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.18),ncol=2,frameon=False);save(fig,'F1_Protected_and_Reversible')

surf=pd.read_csv(ROOT/'results/reporting/BUDGET_SURFACE.csv');surf=surf[surf.gamma==.001]
fig,ax=plt.subplots(figsize=(7.0,4.2))
for eta in [.0001,.001,.01]:
 g=surf[surf.eta_relative==eta].sort_values('epsilon_dB')
 ax.plot(g.epsilon_dB,g.feasible_target,marker='o',label=f'Objective increase <= {100*eta:g}%')
ax.set_xscale('log');ax.set_xticks([.025,.05,.1,.2,.5],['0.025','0.05','0.1','0.2','0.5']);ax.set_xlabel('Maximum change at every training input (dB)');ax.set_ylabel('Slopes with a feasible 0.1%-magnitude sign reversal');ax.set_ylim(0,350);ax.legend(frameon=False);ax.set_title('Critical-budget profile, not a population probability');save(fig,'F2_Budget_Profile')

spec=pd.read_csv(ROOT/'results/reporting/EXAMPLE_SPECTRUM_SUPPORT0.3.csv');g=spec[(spec.firing>=.3)&(spec.frequency_Hz>=499.99)&(spec.frequency_Hz<=8000.01)].sort_values('frequency_Hz')
fig,ax=plt.subplots(figsize=(7.,4.2))
ax.plot(g.frequency_Hz,g.original_local_dB-g.original_local_dB.iloc[0],marker='o',label='Original local function: change from 500 Hz')
ax.plot(g.frequency_Hz,g.witness_local_dB-g.witness_local_dB.iloc[0],marker='s',label='Alternative local function: change from 500 Hz')
ax.set_xscale('log');ax.set_xticks([500,1000,2000,4000,8000],['500','1,000','2,000','4,000','8,000']);ax.set_xlabel('Observed frequency (Hz), configuration G013');ax.set_ylabel('Change within the local component (dB)');ax.set_title('An observed-input local trend reverses; antecedents fixed');ax.legend(frameon=False,loc='best');save(fig,'F3_Observed_Local_Contrast')
