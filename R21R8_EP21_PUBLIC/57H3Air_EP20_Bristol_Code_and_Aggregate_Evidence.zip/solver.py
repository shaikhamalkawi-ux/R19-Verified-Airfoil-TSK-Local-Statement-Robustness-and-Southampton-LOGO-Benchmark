#!/usr/bin/env python3
"""Frozen-state critical zero-reaching budget with primal/dual brackets."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import numpy as np,pandas as pd
from scipy.linalg import cholesky,solve_triangular,null_space
from scipy.optimize import minimize
from scipy.special import logsumexp
import argparse,time
from concurrent.futures import ProcessPoolExecutor
ROOT=Path(__file__).resolve().parent

def fold_data(file):
 z=np.load(file,allow_pickle=False);P=z['P'];b=z['beta'];n,q=P.shape
 H=P.T@P/n+float(z['lam'])*np.eye(q);J=np.mean((z['ytrain']-float(z['offset'])-P@b)**2)+float(z['lam'])*b@b
 M=solve_triangular(cholesky(H,lower=True).T,np.eye(q),lower=False)
 Z=z['Tt'][:,1:];T=z['Tt'];E=-.5*np.sum(((Z[:,None,:]-z['C'])/z['S'])**2,axis=2);W=np.exp(E-logsumexp(E,axis=1,keepdims=True))
 score=-(Z[:,None,0]-z['C'][None,:,0])/z['S'][None,:,0]**2
 WP=W*(score-(W*score).sum(axis=1,keepdims=True));Tp=np.zeros_like(T);Tp[:,1]=1
 D=(WP[:,:,None]*T[:,None,:]+W[:,:,None]*Tp[:,None,:]).reshape(len(T),q)
 assert np.max(abs(W-z['Wt']))<1e-12
 A=[];meta=[]
 for r in range(int(z['R'])):
  a=np.zeros(q);a[6*r+1]=1;A.append(a);meta.append(('local',r,r,'',np.nan))
 for i,a in enumerate(D):
  A.append(a);meta.append(('global',int(z['ids_test'][i]),int(W[i].argmax()),str(z['gtest'][i]),float(10**(Z[i,0]*z['scale'][0]+z['mean'][0]))))
 return P,b,H,float(J),M,np.array(A),meta

def solve(P,b,H,J,M,a,eta):
 base=float(a@b);c=-a/base;k=c@M;K=k@k;e0=1/(K*J)
 assert base!=0 and K>0
 if e0>eta+1e-11:return dict(base=base,eta0=e0,lower=np.inf,upper=np.inf,status='OBJECTIVE_EXCLUDES_ZERO'),None,None,None
 if not e0<eta-1e-11:raise ValueError('near tangency')
 d0=M@k/K;N=null_space(k[None,:]);F=M@N*np.sqrt(eta*J-1/K)
 p0=P@d0;B=P@F;n,m=B.shape;scale=max(abs(p0));p=p0/scale;B=B/scale
 selected=np.unique(np.argsort(-abs(p))[:min(24,n)]);v=np.zeros(m);iterations=0
 bestv=v.copy();bestup=1.;bestlo=0.;bestix=np.array([int(np.argmax(abs(p)))]);bestu=np.array([0.])
 for it in range(30):
  ix=selected;As=np.vstack((B[ix],-B[ix]));ps=np.r_[p[ix],-p[ix]];s=len(ix)
  x0=np.r_[v,max(abs(p+B@v))];jaclin=np.column_stack((-As,np.ones(2*s)))
  def con(x):return np.r_[x[-1]-ps-As@x[:-1],1-x[:-1]@x[:-1]]
  def jac(x):return np.vstack((jaclin,np.r_[-2*x[:-1],0.]))
  res=minimize(lambda x:x[-1],x0,jac=lambda x:np.r_[np.zeros(m),1.],constraints=[{'type':'ineq','fun':con,'jac':jac}],method='SLSQP',options={'ftol':2e-11,'maxiter':160})
  iterations+=int(res.nit);v=res.x[:-1];v=v/max(1.,np.linalg.norm(v))*(1-1e-10)
  pred=p+B@v;up=float(max(abs(pred)))
  if up<bestup:bestup=up;bestv=v.copy()
  mul=np.maximum(res.multipliers[:2*s],0.);mul=mul/max(1.,sum(mul));u=mul[:s]-mul[s:];lo=float(u@p[ix]-np.linalg.norm(B[ix].T@u))
  if lo>bestlo:bestlo=lo;bestix=ix.copy();bestu=u.copy()
  if (bestup-bestlo)*scale<=max(1e-7,5e-7*bestup*scale):break
  new=np.setdiff1d(np.argsort(-abs(pred))[:min(12,n)],selected)
  if not len(new):new=np.setdiff1d(np.argsort(-abs(pred))[:min(len(selected)+24,n)],selected)[:24]
  if not len(new):break
  selected=np.union1d(selected,new)
 d=d0+F@bestv;d+=d0*(1-c@d);cost=d@H@d/J
 if cost>eta-1e-13:
  h=d-d0;d=d0+h*min(1.,np.sqrt((eta*J*(1-1e-10)-1/K)/(h@H@h)))
 u=bestu;ix=bestix;rawlo=float(u@p0[ix]-np.linalg.norm((P[ix]@F).T@u));rawup=float(max(abs(P@d)))
 guard=1e-9*max(1.,rawup,abs(rawlo));lb=max(0.,rawlo-guard);ub=rawup+guard
 assert abs(c@d-1)<1e-10 and d@H@d/J<=eta+1e-12 and np.sum(abs(u))<=1+1e-10 and lb<=ub
 return dict(base=base,eta0=e0,lower=lb,upper=ub,status='BRACKETED',cost=float(d@H@d/J),eq_error=float(abs(c@d-1)),gap=ub-lb,iterations=iterations,cut_rows=len(selected),solver_status=int(res.status)),d,ix,u

def work(args):
 f,src,eta,out=args;P,b,H,J,M,A,meta=fold_data(Path(src)/f'AIRFOIL_ONESE_fold{f:02d}.npz');records=[];ds=[];indices=[];weights=[];offsets=[0];keys=[]
 for a,(kind,key,r,group,freq) in zip(A,meta):
  row,d,ix,u=solve(P,b,H,J,M,a,eta);records.append(dict(fold=f,kind=kind,key=key,rule=r,group=group,frequency_hz=freq,eta=eta,**row))
  if d is not None:keys.append((kind,str(key)));ds.append(d);indices.extend(ix);weights.extend(u);offsets.append(len(indices))
 pd.DataFrame(records).to_csv(Path(out)/f'fold{f:02d}_thresholds.csv',index=False)
 np.savez_compressed(Path(out)/f'fold{f:02d}_evidence.npz',keys=np.array(keys),d=np.array(ds),ix=np.array(indices,dtype=int),u=np.array(weights),offset=np.array(offsets,dtype=int))
 finite=[r for r in records if r['status']=='BRACKETED'];print('fold',f,'rows',len(records),'finite',len(finite),'maxgap',max(r['gap'] for r in finite),flush=True)
 return f

def main():
 p=argparse.ArgumentParser();p.add_argument('--states',required=True);p.add_argument('--out',default=str(ROOT/'thresholds'));p.add_argument('--eta',type=float,default=.01);p.add_argument('--workers',type=int,default=4);p.add_argument('--folds',nargs='*',type=int,default=list(range(10)));a=p.parse_args();out=Path(a.out);out.mkdir(exist_ok=True,parents=True);start=time.time()
 with ProcessPoolExecutor(max_workers=a.workers) as pool:list(pool.map(work,[(f,a.states,a.eta,str(out)) for f in a.folds]))
 print('elapsed',time.time()-start)
if __name__=='__main__':main()
