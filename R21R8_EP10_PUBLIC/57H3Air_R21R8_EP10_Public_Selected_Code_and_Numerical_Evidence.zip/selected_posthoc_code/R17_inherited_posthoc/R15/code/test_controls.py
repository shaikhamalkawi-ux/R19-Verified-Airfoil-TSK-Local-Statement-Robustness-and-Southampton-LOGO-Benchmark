"""Synthetic and basis controls. All are numerical checks, not new observations."""
from pathlib import Path
import json
import numpy as np
from scipy.linalg import block_diag,cho_factor,cho_solve
from joint_core import pointwise_bound,minimum_cost

ROOT=Path(__file__).resolve().parents[1]
def main():
 out=[]
 def test(name,ok,**kw):
  out.append(dict(check=name,passed=bool(ok),**kw));assert ok,(name,kw)
 P=np.eye(3);H=np.diag([2.,3.,4.]);J=2.
 for j in range(3):
  p=pointwise_bound(P,j,.1)
  test(f'identity_lp_{j}',abs(p['lower']-.1)<1e-12 and abs(p['upper']-.1)<1e-12)
  for target in [.01,-.05,.08]:
   q=minimum_cost(P,H,J,j,target,.1,initial=np.eye(3)[j]*target)
   test(f'identity_qp_{j}_{target}',q['status']=='optimal' and abs(q['cost']-H[j,j]*target**2/J)<1e-10)
   test(f'identity_dual_{j}_{target}',abs(q['cost']-q['dual_lower'])<1e-10)
 # A zero change budget excludes a nonzero coordinate only when estimable.
 dup=np.array([[1.,1.],[2.,2.]])
 p=pointwise_bound(dup,0,.1)
 test('duplicate_rule_unbounded_lp',p['status']=='3',status=p['status'])
 # Positive diagonal unit changes: solve the transformed optimization too.
 z=np.load(ROOT/'inputs/states/AIRFOIL_ONESE_fold00.npz',allow_pickle=False)
 P=z['P'];b=z['beta'];H=P.T@P/len(P)+float(z['lam'])*np.eye(P.shape[1]);yc=z['ytrain']-float(z['offset']);J=np.mean((yc-P@b)**2)+float(z['lam'])*(b@b)
 ws=np.load(ROOT/'results/AIRFOIL_ONESE_fold00_WITNESSES.npz',allow_pickle=False)
 # d_old=M*d_new, fixed penalty becomes M^T H M, not a new isotropic ridge.
 scales=np.tile(np.array([1.,.2,2.,.5,5.,.1]),int(z['R']));M=np.diag(scales)
 Hn=M.T@H@M;Pn=P@M;bn=b/scales
 for j in [1,2,3,4,5,7,8,9,10,11]:
  key=f'r{j//6:02d}_k{j%6}'
  old=pointwise_bound(P,j,.1);new=pointwise_bound(Pn,j,.1)
  test(f'unit_LP_bound_j{j}',abs(old['lower']-scales[j]*new['lower'])<3e-6)
  d=old['d'];dn=d/scales
  test(f'unit_point_predictions_j{j}',np.max(abs(P@d-Pn@dn))<1e-11)
  test(f'unit_ridge_form_j{j}',abs(d@H@d-dn@Hn@dn)<1e-10)
  if abs(b[j])*1.001<old['lower']*.95:
   target=-1.001*b[j]
   qo=minimum_cost(P,H,J,j,target,.1,old['d']*(target/old['lower']))
   qn=minimum_cost(Pn,Hn,J,j,target/scales[j],.1,new['d']*(target/scales[j]/new['lower']))
   test(f'unit_QP_solution_j{j}',qo['status']==qn['status']=='optimal')
   test(f'unit_QP_value_j{j}',abs(qo['cost']-qn['cost'])<1e-7)
 # Affine conversion to raw coordinates changes only intercept and scales slopes.
 mean=z['mean'];scale=z['scale'];C=np.zeros((6,6));C[0,0]=1.;C[0,1:]=mean;C[1:,1:]=np.diag(scale)
 C=block_diag(*([C]*int(z['R'])))
 Praw=P@C;Hraw=C.T@H@C;br=np.linalg.solve(C,b)
 test('raw_prediction_identity',np.max(abs(Praw@br-P@b))<1e-10)
 test('raw_ridge_form_identity',abs(br@Hraw@br-b@H@b)<1e-8)
 test('raw_slopes_same_sign',np.all(np.sign(br.reshape(-1,6)[:,1:])==np.sign(b.reshape(-1,6)[:,1:])))
 # Rule permutation: transport the entire question, not just coefficients.
 perm=np.arange(len(b)).reshape(-1,6)[::-1].ravel();d=np.arange(len(b))/len(b)
 test('permutation_prediction_identity',np.max(abs(P[:,perm]@d[perm]-P@d))<1e-11)
 test('permutation_objective_identity',abs(d[perm]@H[np.ix_(perm,perm)]@d[perm]-d@H@d)<1e-10)
 # Definition-level geometric identities on all stored directions.
 for f in sorted((ROOT/'results').glob('*_WITNESSES.npz')):
  x=np.load(f,allow_pickle=False);z=np.load(ROOT/'inputs/states'/f.name.replace('_WITNESSES',''),allow_pickle=False)
  for key in x.files:
   if key.endswith('_lp_d'):
    d=x[key];a=z['P']@d
    test(f'{f.stem}_{key}_budget_scaling',abs(np.max(abs(2*a))-2*np.max(abs(a)))<1e-12)
 report={'scope':'Synthetic controls and transported-unit/basis consistency; arbitrary changes of scientific coordinate are NOT claimed invariant','checks':len(out),'passed':sum(r['passed'] for r in out),'detail':out}
 (ROOT/'qa/SYNTHETIC_AND_INVARIANCE_CONTROLS.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({k:v for k,v in report.items() if k!='detail'},indent=2))
if __name__=='__main__':main()
