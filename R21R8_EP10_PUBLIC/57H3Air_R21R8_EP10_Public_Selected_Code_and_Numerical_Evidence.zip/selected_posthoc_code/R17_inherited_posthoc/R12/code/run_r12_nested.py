"""R12: post-hoc group-nested tuning and bijective aerodynamic coordinate sensitivity.

R9 and R11 are immutable historical baselines. This uses the frozen R10 fuzzy
clustering, firing and fitted-ridge functions, with a Gram eigen-solver for
inner candidate screening (validated against original augmented least squares).
R12 is NOT an independently preregistered experiment. Final outer losses are
never consulted to tune within an outer fold.
"""
from __future__ import annotations
import os,sys,math,time,json,hashlib,argparse,traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,pandas as pd
import scipy.linalg
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'inputs'/'R10_FROZEN_CODE'
sys.path.insert(0,str(SRC))
import controlled_rule_study as frozen
RSET=(2,4,6,8,10,12)
HSET=(0.75,1.0,1.5)
LSET=(1e-6,1e-4,1e-2,1.0,100.0)
REPS=('F5_LOG_F','F5_LOG_ST_DELTA','F5_LOG_K')
ONESE=True


def features(d,rep):
    f=d.frequency_Hz.to_numpy(float)
    alpha=d.angle_deg.to_numpy(float)
    c=d.chord_m.to_numpy(float)
    U=d.velocity_m_s.to_numpy(float)
    delta=d.displacement_m.to_numpy(float)
    if rep=='F5_LOG_F':t=np.log10(f)
    elif rep=='F5_LOG_ST_DELTA':t=np.log10(f*delta/U)
    elif rep=='F5_LOG_K':t=np.log10(np.pi*f*c/U)
    else:raise ValueError(rep)
    return np.column_stack([t,alpha,c,U,np.log10(delta)])


def recon_log_frequency(X,rep):
    t,aa,c,U,ld = X.T
    if rep=='F5_LOG_F':return t
    if rep=='F5_LOG_ST_DELTA':return t+np.log10(U)-ld
    if rep=='F5_LOG_K':return t+np.log10(U)-np.log10(c)-np.log10(np.pi)
    raise ValueError(rep)


def prepare(d,rep,ix):
    X=features(d,rep)
    scaler=StandardScaler().fit(X[ix]);Z=scaler.transform(X[ix]);return X,scaler,Z


def gram_screen(P,y,lamvals=LSET):
    n,q=P.shape
    ym=y.mean();yc=y-ym
    gram=(P.T@P)/n;rhs=P.T@yc/n
    eigvals,eigvecs=scipy.linalg.eigh(gram,check_finite=False)
    coeffs=eigvecs.T@rhs
    B=np.column_stack([eigvecs@(coeffs/(eigvals+lam)) for lam in lamvals])
    return B,ym,eigvals


def fit_with_h_lam(d,X,ix,R,h,lam):
    sub=X[ix];y=d.scaled_SPL_dB.to_numpy(float)[ix]
    scaler=StandardScaler().fit(sub);Z=scaler.transform(sub)
    fc,rec=frozen.fcm(Z,R)
    if fc is None:return None,rec
    C=fc['C'];S=fc['S']*h
    W=frozen.fire(Z,C,S)
    P=frozen.design(Z,W)
    beta=frozen.ridge_fit(P,y,lam)
    return {'scante':scaler,'sccons':scaler,'C':C,'S':S,'beta':beta,'targetmean':float(np.mean(y)),
            'R':R,'lambda':float(lam),'h':float(h),'fcmseed':fc['seed'],'fcmiters':fc['iters']},rec


def one_outer(d,rep,fold):
    start=time.time()
    y=d.scaled_SPL_dB.to_numpy(float);g=d.group_id.to_numpy(str)
    X=features(d,rep)
    split=list(GroupKFold(10).split(X,y,g));outer_tr,outer_te=split[fold]
    inner_parts=list(GroupKFold(5).split(X[outer_tr],y[outer_tr],g[outer_tr]))
    inner_parts=[(outer_tr[a],outer_tr[b]) for a,b in inner_parts]
    assert not set(g[outer_tr])&set(g[outer_te])
    unique_outer=np.unique(g[outer_tr]);unique_test=np.unique(g[outer_te]);
    assert len(unique_outer)+len(unique_test)==106
    rows=[];inner_fold_mse={};cached={};failed=[];solver_checks=[]
    for R in RSET:
        cv_pred={ (h,lam):{} for h in HSET for lam in LSET}
        cv_errors={ (h,lam):[] for h in HSET for lam in LSET}
        for inner_id,(tr,va) in enumerate(inner_parts):
            assert set(g[tr]).isdisjoint(set(g[va]))
            scal=StandardScaler().fit(X[tr]);Ztr=scal.transform(X[tr]);Zva=scal.transform(X[va]);
            fc,starts=frozen.fcm(Ztr,R)
            if fc is None:
                failed.append({'rep':rep,'outer_fold':fold,'R':R,'inner_fold':inner_id,'reason':'all fcm restarts failed','restarts':starts})
                continue
            C=fc['C'];baseS=fc['S'];
            for h in HSET:
                wtr=frozen.fire(Ztr,C,baseS*h);wva=frozen.fire(Zva,C,baseS*h)
                Ptr=frozen.design(Ztr,wtr);Pva=frozen.design(Zva,wva)
                B,offset,eigs=gram_screen(Ptr,y[tr])
                if fold==0 and inner_id==0 and h==1 and R in (2,10,12) and rep=='F5_LOG_F':
                    for lampos in (0,2,4):
                        exact=frozen.ridge_fit(Ptr,y[tr],LSET[lampos]);err=np.max(np.abs(B[:,lampos]-exact))
                        solver_checks.append({'R':R,'h':h,'lam':LSET[lampos],'coefficient_max_abs_error':float(err)})
                yp=Pva@B+offset
                for j,lam in enumerate(LSET):
                    k=(h,lam)
                    cv_errors[k].append(float(frozen.group_rmse(y[va],yp[:,j],g[va])))
                    for group in np.unique(g[va]):
                        sel=g[va]==group
                        sq=float(np.mean((y[va][sel]-yp[sel,j])**2))
                        assert group not in cv_pred[k]
                        cv_pred[k][group]=sq
        for h in HSET:
            for lam in LSET:
                k=(h,lam)
                if len(cv_pred[k])!=len(unique_outer):
                    inner_rmse=float('inf');sel='FAILED_INNER_FCM'
                else:
                    inner_rmse=float(np.sqrt(np.mean(list(cv_pred[k].values()))));sel='VALID'
                rows.append({'representation':rep,'outer_fold':fold,'R':R,'h':h,'lambda':lam,
                             'inner_Egrp_RMSE_dB':inner_rmse,
                             'inner_fold_RMSE_SD_dB':float(np.std(cv_errors[k],ddof=1)) if len(cv_errors[k])>=2 else None,
                             'inner_fold_RMSE_SE_dB':float(np.std(cv_errors[k],ddof=1)/np.sqrt(5)) if len(cv_errors[k])==5 else None,
                             'inner_group_count':len(cv_pred[k]),'inner_folds_completed':len(cv_errors[k]),'status':sel})
    cand=pd.DataFrame(rows)
    # choose best h and penalty for EACH R, without outer outcomes
    choice_by_R=[];outer_rows=[];oof_rows=[]
    for R in RSET:
        z=cand[(cand.R==R)&(cand.status=='VALID')].copy()
        if z.empty:
            failed.append({'rep':rep,'outer_fold':fold,'R':R,'reason':'NO_VALID_INNER_HYPERPARAMETERS'});continue
        z['h_tie']=abs(z.h-1);z['lam_tie']=abs(np.log10(z['lambda'])+2)
        z=z.sort_values(['inner_Egrp_RMSE_dB','h_tie','lam_tie','h','lambda'],kind='mergesort')
        best=z.iloc[0];h=float(best.h);lam=float(best['lambda'])
        choice_by_R.append({'R':R,'h':h,'lambda':lam,'inner_Egrp_RMSE_dB':float(best.inner_Egrp_RMSE_dB),
                            'inner_fold_RMSE_SE_dB':float(best.inner_fold_RMSE_SE_dB)})
        mod,restarts=fit_with_h_lam(d,X,outer_tr,R,h,lam)
        if mod is None:
            failed.append({'rep':rep,'outer_fold':fold,'R':R,'reason':'FULL_OUTER_FIT_FAILED','restarts':restarts});continue
        pred=frozen.infer(mod,X[outer_te],X[outer_te]); err=frozen.group_rmse(y[outer_te],pred,g[outer_te]);
        one={'representation':rep,'outer_fold':fold,'R':R,'h':h,'lambda':lam,
             'inner_Egrp_RMSE_dB':float(best.inner_Egrp_RMSE_dB),
             'inner_fold_RMSE_SE_dB':float(best.inner_fold_RMSE_SE_dB),
             'outer_fold_Egrp_RMSE_dB':err,'test_groups':len(unique_test),'train_groups':len(unique_outer),
             'test_rows':len(outer_te),'train_rows':len(outer_tr),'fit_fcm_seed':mod['fcmseed'],
             'fit_fcm_iters':mod['fcmiters'],'fit_q':len(mod['beta']), 'fit_success':True}
        outer_rows.append(one)
        for row_id,gname,y0,yhat in zip(d.row_id.to_numpy()[outer_te],g[outer_te],y[outer_te],pred):
            oof_rows.append({'representation':rep,'outer_fold':fold,'R':R,'row_id':int(row_id),
                             'group_id':gname,'actual_SPL_dB':float(y0),'pred_SPL_dB':float(yhat),'error_dB':float(yhat-y0)})
    # choose min-CV / one-SE within full six rule-count grid. These are SE on five dependent CV folds.
    choices=pd.DataFrame(choice_by_R)
    valid=choices[choices.R.isin([r['R'] for r in outer_rows])].copy()
    if valid.empty:raise RuntimeError('NO_VALID_OUTER_FIT')
    best=valid.sort_values(['inner_Egrp_RMSE_dB','R']).iloc[0]
    b_threshold=float(best['inner_Egrp_RMSE_dB']+best['inner_fold_RMSE_SE_dB'])
    eligible=valid[valid.inner_Egrp_RMSE_dB<=b_threshold+1e-12]
    onese=eligible.sort_values(['R','inner_Egrp_RMSE_dB']).iloc[0]
    selected={'MIN_ERROR':int(best.R),'ONE_SE':int(onese.R)}
    output={'representation':rep,'fold':fold,'input_sha256':hashlib.sha256((ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').read_bytes()).hexdigest(),
            'outer_train_groups':len(unique_outer),'outer_test_groups':len(unique_test),
            'outer_train_group_ids':unique_outer.tolist(),'outer_test_group_ids':unique_test.tolist(),
            'R_choices':choice_by_R,'one_SE_cutoff_inner_RMSE_dB':b_threshold,'selected':selected,
            'failures':failed,'screen_solver_checks':solver_checks,'duration_seconds':time.time()-start}
    path=ROOT/'results'/'per_fold';path.mkdir(exist_ok=True,parents=True)
    stem=f'{rep}_fold{fold:02d}'
    cand.to_csv(path/f'{stem}_candidates.csv',index=False,float_format='%.15g')
    pd.DataFrame(outer_rows).to_csv(path/f'{stem}_outer_R.csv',index=False,float_format='%.15g')
    pd.DataFrame(oof_rows).to_csv(path/f'{stem}_oof.csv',index=False,float_format='%.15g')
    (path/f'{stem}_trace.json').write_text(json.dumps(output,indent=2,allow_nan=False))
    return {'rep':rep,'fold':fold,'seconds':round(time.time()-start,2),'inner_candidates':len(cand),'outer_success':len(outer_rows),'failures':len(failed),
            'ONE_SE_R':selected['ONE_SE'],'MIN_ERROR_R':selected['MIN_ERROR']}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=3)
    ap.add_argument('--representations',nargs='+',default=list(REPS),choices=list(REPS))
    ap.add_argument('--folds',type=int,nargs='+',default=list(range(10)))
    args=ap.parse_args()
    d=pd.read_csv(ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').sort_values('row_id').reset_index(drop=True)
    assert len(d)==1503 and d.group_id.nunique()==106
    assert len(d.row_id.unique())==1503 and not d.isna().any().any()
    for rep in REPS:
        X=features(d,rep)
        assert np.isfinite(X).all()
        assert np.max(abs(recon_log_frequency(X,rep)-np.log10(d.frequency_Hz.to_numpy(float))))<1e-12
    jobs=[(rep,fold) for rep in args.representations for fold in args.folds]
    st=time.time();state=[];error=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        fut={pool.submit(_worker,job):job for job in jobs}
        for f in as_completed(fut):
            job=fut[f]
            try:
                r=f.result();state.append(r)
                print('R12 DONE',r,'overall elapsed',round(time.time()-st,1),'completed',len(state),'/',len(jobs),flush=True)
            except Exception:
                error.append({'job':job,'traceback':traceback.format_exc()});print('R12 ERROR',job,traceback.format_exc(),flush=True)
    (ROOT/'qa'/'R12_RUN_STATUS.json').write_text(json.dumps({'jobs':jobs,'completed':state,'errors':error,'time_s':time.time()-st,
          'settings':{'R':RSET,'h':HSET,'lambda':LSET,'representations':REPS,'outer_cv':10,'inner_cv':5,
                     'training_group_key':'(angle,chord,velocity)','screening_solver':'symmetric eigendecomposition of Gram plus positive ridge',
                     'final_fit_solver':'frozen R10 augmented least squares','one_SE':'minimum inner-Egrp winner fold-RMSE SE, smallest R within band'}},indent=2))
    if error:raise RuntimeError(f'{len(error)} R12 fold failures')

def _worker(job):
    rep,fold=job
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=1):
        d=pd.read_csv(ROOT/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').sort_values('row_id').reset_index(drop=True)
        return one_outer(d,rep,fold)

if __name__=='__main__':main()
