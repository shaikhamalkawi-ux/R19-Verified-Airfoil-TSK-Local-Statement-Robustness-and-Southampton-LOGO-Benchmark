# R17 external-geometry methodological replication

Public source: University of Southampton dataset DOI 10.5258/SOTON/398169, Creative Commons Attribution. Related study: Lau et al., Wind Energy 20(2):233-252, DOI 10.1002/we.2003.

The exact admitted `DataFiles.zip` is included here with SHA-256 recorded in `qa/SOURCE_ADMISSION.json`. Only experimental blocks from source Figures 3-14 are admitted; BPM/TNO prediction columns are not observations and are excluded by `code/extract_southampton.py`.

Primary external scope: four geometries with eight complete spectra each: RisoB1-15, RisoB1-18, Aerofoil-18 and Aerofoil-21. Each geometry is fitted separately; there is no NASA-to-Southampton coefficient transfer and no claim of prediction on an unseen geometry.

Run record checks with `python code/verify_external.py`. Parent NPZ states and the sensitivity witness are supplied in Additional file 3, not duplicated here.
