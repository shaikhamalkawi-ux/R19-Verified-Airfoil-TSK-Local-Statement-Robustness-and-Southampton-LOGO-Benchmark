# Additional file 3 - fitted parent states and coefficient witnesses

Contains the frozen NASA parent/witness arrays inherited from R16 plus the 16 selected Southampton external parent states and the recorded doubled-budget RisoB1-18 witness used in R17. These arrays support direct numerical verification of constrained model alternatives; they are not new measurements or independent experiments.
