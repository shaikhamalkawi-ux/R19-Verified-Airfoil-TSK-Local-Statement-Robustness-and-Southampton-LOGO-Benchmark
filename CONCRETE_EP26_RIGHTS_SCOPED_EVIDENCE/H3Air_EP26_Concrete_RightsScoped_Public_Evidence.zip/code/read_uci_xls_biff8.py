"""Minimal, stdlib-only OLE2/BIFF8 numeric cell extractor for original UCI Concrete_Data.xls.
This is deliberately scoped to this immutable raw source; not a general Excel reader.
"""
from pathlib import Path
import struct, collections

FREE=0xffffffff
END=0xfffffffe

def parse_ole_workbook(path):
    buf=Path(path).read_bytes()
    if buf[:8] != bytes.fromhex('d0cf11e0a1b11ae1'):
        raise ValueError('Invalid compound file header')
    secsize=1<<struct.unpack_from('<H',buf,30)[0]
    assert secsize==512
    fat_count=struct.unpack_from('<I',buf,44)[0]
    first_dir=struct.unpack_from('<I',buf,48)[0]
    fat_sectors=[i for i in struct.unpack_from('<109I',buf,76) if i!=FREE]
    assert len(fat_sectors)==fat_count
    def read_sec(s):
        assert s<len(buf)//secsize, (s,len(buf),secsize)
        return buf[(s+1)*secsize:(s+2)*secsize]
    fat=[]
    for sec in fat_sectors: fat.extend(struct.unpack('<128I',read_sec(sec)))
    def follow(first,maxlen=20000):
        out=b'';s=first;seen=set()
        while s != END:
            if s in seen or len(seen)>=maxlen: raise RuntimeError('FAT cycle/limit')
            seen.add(s);out+=read_sec(s);s=fat[s]
        return out
    dirt=follow(first_dir)
    streams={}
    for idx in range(len(dirt)//128):
        e=dirt[idx*128:(idx+1)*128]
        name_chars=struct.unpack_from('<H',e,64)[0]
        if not 2<=name_chars<=64: continue
        name=e[:name_chars-2].decode('utf-16le')
        typ=e[66]
        first=struct.unpack_from('<I',e,116)[0]
        length=struct.unpack_from('<Q',e,120)[0]
        print('OLE ENTRY',idx,repr(name),'type',typ,'start',first,'len',length)
        if typ==2 and name.lower() in ('workbook','book'):
            assert length>=4096,'mini stream not supported'
            streams[name]=follow(first)[:length]
    assert len(streams)==1,streams.keys()
    return next(iter(streams.values()))

def records(workbook,offset):
    while offset+4<=len(workbook):
        r_id,length=struct.unpack_from('<HH',workbook,offset)
        start=offset+4
        end=start+length
        if end>len(workbook): raise RuntimeError((r_id,length,offset,len(workbook)))
        yield r_id,workbook[start:end],offset
        offset=end
        if r_id==0x000A: break

def decode_rk(raw):
    is_integer=bool(raw&2)
    if is_integer:
        signed=struct.unpack('<i',struct.pack('<I',raw))[0]
        number=signed>>2
    else:
        number=struct.unpack('<d',struct.pack('<Q',(raw&0xfffffffc)<<32))[0]
    if raw&1: number/=100.0
    return float(number)

def parse_numeric_cells(workbook):
    global_recs=list(records(workbook,0))
    sheets=[]
    for rid, payload, _ in global_recs:
        if rid==0x0085:
            pos=struct.unpack_from('<I',payload,0)[0]
            n=payload[6]
            highbyte=payload[7]&1
            name=payload[8:8+n*(2 if highbyte else 1)].decode('utf-16le' if highbyte else 'latin-1')
            sheets.append((name,pos))
    print('WORKBOOK',len(workbook),'GLOBAL RECORDS',len(global_recs),'SHEETS',sheets)
    result={}
    for name,pos in sheets:
        numeric={}
        counts=collections.Counter()
        for rid,v,roffset in records(workbook,pos):
            counts[f'{rid:04x}']+=1
            if rid==0x0203: # NUMBER
                row,col=struct.unpack_from('<HH',v,0)
                numeric[(row,col)]=struct.unpack_from('<d',v,6)[0]
            elif rid==0x027e: # RK
                row,col=struct.unpack_from('<HH',v,0)
                numeric[(row,col)]=decode_rk(struct.unpack_from('<I',v,6)[0])
            elif rid==0x00bd: # MULRK
                row,col=struct.unpack_from('<HH',v,0)
                col_last=struct.unpack_from('<H',v,len(v)-2)[0]
                assert col_last-col+1==(len(v)-6)//6
                for i,c in enumerate(range(col,col_last+1)):
                    numeric[(row,c)]=decode_rk(struct.unpack_from('<I',v,4+6*i+2)[0])
            elif rid==0x0006: # FORMULA
                row,col=struct.unpack_from('<HH',v,0)
                # BIFF's 'non-numeric cached result' begins with 0xFFFF in final two bytes
                result=v[6:14]
                if result[6:8]!=b'\xff\xff':
                    numeric[(row,col)]=struct.unpack('<d',result)[0]
        print('SHEET',name,'record types',counts,'numeric',len(numeric),
              'columns',sorted(set(x[1] for x in numeric)),
              'first 12',list(numeric.items())[:12])
        result[name]=numeric
    return result

if __name__=='__main__':
    w=parse_ole_workbook('/mnt/data/Concrete_Data.xls')
    s=parse_numeric_cells(w)
    print('n sheets',len(s))
