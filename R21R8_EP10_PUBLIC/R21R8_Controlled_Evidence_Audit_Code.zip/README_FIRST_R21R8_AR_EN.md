# START HERE — Project 57 H3Air R21R8 / IEEE Access reviewer revision
Date: 22 November 2026. Status: **AUTHOR REVIEW; NOT SUBMITTED TO IEEE ACCESS**.

## Provenance
- Old locked R21R7 manuscript: unchanged in its old folder.
- Active scientific/reviewer-stage candidate: **R21R8_Full28k_ReplayClosure**.
- Submission ID Access-2026-52679, original decision 17 November 2026. One resubmission opportunity.
- Drive author-review delivery folder: https://drive.google.com/drive/folders/1vwG8EWjo5TfpCmmcF0zIQZBlePIz5fTH
- Controlled 40 new-fitted-state per-task ZIPs (40 ZIP + 40 JSON): https://drive.google.com/drive/folders/19GWKnAILzKskIM_UYhNQmhj9Xkx0D3JO
- Current official UCI raw NASA file and numeric-source audit: https://drive.google.com/drive/folders/1CvGAme-CirkCfMtb_HJC1e8tueYm6Wdg
- Controlled R5 source-data input archive already in R21R7 project Drive folder.

## The newly admitted software evidence
- All 40 bootstrap tasks were **newly replayed**, 28,000/28,000 attempted fits: 27,998 fitted-state files saved and 2 unchanged historical fitting nonconvergences.
- Independent source-vs-replayed-state audit: 40/40 PASS; exact attempts and seed identities; 27,998/27,998 internal-state SHA-256 PASS; all R5 outputs compared within atol=1e-7, rtol=1e-9.
- Maximum absolute differences: predictions 1.2573764252010733e-10; aligned coefficients 1.469743438065052e-08; similarity 1.8485213360008856e-14.
- Two historical failures: F5 fold00 compact relearn141; F5 fold02 reference relearn115. The failure identities were never substituted.
- Raw *current official* UCI source bytes 59,984, SHA-256 74c75fd71783f1e6b71f8a622b993dc592897a97cd689c5090a07147a1b097b3. All 9,018 cells in 1,503 rows matched R5 at tolerance 1e-12; 106 groups, row order unchanged.

## What this does NOT prove
The current official raw UCI download is **not** the original first-acquired October 2026 file, and does not establish its historical checksum. The newly saved 27,998 internal fitted states are NEW reconstruction objects, not the unarchived original October state bytes. This is numeric/software reproducibility evidence, not new acoustic experiments, physical generalization, or an independently calibrated SPL measurement-uncertainty estimate.

## Which files do what
- `R21R8_Manuscript_CLEAN_AUTHOR_REVIEW.pdf` (19 pages), `R21R8_Supplementary_AUTHOR_REVIEW.pdf` (25 pages, S28 new), `R21R8_Main_PLUS_Supplement_AUTHOR_REVIEW.pdf` (44 pages).
- `R21R8_Manuscript_HIGHLIGHTED_From_R20R4_AUTHOR_REVIEW.pdf` (19 pages, yellow line highlights; page reflow may cause overly broad marks, author visual signoff pending).
- `R21R8_Full_Verbatim_Response_to_16_Reviewers_AUTHOR_REVIEW.docx` & PDF (13 pages), all 16 comments and verbatim reviewer concerns.
- `R21R8_Overleaf_Source_AUTHOR_REVIEW.zip` (35 source assets, clean builds).
- `R21R8_Independent_Evidence_Closure_Report.pdf` (2 pages) & DOCX, `R21R8_FULL40_Completion_Certificate.json`, `R21R8_Independent_Full28k_QA.json`, `R21R8_40Task_Archive_SHA256SUMS.txt`.
- `verify_R21R8_all40_portable.py` independently reads 40 task ZIPs and the original R5 archive, not the replay generator; a one-task test on index4 PASS.

## Journal-stage author gates still open
1. Original October 2026 UCI source bytes/historical SHA unavailable (truthful disclosure in manuscript).
2. Author-approved public code reuse licence, third-party material rights, privacy/reviewer-access plan, published permanent Zenodo DOI pending. Do not publish full internal source ZIP or third-party publisher PDFs.
3. All six author approvals / declarations / CRediT / ORCID and any journal-required AI disclosure; approved corresponding-author metadata.
4. Yellow-highlighted revised PDF must receive author visual/line-by-line approval; generic IEEE template has existing overfull-box build messages.
5. Do not press IEEE Access resubmission until the author/journal-side gates close. No article or data package was published or submitted here.

## Delivery advice
Use `R21R8_IEEEAccess_AuthorReview_CANDIDATE_DO_NOT_UPLOAD.zip` only as a review candidate; its filenames can be normalized for the portal AFTER author approval. Keep the 773MB/40 ZIP new-fitted-state evidence in controlled Drive storage, not inside the journal upload bundle. `R21R8_NewChat_Transfer.zip` and `NEWCHAT_HANDOFF_R21R8_AR_EN.md` preserve the exact continuation point.
