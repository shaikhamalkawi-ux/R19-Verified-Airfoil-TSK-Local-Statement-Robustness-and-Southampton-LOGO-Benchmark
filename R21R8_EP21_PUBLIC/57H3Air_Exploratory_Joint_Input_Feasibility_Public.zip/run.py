#!/usr/bin/env python3
"""Post-review diagnostic: joint finite-input feasibility on frozen NASA parent fits.
Not independent transport: held-out feature inputs enter the new optimization; held-out labels never used.
Usage: python run.py /path/to/extracted/AF4/direct_derivative/inputs --out results
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,json,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from scipy.linalg import cholesky,solve_triangular
from scipy.special import softmax
from solver import solve as solve_ball
from scipy.optimize import linprog
from concurrent.futures import ProcessPoolExecutor

EPS=.1; ETA=.01; TOL=5e-8

def process(args):
 src,fold,tab,out=args
 z=np.load(src/'states'/f'AIRFOIL_ONESE_fold{fold:02}.npz',allow_pickle=False)
 w=np.load(src/'witnesses'/f'AIRFOIL_ONESE_fold{fold:02}_WITNESSES.npz',allow_pickle=False)
 P,Pt,b=z['P'],z['Pt'],z['beta']; n,q=P.shape; U=np.vstack([P,Pt]); lam=float(z['lam']);y=z['ytrain']-float(z['offset']);H=P.T@P/n+lam*np.eye(q);J=np.mean((y-P@b)**2)+lam*b@b
 assert np.max(abs(H@b-P.T@y/n))<1e-9
 # Rebuild both design matrices from saved scaled features and Gaussian premise parameters.
 for T,design in [(z['T'],P),(z['Tt'],Pt)]:
  W=softmax(-.5*np.sum(((T[:,None,1:]-z['C'])/z['S'])**2,axis=2),axis=1)
  assert np.max(abs((W[:,:,None]*T[:,None,:]).reshape(design.shape)-design))<1e-10
 M=solve_triangular(cholesky(H,lower=True).T,np.eye(q)); G=np.linalg.solve(H,np.eye(q));G=(G+G.T)/2
 records=[]; evidence={}
 def bound_and_check(a,scale,stem):
  c=-a/(scale*float(a@b)); v=G@c; K=c@v;d0=v/K;room=ETA*J-1/K
  # First solve the prediction-only minimax LP. Its dual remains a valid lower bound
  # on the smaller objective-bounded feasible set. If the LP witness also satisfies
  # the objective cap, no second optimization is needed.
  nn=len(U)
  lp=linprog(np.r_[np.zeros(q),1.],A_ub=np.column_stack([np.vstack([U,-U]),-np.ones(2*nn)]),b_ub=np.zeros(2*nn),A_eq=np.r_[c,0.][None,:],b_eq=[1.],bounds=[(None,None)]*q+[(0,None)],method='highs',options={'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8})
  assert lp.success,(fold,stem,lp.message)
  d=lp.x[:-1]; dual=-lp.ineqlin.marginals; uu=dual[:nn]-dual[nn:];uu/=max(1.,sum(abs(uu)));ix=np.flatnonzero(uu);u=uu[ix]
  if d@H@d/J>ETA:
   # Interpolate toward the objective-minimum crossing vector to obtain an upper bound.
   h=d-d0;d=d0+h*min(1.,np.sqrt(room*(1-1e-9)/(h@H@h)))
  d+=d0*(1-c@d)
  rr={'status':'BRACKETED'}
  ad=U[ix].T@u; proj=G@ad-v*(c@G@ad)/K
  rawlo=ad@d0-np.sqrt(room)*np.sqrt(max(0,proj@H@proj)); rawup=max(abs(U@d));guard=1e-9*max(1,abs(rawlo),rawup)
  lo=max(0,rawlo-guard);up=rawup+guard
  actual=(np.mean((y-P@(b+d))**2)+lam*((b+d)@(b+d))-J)/J
  if lo<=EPS<=up:
   # Only call the inherited ellipsoid solver when the LP bounds do not resolve
   # the decision. A wide valid bracket is retained as unresolved, never guessed.
   alt,dd,ii,uu=solve_ball(U,b*scale,H,J,M,a,ETA)
   if alt['status']=='BRACKETED':
    if alt['upper']<up:d=dd;up=alt['upper']
    if alt['lower']>lo:ix,u=ii,uu;lo=alt['lower']
   ad=U[ix].T@u;proj=G@ad-v*(c@G@ad)/K
   rawlo=ad@d0-np.sqrt(room)*np.sqrt(max(0,proj@H@proj));rawup=max(abs(U@d));guard=1e-9*max(1,abs(rawlo),rawup);lo=max(0,rawlo-guard);up=rawup+guard
   actual=(np.mean((y-P@(b+d))**2)+lam*((b+d)@(b+d))-J)/J
  assert lo<=up and abs(c@d-1)<1e-9 and abs(actual-d@H@d/J)<1e-9 and actual<=ETA+1e-10 and sum(abs(u))<=1+1e-12
  rr.update(lower=float(lo),upper=float(up))
  for k,vv in [('d',d),('ix',ix),('u',u)]: evidence[f'{stem}_{k}']=vv
  return rr,d,actual
 for row in tab.itertuples(index=False):
  r,k,j=int(row.rule),int(row.feature_index),int(row.j);stem=f'r{r:02}_k{k}'
  d=w[f'{stem}_eps0.1_g0.001_d'];train=float(max(abs(P@d)));test=float(max(abs(Pt@d)));cost=float(d@H@d/J)
  assert abs(test-row.max_heldout_change)<2e-8 and abs(train-row.max_training_change)<2e-8 and abs(b[j]+d[j]+.001*b[j])<1e-8 and cost<=ETA+TOL and train<=EPS+TOL
  rec=dict(fold=fold,rule=r,feature_index=k,feature=row.feature,j=j,baseline=float(b[j]),old_train=train,old_test=test,old_cost=cost,old_retained=bool(test<=EPS+TOL),status='ORIGINAL_WITNESS_RETAINED' if test<=EPS+TOL else 'UNRESOLVED',zero_lower=None,zero_upper=None,margin_lower=None,margin_upper=None,new_train=None,new_test=None,new_cost=None,new_coefficient=None)
  if not rec['old_retained']:
   a=np.eye(q)[j]
   rr,dz,actual=bound_and_check(a,1.,stem+'_zero')
   rec.update(zero_lower=rr['lower'],zero_upper=rr['upper'])
   if rr['lower']>EPS:
    rec['status']='JOINT_ZERO_EXCLUDED'
   elif rr['upper']<EPS:
    # Try the original 0.001-relative strict target, not a different post hoc margin.
    rm,dm,ac=bound_and_check(a,1.001,stem+'_margin')
    rec.update(margin_lower=rm['lower'],margin_upper=rm['upper'])
    if rm['upper']<EPS and ac<=ETA+1e-10 and float(b[j]*(b[j]+dm[j]))<0:
     rec.update(status='JOINT_ORIGINAL_MARGIN_WITNESS',new_train=float(max(abs(P@dm))),new_test=float(max(abs(Pt@dm))),new_cost=float(ac),new_coefficient=float(b[j]+dm[j]));evidence[stem+'_strict']=dm
    else:
     # If the original margin cannot be certified, keep a strict witness with a smaller positive margin if feasible.
     c=-a/float(a@b);v=G@c;K=c@v;d0=v/K
     gap=EPS-max(abs(U@dz));mix=min(.5,gap/(4*max(abs(U@(d0-dz)))+1e-30));x=(1-mix)*dz+mix*d0;x+=d0*(1-c@x)
     q0=x@H@x/J;p0=max(abs(U@x));step=min(.001,(EPS/p0-1)/2,(np.sqrt(ETA/q0)-1)/2)
     if step>1e-10:
      x*=1+step;ac=(np.mean((y-P@(b+x))**2)+lam*((b+x)@(b+x))-J)/J
      assert max(abs(U@x))<EPS and ac<ETA and b[j]*(b[j]+x[j])<0
      rec.update(status='JOINT_SMALLER_MARGIN_WITNESS',new_train=float(max(abs(P@x))),new_test=float(max(abs(Pt@x))),new_cost=float(ac),new_coefficient=float(b[j]+x[j]));evidence[stem+'_strict']=x
   print(fold,stem,rec['status'],rec['zero_lower'],rec['zero_upper'],flush=True)
  records.append(rec)
 np.savez_compressed(out/f'fold{fold:02d}_new_evidence.npz',**evidence)
 return records

def main():
 p=argparse.ArgumentParser();p.add_argument('inputs',type=Path);p.add_argument('--out',type=Path,default=Path('results'));args=p.parse_args();args.out.mkdir(exist_ok=True,parents=True)
 t=pd.read_csv(args.inputs/'RESOLVED_510_STATEMENTS.csv');t=t[(t.epsilon==EPS)&(t.gamma==.001)&(t.final_class=='FEASIBLE_REVERSAL')];assert len(t)==107
 with ProcessPoolExecutor(max_workers=4) as pool:
  records=sum(list(pool.map(process,[(args.inputs,f,t[t.fold==f],args.out) for f in range(10)])),[])
 d=pd.DataFrame(records).sort_values(['fold','rule','feature_index']);assert len(d)==107 and d.old_retained.sum()==69
 d.to_csv(args.out/'joint_transport_audit.csv',index=False)
 s={'status':'PASS','scope':'post hoc frozen-premise joint observed training+held-out INPUT feasibility; no held-out targets; not prospective transport or a new measurement campaign','original_witness_count':107,'original_witness_retained':int(d.old_retained.sum()),'original_witness_failed':int((~d.old_retained).sum()),'old_max_heldout_change_dB':float(d.old_test.max()),'outcomes':d.status.value_counts().to_dict(),'input_sha256':{str(f.relative_to(args.inputs)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(args.inputs.rglob('*')) if f.is_file()}}
 (args.out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items() if k!='input_sha256'},indent=2))
if __name__=='__main__':main()
