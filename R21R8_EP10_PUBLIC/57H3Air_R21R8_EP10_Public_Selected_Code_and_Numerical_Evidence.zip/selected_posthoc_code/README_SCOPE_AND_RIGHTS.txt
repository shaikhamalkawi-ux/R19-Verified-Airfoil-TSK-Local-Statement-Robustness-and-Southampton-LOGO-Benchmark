57 H3Air EP9 | Additional File 2 | REVIEWER EVIDENCE ONLY
Scope: Selected earlier post hoc code and scalar records.
Historical basis: H3_R20_Executed_Exploratory_Research_Archive_20261013.zip, source_R18.
Preserved source files are unmodified; see MANIFEST_SHA256.json for each exact hash.
The complete historical 28,000-attempt and newly reconstructed 27,998-state archives are NOT included.
This is NOT a licensed public source release, Zenodo DOI or newly executed experiment.
The current NASA source is at 10.24432/C5VW2C; Southampton 10.5258/SOTON/398169.
No author-owned software licence has been approved here; review and redistribution permissions remain to be verified.
Do not treat these selected states as originally recovered historical 28,000 per-draw state bytes.
