"""R12 paired fixed OOF conditional reweighting of alternative representations at the SAME R.
No retraining, no physical-causation or independent-experiment claims.
"""
from pathlib import Path
import numpy as np,pandas as pd
root=Path(__file__).resolve().parents[1]
full=pd.read_csv(root/'results'/'R12_ALL_OOF_PREDICTIONS_BY_R.csv')
RSET=[2,4,6,8,10,12]
reps=['F5_LOG_ST_DELTA','F5_LOG_K']
rng=np.random.default_rng(12021101)
rows=[]
for alt in reps:
    for R in RSET:
        base=full[(full.representation=='F5_LOG_F')&(full.R==R)]
        a=full[(full.representation==alt)&(full.R==R)]
        gb=base.assign(sq=(base.actual_SPL_dB-base.pred_SPL_dB)**2).groupby('group_id').sq.mean().sort_index()
        ga=a.assign(sq=(a.actual_SPL_dB-a.pred_SPL_dB)**2).groupby('group_id').sq.mean().sort_index()
        complete=len(ga)==106 and len(gb)==106 and list(ga.index)==list(gb.index)
        if not complete:
            rows.append({'alternative_representation':alt,'R':R,'comparison_complete':False,'common_groups':len(set(ga.index)&set(gb.index)),
                          'RMSE_delta_alt_minus_baseline_dB':None,'p2p5_fixedOOF_conditional':None,'p97p5_fixedOOF_conditional':None,
                          'alt_group_MSE_lower':None})
            continue
        x=ga.to_numpy();y=gb.to_numpy();ii=rng.integers(0,106,size=(5000,106))
        diff=np.sqrt(x[ii].mean(axis=1))-np.sqrt(y[ii].mean(axis=1))
        rows.append({'alternative_representation':alt,'R':R,'comparison_complete':True,'common_groups':106,
                      'RMSE_delta_alt_minus_baseline_dB':float(np.sqrt(x.mean())-np.sqrt(y.mean())),
                      'p2p5_fixedOOF_conditional':float(np.quantile(diff,.025)),
                      'p97p5_fixedOOF_conditional':float(np.quantile(diff,.975)),
                      'alt_group_MSE_lower':int(np.sum(x<y))})
p=pd.DataFrame(rows);p.to_csv(root/'results'/'R12_FIXED_R_CONDITIONAL_PAIRED_SENSITIVITIES.csv',index=False)
print(p.to_string(index=False))
