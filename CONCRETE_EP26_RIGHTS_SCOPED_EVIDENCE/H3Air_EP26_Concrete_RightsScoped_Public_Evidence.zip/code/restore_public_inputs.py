"""Fetch pinned mirror inputs directly; restore excluded state arrays without fitting.
Run in an extracted working copy. Fail closed on unexpected bytes.
"""
import csv, hashlib, io, json, urllib.request
from decimal import Decimal
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
R=Path(__file__).resolve().parents[1]
lineage=json.loads((R/'provenance/R20_mirror_lineage.json').read_text())
recovery=json.loads((R/'provenance/recovery.json').read_text())
header='Cement,BlastFurnaceSlag,FlyAsh,Water,Superplasticizer,CoarseAggregate,FineAggregate,Age,ConcreteCompressiveStrength'.split(',')
sha=lambda b:hashlib.sha256(b).hexdigest()
urls={'high':('https://raw.githubusercontent.com/adaa-polsl/RuleKit/3ff3f49a0939400e51de65bc29f01e77085f1526/data/contrast-sets/regression/compressive.arff','highprecision_git_blob_sha','Concrete_RuleKit_HighPrecision1030.csv'),'rounded':('https://raw.githubusercontent.com/CaroFuchs/pyFUME/5df2b70dbd9cca5641e93b0e70ada17955323c61/Examples/Concrete_data.csv','rounded_git_blob_sha','Concrete_pyFUME_Rounded1030.csv')}
def number(s):
 d=Decimal(s.strip()); return format(d.normalize(),'f') if d else '0'
for kind,(url,blob,filename) in urls.items():
 raw=urllib.request.urlopen(url,timeout=90).read(); assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==lineage[blob],url
 text=raw.decode('utf-8-sig'); lines=text.splitlines(); start=next(i for i,l in enumerate(lines) if l.strip().lower()=='@data')+1 if kind=='high' else 1
 rows=[row[:9] for row in csv.reader(lines[start:]) if row and not row[0].lstrip().startswith('%')]; assert len(rows)==1030 and all(len(r)==9 for r in rows)
 out=io.StringIO(newline=''); w=csv.writer(out,lineterminator='\r\n');w.writerow(header);w.writerows([number(v) for v in row] for row in rows); b=out.getvalue().encode(); assert sha(b)==recovery['input_hashes'][filename],('normalized source hash mismatch',filename,sha(b))
 (R/'data'/filename).write_bytes(b)
manifest=json.loads((R/'PUBLIC_PROJECTION_MANIFEST.json').read_text())
for record in manifest['source_state_projection_records']:
 p=R/record['public_projection']; assert sha(p.read_bytes())==record['projection_sha256']; kind=p.parent.name.split('_')[0]; arr=np.loadtxt(R/'data'/urls[kind][2],delimiter=',',skiprows=1)
 with np.load(p,allow_pickle=False) as a: d={k:a[k] for k in a.files}
 d.update(Xtrain=arr[d['tr'],:8],Xtest=arr[d['te'],:8],ytrain=arr[d['tr'],8],ytest=arr[d['te'],8])
 def design(x):
  zz=(x-d['mean'])/d['scale'];l=-.5*(((zz[:,None,:]-d['C'])/d['S'])**2).sum(2);w=np.exp(l-logsumexp(l,axis=1,keepdims=True));return (w[:,:,None]*np.c_[np.ones(len(zz)),zz][:,None,:]).reshape(len(zz),-1)
 d.update(P=design(d['Xtrain']),Pt=design(d['Xtest'])); np.savez_compressed(R/record['original_path'],**d)
print('Pinned input hashes verified; projected states rehydrated without refitting.')
