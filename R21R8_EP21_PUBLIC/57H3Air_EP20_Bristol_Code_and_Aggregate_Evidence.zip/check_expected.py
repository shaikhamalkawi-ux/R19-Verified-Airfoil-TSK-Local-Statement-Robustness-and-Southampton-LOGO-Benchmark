#!/usr/bin/env python3
"""Check newly reproduced aggregate files, not substitute expected values for actual outputs."""
from pathlib import Path
import argparse,json
import pandas as pd
p=argparse.ArgumentParser();p.add_argument('--results',type=Path,required=True);a=p.parse_args()
e=Path(__file__).resolve().parent/'expected'
for n in ['classification_summary.csv','prediction_summary.csv','fold_QA.csv']:
    pd.testing.assert_frame_equal(pd.read_csv(e/n),pd.read_csv(a.results/n),check_exact=False,rtol=1e-10,atol=1e-10)
q=json.loads((a.results/'independent_QA.json').read_text());r=json.loads((e/'independent_QA.json').read_text())
for k in ['status','source_sha1_matches','rows','spectra','outer_folds','inner_folds','budget_statement_tests','original_strict_witnesses','all_training_classifications_resolved','all_joint_classifications_resolved']:
    assert q[k]==r[k],k
assert q['status']=='PASS'
print('PASS: all expected classifications, RMSEs, fold coverage and verification counts match.')
