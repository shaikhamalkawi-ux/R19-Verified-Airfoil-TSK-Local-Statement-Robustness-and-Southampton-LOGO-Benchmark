#!/usr/bin/env python3
"""Recomputable cross-domain exploratory grouped CV (not frozen R19 science).
Dataset option is a pinned *mirror*, not an independently downloaded official UCI XLS.
Model selections are training-only; held-out mixtures never affect tuning.
"""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
 os.environ[name]='1'
import argparse, csv, json, time, hashlib
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from scipy.linalg import lstsq, eigh
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GroupKFold
from sklearn.ensemble import ExtraTreesRegressor
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[1]
DATASETS={'high':'Concrete_RuleKit_HighPrecision1030.csv','rounded':'Concrete_pyFUME_Rounded1030.csv','official':'Concrete_UCI_Official_1030x9.csv'}
RGRID=(2,4,6);HGRID=(.75,1.,1.5); LGRID=(1e-4,1e-2,1.)
FCM_SEEDS=(11,23,47);FCM_MAXITER=2000;FCM_TOL=1e-6;FCM_FLOOR=.05
ET_MF=(.5,.75,1.);ET_LEAF=(1,2,4,8); ET_ESTIMATORS=160; ET_SEED=23

def read_csv(path):
 with path.open() as f:
  rows=list(csv.reader(f))
 assert len(rows)==1031 and len(rows[0])==9
 arr=np.asarray([list(map(float,x)) for x in rows[1:]])
 assert arr.shape==(1030,9) and np.isfinite(arr).all() and (arr[:,7]>0).all()
 return arr,rows[0]

def group_ids(X):
 # Convert source numeric values to stable exact byte tuple; no arbitrary rounding
 key=[tuple(row[:7]) for row in X];m={k:i for i,k in enumerate(sorted(set(key)))}
 return np.asarray([m[k] for k in key])

def fcm(Z,R):
 n,p=Z.shape;z2=(Z*Z).sum(1,keepdims=True);best=None;records=[]
 for seed in FCM_SEEDS:
  rng=np.random.default_rng(seed);U=rng.random((n,R))+1e-12;U/=U.sum(axis=1,keepdims=True);converged=False
  for it in range(1,FCM_MAXITER+1):
   UM=U*U;C=(UM.T@Z)/UM.sum(0)[:,None]
   D=np.maximum(z2+(C*C).sum(1)[None,:]-2*Z@C.T,1e-25)
   inv=1/D;new=inv/inv.sum(axis=1,keepdims=True)
   delta=float(np.max(np.abs(new-U)));U=new
   if delta<FCM_TOL:converged=True;break
  UM=U*U;C=(UM.T@Z)/UM.sum(0)[:,None]
  D=np.maximum(z2+(C*C).sum(1)[None,:]-2*Z@C.T,0.);obj=float(np.sum(UM*D))
  records.append({'seed':seed,'converged':bool(converged),'iters':it,'objective':obj,'last_U_delta':delta})
  if converged and (best is None or (obj,seed)<(best['obj'],best['seed'])):
   vari=(UM.T@(Z*Z))/UM.sum(0)[:,None]-C*C
   best={'C':C,'S0':np.maximum(np.sqrt(np.maximum(vari,0)),FCM_FLOOR),'obj':obj,'seed':seed,'iters':it}
 return best,records

def firing(Z,C,S):
 l=-.5*np.sum(((Z[:,None,:]-C[None,:,:])/S[None,:,:])**2,axis=2)
 return np.exp(l-logsumexp(l,axis=1,keepdims=True))

def design(Z,W):return np.einsum('nr,nj->nrj',W,np.c_[np.ones(len(Z)),Z]).reshape(len(Z),-1)

def gram_screen(P,y):
 n=len(y);yc=y-y.mean(); eig,V=eigh(P.T@P/n,check_finite=False); proj=V.T@(P.T@yc/n)
 return {lam:V@(proj/(eig+lam)) for lam in LGRID}

def ridge_fit(P,y,lam):
 n,q=P.shape;A=np.vstack([P/np.sqrt(n),np.sqrt(lam)*np.eye(q)]);yy=np.r_[(y-y.mean())/np.sqrt(n),np.zeros(q)]
 return lstsq(A,yy,lapack_driver='gelsd',check_finite=False)[0]

def group_rmse(y,hat,g):
 _,inv=np.unique(g,return_inverse=True);loss=np.bincount(inv,weights=(y-hat)**2)/np.bincount(inv)
 return float(np.sqrt(np.mean(loss)))

def et_model(mf,leaf):return ExtraTreesRegressor(n_estimators=ET_ESTIMATORS,max_features=mf,min_samples_leaf=leaf,min_samples_split=2,bootstrap=False,random_state=ET_SEED,n_jobs=1)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--dataset',choices=DATASETS,default='high');ap.add_argument('--fold',type=int,required=True);ap.add_argument('--group-source',choices=('official','rounded'),required=True);args=ap.parse_args()
 arr,headers=read_csv(ROOT/'data'/DATASETS[args.dataset]); X=arr[:,:8];y=arr[:,8];g=group_ids(read_csv(ROOT/'data'/DATASETS[args.group_source])[0][:,:8])
 outer=list(GroupKFold(5).split(X,y,g));k=args.fold;assert 0<=k<5
 tr,te=outer[k]; assert not set(g[tr])&set(g[te])
 inner=[(tr[aa],tr[bb]) for aa,bb in GroupKFold(3).split(X[tr],y[tr],g[tr])]
 out=ROOT/'runs'/(args.dataset+'_'+('original' if args.group_source=='official' else 'rounded')); out.mkdir(parents=True,exist_ok=True)
 log=[];cand=[];et_candidates=[];clock=time.monotonic()
 expected_groups=len(np.unique(g[tr]))
 for R in RGRID:
  groupscores={(h,l):{} for h in HGRID for l in LGRID};fscores={(h,l):[] for h in HGRID for l in LGRID};invalid=False
  for inner_i,(itr,iva) in enumerate(inner):
   sc=StandardScaler().fit(X[itr]); Ztr=sc.transform(X[itr]);Zva=sc.transform(X[iva]);f, rec=fcm(Ztr,R)
   log.append({'R':R,'inner':inner_i,'restarts':rec,'selected_seed':f['seed'] if f is not None else None})
   if f is None:invalid=True;continue
   for h in HGRID:
    Ptr=design(Ztr,firing(Ztr,f['C'],f['S0']*h))
    Pva=design(Zva,firing(Zva,f['C'],f['S0']*h))
    coefs=gram_screen(Ptr,y[itr]); ym=float(y[itr].mean())
    for lam in LGRID:
     pred=Pva@coefs[lam]+ym
     key=(h,lam)
     fscores[key].append(group_rmse(y[iva],pred,g[iva]))
     for gg in np.unique(g[iva]):
      mask=g[iva]==gg;groupscores[key][int(gg)]=float(np.mean((y[iva][mask]-pred[mask])**2))
  for h in HGRID:
   for lam in LGRID:
    key=(h,lam);valid=not invalid and len(groupscores[key])==expected_groups and len(fscores[key])==3
    cand.append({'fold':k,'R':R,'h':h,'lambda':lam,'valid':int(valid),'score':float(np.sqrt(np.mean(list(groupscores[key].values())))) if valid else None,'foldscore_se':float(np.std(fscores[key],ddof=1)/np.sqrt(3)) if valid else None,'validated_groups':len(groupscores[key])})
  print('TSK',args.dataset,k,'R=',R,'elapsed_s=',round(time.monotonic()-clock,1),flush=True)
 validc=[r for r in cand if r['valid']];assert validc,'no FCM fit'
 # One-SE policy: minimum CV then smallest admissible R, tie by CV score (no heldout optimization)
 best=min(validc,key=lambda r:(r['score'],r['R'],abs(r['h']-1),r['lambda']))
 bound=best['score']+best['foldscore_se']
 selection=min((r for r in validc if r['score']<=bound+1e-12),key=lambda r:(r['R'],r['score'],abs(r['h']-1),r['lambda']))
 R=int(selection['R']);h=float(selection['h']);lam=float(selection['lambda'])
 sc=StandardScaler().fit(X[tr]);Ztr=sc.transform(X[tr]);Zte=sc.transform(X[te]);fit,rec=fcm(Ztr,R)
 assert fit is not None
 C=fit['C']; S=fit['S0']*h;Ptr=design(Ztr,firing(Ztr,C,S));Pte=design(Zte,firing(Zte,C,S))
 beta=ridge_fit(Ptr,y[tr],lam);offset=float(y[tr].mean());yp=Pte@beta+offset
 # retain all 12 ET candidates (no test values influence selection)
 for mf in ET_MF:
  for leaf in ET_LEAF:
   losses={};foldscore=[]
   for itr,iva in inner:
    et=et_model(mf,leaf);et.fit(X[itr],y[itr]);pred=et.predict(X[iva]);foldscore.append(group_rmse(y[iva],pred,g[iva]))
    for gg in np.unique(g[iva]):
     mask=g[iva]==gg;losses[int(gg)]=float(np.mean((y[iva][mask]-pred[mask])**2))
   assert len(losses)==expected_groups
   et_candidates.append({'fold':k,'n_estimators':ET_ESTIMATORS,'max_features':mf,'min_samples_leaf':leaf,'score':float(np.sqrt(np.mean(list(losses.values())))),'foldscore_se':float(np.std(foldscore,ddof=1)/np.sqrt(3))})
 print('ET',args.dataset,k,'elapsed_s=',round(time.monotonic()-clock,1),flush=True)
 choose=min(et_candidates,key=lambda r:(r['score'],r['min_samples_leaf'],r['max_features']));et=et_model(choose['max_features'],choose['min_samples_leaf']);et.fit(X[tr],y[tr]);ypet=et.predict(X[te])
 # observed states and independent objective check
 H=Ptr.T@Ptr/len(tr)+lam*np.eye(Ptr.shape[1]);J=float(np.mean((y[tr]-(offset+Ptr@beta))**2)+lam*beta@beta)
 grad=2*(Ptr.T@(Ptr@beta-(y[tr]-offset))/len(tr)+lam*beta)
 assert np.max(np.abs(grad))<1e-7
 np.savez_compressed(out/f'fold{k:02d}_state.npz',tr=tr,te=te,gtrain=g[tr],gtest=g[te],P=Ptr,Pt=Pte,mean=sc.mean_,scale=sc.scale_,C=C,S=S,beta=beta,offset=np.array(offset),lam=np.array(lam),R=np.array(R),h=np.array(h),J=np.array(J),H=H,ytrain=y[tr],ytest=y[te],ytpred=yp,etpred=ypet,Xtrain=X[tr],Xtest=X[te],et_mf=np.array(choose['max_features']),et_leaf=np.array(choose['min_samples_leaf']),source_csv_sha256=np.array(hashlib.sha256((ROOT/'data'/DATASETS[args.dataset]).read_bytes()).hexdigest()))
 with (out/f'fold{k:02d}_TSK_candidates.csv').open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=cand[0].keys());wr.writeheader();wr.writerows(cand)
 with (out/f'fold{k:02d}_ET_candidates.csv').open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=et_candidates[0].keys());wr.writeheader();wr.writerows(et_candidates)
 (out/f'fold{k:02d}_FCM_restarts.json').write_text(json.dumps(log,indent=2))
 summary={'fold':k,'dataset':args.dataset,'heldout_records':len(te),'heldout_mix_count':len(set(g[te])),'train_mix_count':len(set(g[tr])),'TSK':selection,'ET':choose,'outer_TSK_rmse_group':group_rmse(y[te],yp,g[te]),'outer_ET_rmse_group':group_rmse(y[te],ypet,g[te]),'model_stationarity_inf':float(np.max(np.abs(grad))),'wall_s':time.monotonic()-clock,'invalid_TSK_candidates':len(cand)-len(validc),'all_inner_candidate_rows':len(cand),'all_ET_candidates':len(et_candidates),'R_selected':R,'FCM_outer_seed':fit['seed'],'regret_claim':'NONE'}
 (out/f'fold{k:02d}_summary.json').write_text(json.dumps(summary,indent=2));print('FINISHED',json.dumps(summary),flush=True)
if __name__=='__main__':
 with threadpool_limits(limits=1):main()
