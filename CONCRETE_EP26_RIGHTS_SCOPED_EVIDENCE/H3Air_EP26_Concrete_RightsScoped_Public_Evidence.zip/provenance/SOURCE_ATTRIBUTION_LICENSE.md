# Official concrete dataset attribution and use

**Yeh, I. (1998).** *Concrete Compressive Strength* [Dataset]. UCI Machine Learning Repository. <https://doi.org/10.24432/C5PK67>. Registered source: <https://archive.ics.uci.edu/dataset/165/concrete+compressive+strength>.

The UCI registry identifies the dataset as licensed under **Creative Commons Attribution 4.0 International (CC BY 4.0)**. <https://creativecommons.org/licenses/by/4.0/>. The official `Concrete_Data.xls` and its original ZIP were copied **unchanged**; the included `Concrete_UCI_Official_1030x9.csv` is a newly extracted numeric CSV derived from the original OLE2/BIFF8 workbook. Model results, admission reports, and normalized CSVs are derived analysis and must not be confused with original raw data.

The specific original source ZIP and XLS SHA-256 digests are recorded in `source/ORIGIN_AND_SHA256.json`, and the full SHA-256 provenance chain is in `SHA256SUMS.txt`.
