Additional File 2 contains executable/scalar materials for the post hoc analyses.
- R17_inherited_posthoc: inherited R17 controlled sensitivities and statement-level materials.
- R18_feature_role_extension: complete R18 source-case, role-decomposition, fixed-tree control, statement-audit, derived-representation, QA, state and replay package.
The R18 extension does not alter locked R17 primary NASA or Southampton results.
