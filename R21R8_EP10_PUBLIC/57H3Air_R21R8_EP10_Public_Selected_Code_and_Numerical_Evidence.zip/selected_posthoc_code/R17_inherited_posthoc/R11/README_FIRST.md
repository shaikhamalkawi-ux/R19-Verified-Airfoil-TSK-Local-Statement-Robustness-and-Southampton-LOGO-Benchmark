# 57 H3 Airfoil — R11 Targeted Accuracy / Local-Rule Follow-up

**Status:** R11 numerical extension of the R10 post-hoc pilot. **R9 LOCKED AND UNCHANGED.** No paper submission, GitHub update, release tag, software-license decision, or Zenodo upload has been executed by this R11 work.

## Exact source and numerical boundaries

- NASA/UCI Airfoil Self-Noise, DOI `10.24432/C5VW2C`, 1,503 rows, five input variables, 106 repeated `(angle,chord,velocity)` operating configurations; UCI data CC BY 4.0, credit Brooks, Pope and Marcolini.
- Parent code, derived CSV and draw generator are byte-identical to the frozen R10 source, copied under `input/R10_FROZEN_SOURCE`. Original complete R10 ZIP is under `input/R10_SOURCE_ARCHIVE_UNCHANGED.zip`.
- Original R10 ZIP SHA-256: `bd185fb985ff3589ac05e3db3ecc0b29fa0b2e1fef2bd27e6d60ee460eef1dfe`.
- R9 GitHub historical data/code source commit: `6c537312da0388a0c9a2784ee175be95f8657747`. Exact original UCI download bytes were not newly acquired in this R11 run: data are admitted by inherited numerical/semantic verification, not original UCI-byte hash parity.
- R9 editor-corrected combined manuscript provided in conversation SHA-256 `0a9669801ad6379fa1cf1a3f3b143bb56121f53e5b517fe9e2f6abdde8975ad5` (input only; not edited/repackaged into scientific R11 work).

## Scope and endpoints

- R11 core: **six** controlled structures × **ten** unchanged configuration-held-out folds × **200 whole-configuration bootstrap draws** = 12,000 attempted draws, at `h=1`, `lambda=0.01`, fixed FCM inputs/seeds, input-only clustering and ridge-regularized first-order TSK consequent functions.
- Structures: A (F4 premise/F4 consequent) R10, B (F4/F5) R10, C (F5/F4) R10, D (F5/F5) R10, and D (F5/F5) R6 and R12. Every structure/fold uses identical group draw identities under the R10-CONTROL seed family.
- Separately seeded ridge experiment: D/R10, B=200 per fold with all five penalties `{1e-6,1e-4,1e-2,1,100}` sharing *one common fitted antecedent, bootstrap draw, match assignment and joint support mask within each fold and replicate*. This is **2,000 further configuration-bootstrap attempts**, not 2,000 per penalty. The R10-LAMBDA draw family is separate from R10-CONTROL; cross-panel D differences should not be subtracted as if pairwise identical.
- Endpoints: equal-configuration outer OOF RMSE against measured SPL; rule Jaccard matchability; matched local-function disagreement `D` on common relative activation support; retained support; successful and failed FCM denominators. Conditional `D` is NOT an error against observed SPL, and missing matches do not count as zero disagreement.
- Bootstrap and folds reuse the same 106 configurations: they do not create new independent wind-tunnel experiments. Fixed-OOF group-resampling percentile ranges are conditional, not a population confidence interval. Selected fixed controls do NOT replace R9 nested tuned one-SE model-selection results.
- Results derived from a post-pilot follow-up: not preregistered and no causal aerodynamics explanation, interpretability certificate, physically meaningful parameter proof, or generalization to other airfoils claimed.

## Reproduce from a fresh extracted archive

Tested local Python: 3.13.5; dependency versions in `requirements_R11_observed.txt`. With adequate RAM (>=4 GB recommended) and four CPU workers:

```bash
python -m pip install -r requirements_R11_observed.txt
python code/run_r11_replay.py --bootstrap 200 --workers 4 --overwrite
python code/audit_and_summarize_r11.py
python code/run_r11_lambda.py --bootstrap 200 --workers 4
python code/audit_r11_lambda.py
python code/group_heterogeneity_descriptive.py
python code/create_r11_figures.py
python code/build_r11_report.py
```

The main run can require >10 minutes on four allocated CPU cores; it is deterministic under the stated numerical library environment. R11 main reuses **unmodified R10 fitting code**, with output paths redirected into R11, not a redesigned fitter. Fresh reruns of all B=200 results are not required to verify the frozen archived CSVs; use the independent record audits first. For a quick smoke test, run `python code/run_r11_replay.py --parity --bootstrap 2 --workers 2` and `python code/run_r11_lambda.py --bootstrap 2 --folds 0 --workers 1` on a **temporary extracted copy**; do not run the B2 tests in this frozen folder if preserving the delivered output file list matters.

## Important current limitations

1. This is a fixed-h/fixed-penalty exploratory mechanism sensitivity, not independent grouped inner-CV tuning of h and lambda per rule count.
2. More rule matches and smaller D do not establish a better predictive model or physically meaningful rules; strong ridge shrinkage can collapse all local functions toward the training target mean.
3. Both normalized firing mask and similarity match threshold are stated methodological choices; not calibrated physical support.
4. A/B local D is perfectly paired on identical matched rules; between-R rule D values condition on different rule sets. Fold-wise medians are descriptive.
5. Posterior/distribution-free inference on independent aerodynamic campaigns is not possible with this dataset alone.
6. No replacement or upload of R9/R10 source, results or journal materials was authorized; this package remains an author-review evidence extension.
