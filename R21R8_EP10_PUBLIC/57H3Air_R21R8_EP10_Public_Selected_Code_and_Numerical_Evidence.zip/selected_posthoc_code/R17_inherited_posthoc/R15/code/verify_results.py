"""Independent array-level verification; does NOT import the optimization core.

Verifies stored feasible witnesses and dual bounds using direct matrix operations
and an eigendecomposition route for the quadratic conjugate. No training or new
experimental replication is claimed. Run from a fresh archive extraction.
"""
from pathlib import Path
import json,hashlib,argparse
import numpy as np,pandas as pd

def run(root:Path,result:Path):
 checks=[]; maxima={'primal_training_excess':0.,'qp_duality_gap':0.,'lp_duality_gap':0.,'quadratic_identity_error':0.,'eigen_dual_discrepancy':0.}
 def ck(name,good,**extra):
  checks.append({'check':name,'pass':bool(good),**extra})
  if not good:raise AssertionError((name,extra))
 allrows=[]
 for f in sorted(result.glob('*_JOINT.csv')):
  stem=f.name[:-len('_JOINT.csv')];csv=pd.read_csv(f)
  z=np.load(root/'inputs/states'/f'{stem}.npz',allow_pickle=False)
  w=np.load(result/f'{stem}_WITNESSES.npz',allow_pickle=False)
  P=z['P'];beta=z['beta'];n,q=P.shape;lam=float(z['lam']);off=float(z['offset']);yc=z['ytrain']-off
  Pind=(z['W'][:,:,None]*z['T'][:,None,:]).reshape(n,q)
  ck(stem+':design',np.max(abs(P-Pind))<1e-12)
  ck(stem+':groups_disjoint',not(set(z['gtrain'])&set(z['gtest'])))
  H=P.T@P/n+lam*np.eye(q);ev,U=np.linalg.eigh(H)
  ck(stem+':positive_H',ev.min()>0)
  Hi=(U/ev[None,:])@U.T
  J=float(np.mean((yc-P@beta)**2)+lam*beta@beta)
  ck(stem+':stationary',np.max(abs(H@beta-P.T@yc/n))<1e-9)
  sigma=np.linalg.svd(P,compute_uv=False)[-1]
  ck(stem+':full_rank',sigma>np.linalg.svd(P,compute_uv=False)[0]*1e-10)
  for jdata in csv.groupby('j'):
   j,g=jdata;one=g.iloc[0];key=f'r{int(one.rule):02d}_k{int(one.feature_index)}'
   d=w[key+'_lp_d'];mu=w[key+'_lp_mu'];B=np.vstack((P,-P));e=B.T@mu-np.eye(q)[j]
   lo=d[j];up=.1*(mu.sum()+np.sqrt(n)*np.linalg.norm(e)/sigma)
   ck(stem+key+':LP_primal',np.max(abs(P@d))<=.1+1e-10)
   ck(stem+key+':LP_dual_nonnegative',mu.min()>=0)
   ck(stem+key+':LP_gap',-1e-9<=up-lo<=2e-6,gap=float(up-lo))
   maxima['lp_duality_gap']=max(maxima['lp_duality_gap'],float(up-lo))
   for _,row in g.iterrows():
    eps=float(row.epsilon);gam=float(row.gamma);target=-(1+gam)*beta[j]
    prefix=stem+key+f':eps{eps:g}:gamma{gam:g}'
    lo1=lo*eps/.1;up1=up*eps/.1
    ck(prefix+':LP_record',abs(lo1-row.pointwise_max_lower)<1e-8 and abs(up1-row.pointwise_max_upper)<1e-8)
    if row.status=='TARGET_INFEASIBLE_POINTWISE':
     ck(prefix+':exclusion',up1<abs(target)-1e-7*max(1.,abs(beta[j])))
     continue
    if 'UNRESOLVED' in row.status:
     checks.append({'check':prefix,'pass':False,'admissible_unresolved':True,'status':row.status});continue
    ekey=f'{key}_eps{eps:g}_g{gam:g}'
    dp=w[ekey+'_d'];u=w[ekey+'_upper_mu'];v=w[ekey+'_lower_mu'];nu=float(w[ekey+'_nu'])
    qlin=P.T@(u-v);qlin[j]+=nu
    dual=(-.25*qlin@Hi@qlin-eps*(u.sum()+v.sum())-nu*target)/J
    val=float(dp@H@dp/J)
    actual=float((np.mean((yc-P@(beta+dp))**2)+lam*(beta+dp)@(beta+dp)-J)/J)
    trmax=float(np.max(abs(P@dp)));htmax=float(np.max(abs(z['Pt']@dp)))
    ck(prefix+':primal',trmax<=eps+2e-10 and abs(dp[j]-target)<1e-8)
    ck(prefix+':dual',min(u.min(),v.min())>=0 and dual<=val+1e-8)
    ck(prefix+':QP_gap',-1e-8<=val-dual<=2e-6,gap=float(val-dual))
    ck(prefix+':direct_objective',abs(val-actual)<2e-9)
    ck(prefix+':record_cost',abs(val-row.minimum_relative_cost)<1e-10)
    ck(prefix+':record_dual',abs(dual-row.dual_lower)<1e-7)
    ck(prefix+':record_holdout',abs(htmax-row.max_heldout_change)<1e-9)
    if row.status in ['REVERSAL_WITHIN_1PCT','ZERO_REACHABLE_WITHIN_1PCT']:
     ck(prefix+':budget',actual<=.01-1e-8)
    if row.status=='REVERSAL_WITHIN_1PCT':ck(prefix+':opposite',beta[j]*(beta[j]+dp[j])<0)
    if 'EXCLUDED_BY_JOINT_COST' in row.status:ck(prefix+':cost_excludes',dual>.01+1e-8)
    maxima['primal_training_excess']=max(maxima['primal_training_excess'],trmax-eps)
    maxima['qp_duality_gap']=max(maxima['qp_duality_gap'],val-dual)
    maxima['quadratic_identity_error']=max(maxima['quadratic_identity_error'],abs(val-actual))
    maxima['eigen_dual_discrepancy']=max(maxima['eigen_dual_discrepancy'],abs(dual-row.dual_lower))
  allrows.append(csv)
 df=pd.concat(allrows,ignore_index=True)
 failed=[c for c in checks if not c['pass']]
 report={'scope':'Independent numerical primal/dual checks; not interval arithmetic or independent physical data',
         'result_directory':result.name,'checks':len(checks),'passed':sum(c['pass'] for c in checks),'unresolved':len(failed),
         'maxima':maxima,'rows':len(df),'parents':len(allrows),'status_counts':{str(k):int(v) for k,v in df.groupby(['epsilon','gamma','status']).size().items()},
         'detail':checks}
 (result/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({k:v for k,v in report.items() if k not in ['detail','status_counts']},indent=2))
 if failed:raise SystemExit(1)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--results',type=Path);a=p.parse_args();run(a.root,a.results or a.root/'results')
