# Exploratory joint observed-input feasibility audit (not incorporated into the manuscript)
The original 69/107 training-only reversal witnesses retained on held-out coordinates are unchanged. Of the remaining 38, 31 alternative witnesses satisfy the joint observed training+held-out input constraints and seven have verified guarded zero-exclusion bounds. Consequently 410/510 protected and 100/510 reversible under the tighter joint input constraint. These are post hoc, fixed-premise, finite-coordinate numerical results; no held-out targets are used, but held-out coordinates enter the new optimization. They are not prospective transfer or independent physical validation, nor the primary 403/107 partition. One exclusion is close to the numerical boundary; no interval-arithmetic proof is claimed.

## Exact dependencies and replay
Download the earlier public AF4 ZIP from https://github.com/shaikhamalkawi-ux/R19-Verified-Airfoil-TSK-Local-Statement-Robustness-and-Southampton-LOGO-Benchmark/releases/tag/h3air-r21r8-ep18-evidence-v1 (asset `57H3Air_EP18_AF4_Scientific_Evidence.zip`, SHA-256 `1edd543fb6544f8bd23de418b3108f1617518251bf35a2cb18ec966d5a7225dd`), extract it, and use `direct_derivative/inputs` as the input directory. All 21 input files in the original exploratory archive were checked byte-identical to those public AF4 files; they are not duplicated here. Input SHA-256 identities are in `results/summary.json`. Original calculation and verification code and saved scientific evidence are retained unchanged. Install `requirements.txt` (original environment Python 3.13.5) and run:
```
python verify.py /path/to/AF4/direct_derivative/inputs --results results
python run.py /path/to/AF4/direct_derivative/inputs --out fresh_results
python verify.py /path/to/AF4/direct_derivative/inputs --results fresh_results
```
This exploratory evidence was deliberately not included in EP20/EP21. It does not supersede the manuscript or Bristol source-method replication. No private correspondence or raw Bristol files are distributed.
