"""R11 replay of R10 SVD shared-antecedent penalty sensitivity with B=200.
Uses the original code unchanged and preserves seed R10-LAMBDA|fold|rep.
All lambdas in a fixed fold share identical group bootstraps, FCM antecedents,
rule assignments and common-support masks. Pilot R10 was B=30.
"""
from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import argparse,sys,json,traceback,hashlib,time
from threadpoolctl import threadpool_limits
BASE=Path(__file__).resolve().parents[1]
R10=Path(__file__).resolve().parents[1]/'input'/'R10_FROZEN_SOURCE'

def worker(fold,B):
    sys.path.insert(0,str(R10/'code'))
    import ridge_lambda_sensitivity as m
    import controlled_rule_study as core
    from decode_derived_table import load
    m.OUT=BASE/'results'/'lambda_200'
    m.OUT.mkdir(parents=True,exist_ok=True)
    with threadpool_limits(limits=1):
        r=m.run_variant(load(),'D',10,fold,B)
    return {'fold':fold,'bootstrap_attempts':B,'bootstrap_failed':r.get('bootstrap_fails'), 'elapsed_s':r.get('elapsed_s'), 'parent_success':r.get('parent_success')}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--bootstrap',type=int,default=200);p.add_argument('--workers',type=int,default=4);p.add_argument('--folds',default='0,1,2,3,4,5,6,7,8,9');a=p.parse_args()
    folds=[int(x) for x in a.folds.split(',')]; print('R11 LAMBDA tasks',folds,'B',a.bootstrap,flush=True)
    begin=time.time();errors=[];out=[]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        fs={pool.submit(worker,f,a.bootstrap):f for f in folds}
        for ft in as_completed(fs):
            try:
                x=ft.result();out.append(x);print('LAMBDA DONE',x,'completed',len(out),'/',len(folds),'elapsed',round(time.time()-begin,1),flush=True)
            except Exception:
                errors.append({'fold':fs[ft],'trace':traceback.format_exc()});print('LAMBDA ERROR',fs[ft],errors[-1]['trace'],flush=True)
    (BASE/'qa'/('R11_LAMBDA_B200_RUN_STATUS.json' if a.bootstrap==200 else 'R11_LAMBDA_B30_PARITY_STATUS.json')).write_text(json.dumps({'data':out,'errors':errors,'runtime_s':time.time()-begin,'source_sha256':hashlib.sha256((R10/'code'/'ridge_lambda_sensitivity.py').read_bytes()).hexdigest()},indent=2))
    if errors:raise RuntimeError('lambda runner errors')
