#!/usr/bin/env python3
"""Verify saved primal witnesses and dual lower bounds independently; no optimization or fitting."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import argparse,hashlib,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.special import logsumexp

def main():
 p=argparse.ArgumentParser();p.add_argument('inputs',type=Path);p.add_argument('--results',type=Path,default=Path('results'));args=p.parse_args()
 S=json.loads((args.results/'summary.json').read_text());D=pd.read_csv(args.results/'joint_transport_audit.csv');T=pd.read_csv(args.inputs/'RESOLVED_510_STATEMENTS.csv');T=T[(T.epsilon==.1)&(T.gamma==.001)&(T.final_class=='FEASIBLE_REVERSAL')];ids=['fold','rule','feature_index'];assert len(D)==len(T)==107 and set(map(tuple,D[ids].to_numpy()))==set(map(tuple,T[ids].to_numpy())) and not D.duplicated(ids).any();T=T.set_index(ids)
 for k,h in S['input_sha256'].items():assert hashlib.sha256((args.inputs/k).read_bytes()).hexdigest()==h
 eps=.1;eta=.01;mx={'design_reconstruction':0.,'stationarity':0.,'direct_objective_expansion':0.,'crossing_error':0.,'lower_replay_error':0.,'upper_replay_error':0.,'max_dual_l1':0.}; old=0;new=0;blocked=0;min_excess=1.;min_relative_margin=1.;max_new_train=0.;max_new_test=0.;max_new_objective=0.;used=set()
 for fold in range(10):
  z=np.load(args.inputs/'states'/f'AIRFOIL_ONESE_fold{fold:02}.npz',allow_pickle=False);w=np.load(args.inputs/'witnesses'/f'AIRFOIL_ONESE_fold{fold:02}_WITNESSES.npz',allow_pickle=False);ev=np.load(args.results/f'fold{fold:02d}_new_evidence.npz',allow_pickle=False)
  P,Pt,b=z['P'],z['Pt'],z['beta']; n,q=P.shape;U=np.concatenate((P,Pt));y=z['ytrain']-float(z['offset']);lam=float(z['lam']);H=P.T@P/n+lam*np.eye(q);J=np.mean((P@b-y)**2)+lam*b@b
  def rebuild(T):
   X=T[:,1:];logw=-.5*np.sum(((X[:,None,:]-z['C'][None,:,:])/z['S'][None,:,:])**2,axis=2);weights=np.exp(logw-logsumexp(logw,axis=1,keepdims=True));return np.einsum('ir,ij->irj',weights,T).reshape(len(T),q)
  mx['design_reconstruction']=max(mx['design_reconstruction'],np.max(abs(P-rebuild(z['T']))),np.max(abs(Pt-rebuild(z['Tt']))));mx['stationarity']=max(mx['stationarity'],np.max(abs(H@b-P.T@y/n)))
  def actual(d):return (np.mean((P@(b+d)-y)**2)+lam*((b+d)@(b+d))-J)/J
  # In raw coordinates evaluate the tangent covariance metric directly, rather than reuse optimization code.
  def replay(stem,j,scale,lo,up):
   d,ix,u=[ev[stem+'_'+k] for k in ('d','ix','u')];used.update((fold,stem+'_'+k) for k in ('d','ix','u'));assert len(ix)==len(u) and len(set(ix))==len(ix) and np.all((ix>=0)&(ix<len(U)))
   c=np.zeros(q);c[j]=-1/(scale*b[j]);v=np.linalg.solve(H,c);K=c@v;d0=v/K;room=eta*J-1/K;ad=U[ix].T@u;iv=np.linalg.solve(H,ad);tangent=iv-v*(c@iv)/K
   raw_lower=ad@d0-np.sqrt(room*(tangent@H@tangent));raw_upper=max(abs(U@d));guard=1e-9*max(1.,abs(raw_lower),raw_upper);L=max(0.,raw_lower-guard);B=raw_upper+guard
   assert room>0 and L<=B and abs(L-lo)<2e-8 and abs(B-up)<2e-8 and abs(c@d-1)<1e-9 and sum(abs(u))<=1+1e-12 and actual(d)<=eta+1e-10
   mx['lower_replay_error']=max(mx['lower_replay_error'],abs(L-lo));mx['upper_replay_error']=max(mx['upper_replay_error'],abs(B-up));mx['crossing_error']=max(mx['crossing_error'],abs(c@d-1));mx['max_dual_l1']=max(mx['max_dual_l1'],sum(abs(u)));mx['direct_objective_expansion']=max(mx['direct_objective_expansion'],abs(actual(d)-d@H@d/J));return L,B
  for r in D[D.fold==fold].itertuples(index=False):
   j=r.rule*6+r.feature_index;stem=f'r{r.rule:02}_k{r.feature_index}';assert j==r.j and abs(b[j]-r.baseline)<1e-12
   d=w[stem+'_eps0.1_g0.001_d'];a=float(max(abs(P@d)));t=float(max(abs(Pt@d)));ac=actual(d);assert abs(a-r.old_train)<1e-9 and abs(t-r.old_test)<1e-9 and abs(ac-r.old_cost)<1e-9 and abs(t-T.loc[(fold,r.rule,r.feature_index)].max_heldout_change)<2e-8 and b[j]*(b[j]+d[j])<0 and a<=eps+5e-8 and ac<=eta+5e-8
   if r.status=='ORIGINAL_WITNESS_RETAINED':
    assert t<=eps+5e-8;old+=1;continue
   assert t>eps+5e-8
   L,B=replay(stem+'_zero',j,1.,r.zero_lower,r.zero_upper)
   if r.status=='JOINT_ZERO_EXCLUDED':
    assert L>eps;blocked+=1;min_excess=min(min_excess,L-eps);continue
   assert r.status=='JOINT_ORIGINAL_MARGIN_WITNESS'
   L1,B1=replay(stem+'_margin',j,1.001,r.margin_lower,r.margin_upper);d=ev[stem+'_strict'];used.add((fold,stem+'_strict'));nt=max(abs(P@d));nv=max(abs(Pt@d));nc=actual(d);rel=-float((b[j]+d[j])/b[j]);assert max(nt,nv)<eps and nc<=eta+1e-10 and rel>0 and abs(rel-.001)<1e-9
   assert abs(nt-r.new_train)<1e-9 and abs(nv-r.new_test)<1e-9 and abs(nc-r.new_cost)<1e-9 and abs(b[j]+d[j]-r.new_coefficient)<1e-9
   new+=1;min_relative_margin=min(min_relative_margin,rel);max_new_train=max(max_new_train,nt);max_new_test=max(max_new_test,nv);max_new_objective=max(max_new_objective,nc)
  assert set(ev.files)=={k for f,k in used if f==fold}
 assert mx['design_reconstruction']<1e-10 and mx['stationarity']<1e-9 and mx['direct_objective_expansion']<1e-9 and (old,new,blocked)==(69,31,7)
 out={'status':'PASS','original_training_only_witnesses_retained':old,'new_query_targeted_same_margin_witnesses':new,'joint_zero_exclusions':blocked,'minimum_guarded_lower_bound_excess_over_0.1_dB':float(min_excess),'minimum_new_relative_reversal_margin':float(min_relative_margin),'maximum_new_training_change_dB':float(max_new_train),'maximum_new_heldout_change_dB':float(max_new_test),'maximum_new_relative_objective_increase':float(max_new_objective),'numerical_QA':{k:float(v) for k,v in mx.items()},'scope':'all 107 inherited reversible slopes; 403 original protected slopes remain protected by set inclusion; finite observed union only; no held-out y read, no fitting, no interval arithmetic'}
 (args.results/'independent_verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
