"""Independent R11 record audit; no imports from R10 analysis code. No model fitting.
Exit nonzero on failed calculation/lineage gates. R9/R10 locked.
"""
from __future__ import annotations
from pathlib import Path
import json,hashlib,math,csv,statistics,collections
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'input'/'R10_FROZEN_SOURCE'
SUB=ROOT/'results'/'replay_200'
QA=ROOT/'qa';QA.mkdir(exist_ok=True)
SPEC=[('A',10),('B',10),('C',10),('D',10),('D',6),('D',12)]
BOOTS=200
FIELDS=['parent_condition','test_group_rmse_dB','matched_jaccard_median','D_parent_median_dB','D_common_median_dB','match_fraction_mean','common_support_retention_median']
GATES=[]

def test(name,passed,detail=None):
    GATES.append({'gate':name,'passed':bool(passed),'detail':detail})
    if not passed: print('FAIL',name,detail,flush=True)

def med(arr):return float(np.median(arr)) if arr else None

def get(v,R,f,B,root):
    p=root/f'{v}_outer{f:02d}_R{R:02d}_B{B:03d}.json'
    return json.loads(p.read_text()) if p.exists() else None

all_records=[]
for v,R in SPEC:
    for f in range(10):
        current=get(v,R,f,200,SUB)
        prev=get(v,R,f,30,SRC/'results')
        test('result_present:'+v+str(R)+':'+str(f),current is not None)
        if current is None:continue
        all_records.append(current)
        test('parent_success:'+v+str(R)+':'+str(f),current.get('parent_fit_success'))
        test('replicate_accounting:'+v+str(R)+':'+str(f),current.get('bootstrap_attempts')==200 and current['bootstrap_success']+current['bootstrap_failed']==200 and len(current['failed_register'])==current['bootstrap_failed'])
        test('pair_accounting:'+v+str(R)+':'+str(f),current['matched_common_pair_count']+current['pairs_empty']==current['pairs'])
        test('configuration_partition:'+v+str(R)+':'+str(f),current['train_groups']+current['test_groups']==106)
        test('score_bounds:'+v+str(R)+':'+str(f),all((current.get(k) is not None and 0 <= current[k]<=1) for k in ['match_fraction_mean','common_support_retention_median','matched_jaccard_median']))
        test('matched_nonnegative:'+v+str(R)+':'+str(f),current['pairs']>0 and current['D_common_median_dB']>=0)
        q=R*(5 if v in 'AC' else 6) # A,C four consequent features; B,D five
        test('q_dimension:'+v+str(R)+':'+str(f),current['q']==q)
        test('source_data_hash:'+v+str(R)+':'+str(f),current['input_hash_sha256']==hashlib.sha256((SRC/'data'/'airfoil_F5_RECONSTRUCTED_NUMERICALLY.csv').read_bytes()).hexdigest())
        if prev is not None:
            parent_equal=all(current[k]==prev[k] for k in ['parent_condition','test_group_rmse_dB','parent_fcm_iters','parent_fcm_seed','q','test_rows','test_groups','train_rows','train_groups','test_square_error_by_group'])
            test('R10_parent_numerical_lock:'+v+str(R)+':'+str(f),parent_equal)
        else: test('R10_parent_found:'+v+str(R)+':'+str(f),False)

test('all_six_specs_ten_folds',len(all_records)==60)
# The entire feature-role matched rule set must have identical match outcomes for A/B and C/D, since they share antecedent inputs.
for f in range(10):
    for a,b in [('A','B'),('C','D')]:
        p=get(a,10,f,200,SUB);q=get(b,10,f,200,SUB)
        if p and q:
            for k in ['bootstrap_failed','bootstrap_success','pairs','pairs_empty','matched_common_pair_count','match_fraction_mean','common_support_retention_median','matched_jaccard_median']:
                test('role_shared_antecedent:'+a+b+':'+str(f)+':'+k,p[k]==q[k])

specrows=[];foldrows=[]; all_losses={}
for v,R in SPEC:
    rr=[get(v,R,f,200,SUB) for f in range(10)]
    if any(r is None for r in rr):continue
    squared={k:loss for r in rr for k,loss in r['test_square_error_by_group'].items()}
    test('all_heldout_group_coverage:'+v+str(R),len(squared)==106 and sum(len(r['test_square_error_by_group']) for r in rr)==106)
    all_losses[v,R]=squared
    for r in rr:
        foldrows.append({'variant':v,'R':R,'fold':r['fold'],'test_group_RMSE_dB':r['test_group_rmse_dB'],
          'D_common_dB':r['D_common_median_dB'],'D_parent_dB':r['D_parent_median_dB'],
          'match_fraction':r['match_fraction_mean'],'retention':r['common_support_retention_median'],
          'matched_pairs':r['pairs'],'unmatched_rules_or_rulesets_conditional':None,
          'failures':r['bootstrap_failed'],'parent_condition':r['parent_condition']})
    specrows.append({'variant':v,'R':R,'folds':len(rr),'heldout_configurations':len(squared),
      'group_RMSE_dB':float(np.sqrt(np.mean(list(squared.values())))),
      'median_fold_D_common_dB':med([r['D_common_median_dB'] for r in rr]),
      'median_fold_D_parent_dB':med([r['D_parent_median_dB'] for r in rr]),
      'median_fold_match_fraction':med([r['match_fraction_mean'] for r in rr]),
      'median_fold_support_retention':med([r['common_support_retention_median'] for r in rr]),
      'median_parent_condition':med([r['parent_condition'] for r in rr]),
      'bootstrap_attempts':sum(r['bootstrap_attempts'] for r in rr),
      'bootstrap_success':sum(r['bootstrap_success'] for r in rr),
      'bootstrap_failures':sum(r['bootstrap_failed'] for r in rr),
      'matched_pairs':sum(r['pairs'] for r in rr),
      'unmatched_pairs_common_domain':sum(r['pairs_empty'] for r in rr)})

pd.DataFrame(foldrows).sort_values(['variant','R','fold']).to_csv(ROOT/'results'/'R11_B200_FOLD_RESULTS.csv',index=False)
pd.DataFrame(specrows).sort_values(['variant','R']).to_csv(ROOT/'results'/'R11_B200_SUMMARY.csv',index=False)

# Fixed OOF group-resampling differences (not a retraining-inclusive uncertainty interval).
rng=np.random.default_rng(20261010)
paired=[]
base=('A',10)
for k,l in [(('B',10),('A',10)),(('C',10),('A',10)),(('D',10),('A',10)),(('B',10),('D',10)),(('D',12),('D',6)),(('D',10),('D',6)),(('D',12),('D',10))]:
    if k not in all_losses or l not in all_losses: continue
    keys=sorted(all_losses[k])
    x=np.array([all_losses[k][g] for g in keys]);y=np.array([all_losses[l][g] for g in keys]);
    test('loss_group_alignment:'+str(k)+str(l),keys==sorted(all_losses[l]))
    idx=rng.integers(0,106,size=(5000,106))
    boot=np.sqrt(x[idx].mean(axis=1))-np.sqrt(y[idx].mean(axis=1))
    fr=[get(*k,f,200,SUB)['test_group_rmse_dB']-get(*l,f,200,SUB)['test_group_rmse_dB'] for f in range(10)]
    paired.append({'first_variant':k[0],'first_R':k[1],'second_variant':l[0],'second_R':l[1],
     'group_RMSE_difference_dB':float(np.sqrt(x.mean())-np.sqrt(y.mean())),
     'conditional_group_resampling_p2p5':float(np.quantile(boot,.025)),
     'conditional_group_resampling_p97p5':float(np.quantile(boot,.975)),
     'groups_first_mse_lower':int(np.sum(x<y)),
     'folds_first_rmse_lower':int(np.sum(np.array(fr)<0)),
     'median_fold_rmse_diff_dB':med(fr),
     'inference_scope':'paired group-resampling of FIXED out-of-fold errors; no retraining or independent experimental sampling'})
pd.DataFrame(paired).to_csv(ROOT/'results'/'R11_FIXED_OOF_PAIRED_CONTRASTS.csv',index=False)

# Paired fold medians for same antecedent case (not independent bootstrapped rule-pair tests).
local=[]
for x,y in [('B','A'),('D','C'),('B','D')]:
    if not all(get(a,10,f,200,SUB) for a in [x,y] for f in range(10)):continue
    d=[get(x,10,f,200,SUB)['D_common_median_dB']-get(y,10,f,200,SUB)['D_common_median_dB'] for f in range(10)]
    local.append({'contrast':x+' - '+y,'R':10,'fold_median_D_delta':med(d),'folds_first_D_lower':sum(x<0 for x in d),'minimum':min(d),'maximum':max(d),'comparison_scope':'fold-wise medians conditional on differing matched pair subsets unless same antecedent'})
pd.DataFrame(local).to_csv(ROOT/'results'/'R11_LOCAL_D_FOLD_CONTRASTS.csv',index=False)

report={'project':'57 H3 Airfoil','run':'R11 targeted B200 extension of R10 pilot','status':'FULL_REPLAY_QA' if len(all_records)==60 else 'INCOMPLETE_REPLAY_QA',
 'R9_locked_science':'preserved; none of the R9 numerical outputs modified',
 'R10_archive_sha256':hashlib.sha256((ROOT/'input'/'R10_SOURCE_ARCHIVE_UNCHANGED.zip').read_bytes()).hexdigest(),
 'parent_core_code_sha256':hashlib.sha256((SRC/'code'/'controlled_rule_study.py').read_bytes()).hexdigest(),
 'validation_gates':len(GATES),'validation_pass':sum(int(g['passed']) for g in GATES),'validation_failures':[g for g in GATES if not g['passed']],
 'specification_results':specrows,'paired_fixed_output_differences':paired,'local_fold_differences':local,
 'warnings':['All R11 analyses developed after inspection of R9/R10; not preregistered.',
    'D is conditional on successful rule matching and shared firing threshold, not outcome error.',
    'Configured B200 improves resampling resolution but does not create independent experiments.',
    'Group-reweighted ranges condition on fixed OOF predictions; they do not cover model selection or retraining.',
    'Fixed h=1 and lambda=0.01 across rule counts is a controlled diagnostic, not independent inner-CV tuning.',
    'Original UCI downloaded bytes not archived here as a new verified source.',
    'No new results replace R9 published/locked manuscript.']}
(QA/'R11_INDEPENDENT_RECORD_AUDIT.json').write_text(json.dumps(report,indent=2,allow_nan=False))
print('INDEPENDENT R11 GATES',report['validation_pass'],'/',report['validation_gates'],'PASS')
print('SPECS',len(specrows),'LOST',len(report['validation_failures']))
print(pd.DataFrame(specrows).to_string(index=False))
print('PAIRED',pd.DataFrame(paired).to_string(index=False))
if report['validation_failures'] or len(all_records)!=60:raise SystemExit(1)
