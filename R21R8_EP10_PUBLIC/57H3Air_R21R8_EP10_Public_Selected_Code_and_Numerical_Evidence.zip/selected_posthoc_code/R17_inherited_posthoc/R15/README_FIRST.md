# 57 H3 Airfoil — R15 Statement Robustness
Date: 10 October 2026. Status: EXECUTED_RESEARCH_EXTENSION / MANUSCRIPT_NOT_REPLACED.

## Read first
- `docs/R15_Method_and_Results.pdf`: eight-page scientific report, equations and results.
- `docs/SCIENTIFIC_DECISION_AR.md`: Arabic decision and claim boundaries.
- `results/reporting/RESOLVED_510_STATEMENTS.csv`: every primary result and its prior classification.
- `results/reporting/BUDGET_SURFACE.csv`: prediction/objective budgets; no unresolved grid cells.
- `results/reporting/OBSERVED_FREQUENCY_CONTRASTS.csv`: finite observed-input illustration.
- `sources/PRIMARY_SOURCE_LEDGER.md`: targeted novelty review and accessible source scope.

## What was executed
Frozen matrices from ten R14 one-SE parents and ten paired narrower-width parents were used; these parents were NOT retrained. The 351 unresolved prior statements are resolved as 293 protected and 58 reversible. Across all 510 slopes there are 403 protected signs and 107 feasible strict reversals at epsilon=0.1 dB and eta=1%; 60 equal-magnitude reversals are feasible. Protection is conditional on the declared finite-input model set, not proof of physics or a confidence statement.

The objective budget adds no primary sign exclusions beyond the pointwise constraint; this negative result is retained. At other budgets it can exclude additional targets. The narrower-width parents have 71 strict reversals overall, but 38 previously protected signs become reversible: width is not uniformly beneficial. The held-out transfer results and failed stricter tests are retained.

## Verification and reproduction
Use Python 3.11+ with NumPy, SciPy, pandas and matplotlib. Versions actually used are in `qa/ENVIRONMENT.json`.

```sh
python code/verify_all.py
# Full fresh numerical re-solving (no model retraining):
python code/reproduce_fresh.py
# Optional figure regeneration:
python code/make_figures.py
```

`verify_all.py` checks stored witnesses and duals using an independently assembled matrix route, runs controls, and rebuilds reporting tables. `reproduce_fresh.py` copies inputs/code into a temporary directory, re-solves all three branches and compares numerical arrays/CSV values. It writes audit logs and may alter the full-package file manifest because runtime logs record new execution times. Preserve the distributed ZIP unchanged; run full execution in a working copy. `run_joint.py` supports restart by reusing existing per-fold CSVs; an empty output directory is required for a genuinely fresh run.

All reported optimization classifications include numeric feasibility and primal/dual checks. Arithmetic is ordinary floating point, NOT an outward-rounded proof. File hashes bind evidence but do not establish scientific novelty.

## File organization
- `inputs/states/`: exact frozen R14 NPZ parents; no unsafe pickle loading.
- `inputs/PRIOR_SCREEN_510.csv`: original analytic screen.
- `inputs/AIRFOIL.csv`: inherited numeric data table.
- `results/`: primary per-parent tables and coefficient/dual witnesses.
- `results/budget/`: four further prediction budgets, gamma=0 and 0.001.
- `results/narrow/`: paired h=1 parents at the primary budget.
- `results/reporting/`: regenerated tables and summaries.
- `code/`: solver, separate verification, controls and production scripts.
- `qa/`: initial rejected solver logs, successful checks and fresh parity.
- `sources/`: primary-source ledger and external dataset inventory/retrieval boundary.

The complete set contains 7,140 target evaluations across the three branches; many targets are excluded by LP bounds without a QP solve. They are NOT 7,140 experiments. Bootstrap resampling from older versions is not repeated here.

## Release and data scope
R13 and R14 are untouched. Nothing was submitted to a journal or published to GitHub/Zenodo. Software licensing and author approval remain separate. Airfoil derives from NASA/UCI (DOI 10.24432/C5VW2C), source CC BY 4.0; inherited row-level provenance is disclosed. No new original-download byte attestation is claimed. The 4TU external dataset is a located candidate with CC BY-NC 4.0 metadata; its bytes were not admitted because download failed. No third-party paper PDF or font file is redistributed.
