# Component-level rights and attribution — authorized release

The project representative confirmed on 26 November 2026 that the six-author publication approval includes the exact AF4 and AF5 scientific evidence candidates and the proposed component-level licensing. This records the representative’s confirmation, not an independently collected set of signed author declarations or a grant of third-party rights.

- UCI Airfoil Self-Noise: Brooks, T., Pope, D., & Marcolini, M. (1989). https://doi.org/10.24432/C5VW2C. UCI's official dataset page https://archive.ics.uci.edu/dataset/291/airfoil+self-noise states CC BY 4.0. Retain attribution and identify the model/derived-data transformations.
- Southampton dataset: Lau, A. S. H., & Kim, J. W. (2016), https://doi.org/10.5258/SOTON/398169; https://eprints.soton.ac.uk/398169/ states Creative Commons Attribution. Retain the source's exact terms, authorship and attribution; do not substitute a project license.
- Byte-identical parent-state and original witness files from the previously deposited EP11 Additional File 3 are matched to that archive's published MD5 (17557ace07c178c94efdcd49a58a9e72). Their existing component-level rights remain unchanged; this does not independently license new code.
- Authorized original project code: MIT (LICENSE_MIT.txt). Authorized original documentation and derived research records: Creative Commons Attribution 4.0 International (https://creativecommons.org/licenses/by/4.0/legalcode). No blanket license for third-party content or any other rights holder.
- Excluded: manuscript, reviewer correspondence, cover letter, publisher templates, personal documents, credentials, third-party PDFs and restricted Bristol raw files.
- Numeric records are frozen historical evidence; pre-release notices are historical and not proof of new authorization.

Earlier notices preserved under provenance/ describe their original dates and are not current release restrictions on the authorized original components. No broader grant is implied. The existing EP11 deposit and historical inputs remain unchanged.
