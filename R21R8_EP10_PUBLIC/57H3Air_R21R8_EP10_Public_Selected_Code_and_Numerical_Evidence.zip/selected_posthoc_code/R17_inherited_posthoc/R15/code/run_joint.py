from __future__ import annotations
import os
for var in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:
 os.environ.setdefault(var,'1')
import argparse,json,time,hashlib,sys
from pathlib import Path
import numpy as np,pandas as pd
from scipy.linalg import cho_factor,cho_solve
from joint_core import minimum_cost, pointwise_bound,HIGHS_BACKEND
FEATURES=['log10_frequency','angle','chord','velocity','log10_displacement']

def jsonable(v):
 if isinstance(v,np.generic):return v.item()
 if isinstance(v,Path):return str(v)
 raise TypeError(type(v))

def run(root:Path,families:list[str],epsilons:list[float],output:Path|None=None,gammas:list[float]|None=None):
 allrows=[];checks=[];start=time.time()
 resultdir=output or root/'results';resultdir.mkdir(parents=True,exist_ok=True)
 gammas=gammas or [0.,.001,1.]
 for family in families:
  for path in sorted((root/'inputs/states').glob(f'{family}_fold*.npz')):
   fold=int(path.stem[-2:]);z=np.load(path,allow_pickle=False)
   if (resultdir/f'{path.stem}_JOINT.csv').exists():
    old=pd.read_csv(resultdir/f'{path.stem}_JOINT.csv');allrows.extend(old.to_dict('records'));continue
   P=z['P'];Pt=z['Pt'];beta=z['beta'];lam=float(z['lam']);offset=float(z['offset']);yc=z['ytrain']-offset
   H=P.T@P/len(P)+lam*np.eye(len(beta));cf=cho_factor(H,lower=True);Hi=cho_solve(cf,np.eye(len(beta)))
   J=float(np.mean((yc-P@beta)**2)+lam*beta@beta)
   n,q=P.shape;R=int(z['R']);b=q//R
   stationarity=np.max(np.abs(H@beta-P.T@yc/n))
   assert stationarity<1e-9 and b==6
   arrays={};foldrows=[]
   for r in range(R):
    for k,feature in enumerate(FEATURES,1):
     j=r*b+k;coeff=float(beta[j]);key=f'r{r:02d}_k{k}'
     lp=pointwise_bound(P,j,eps=.1)
     if lp['status']!='optimal':raise RuntimeError((path.name,j,lp))
     for name in ['d','mu','raw_mu']:arrays[f'{key}_lp_{name}']=lp[name]
     for eps in epsilons:
      lp_lower=lp['lower']*eps/.1; lp_upper=lp['upper']*eps/.1
      etazero=coeff**2/(J*Hi[j,j]); tol=1e-7*max(abs(coeff),1.)
      for gamma in gammas:
       target=-(1+gamma)*coeff;eta_analytic=target**2/(J*Hi[j,j]);cost=None;lower=None
       base={'family':family,'fold':fold,'rule':r,'feature_index':k,'feature':feature,'j':j,'R':R,'h':float(z['h']),'lambda':lam,
        'beta':coeff,'beta_raw':coeff/float(z['scale'][k-1]),'epsilon':eps,'gamma':gamma,'J0':J,
        'pointwise_max_lower':lp_lower,'pointwise_max_upper':lp_upper,
        'epsilon_to_target_pointwise_lower':abs(target)*.1/lp['upper'],
        'epsilon_to_target_pointwise_upper':abs(target)*.1/lp['lower'],
        'eta_target_objective_only':eta_analytic,
        'pointwise_only_protected':bool(lp_upper<abs(target)-tol),
        'objective_only_protected_1pct':bool(eta_analytic>.01*(1+1e-8)),
        'support_rows':int((z['W'][:,r]>=.1).sum()),
        'parent_condition':float(np.linalg.cond(P*np.sqrt(z['weight'][:,None]))) }
       if lp_upper < abs(target)-tol:
        base.update(method='LP_EXCLUDES_TARGET',status='TARGET_INFEASIBLE_POINTWISE',minimum_relative_cost=np.inf,dual_lower=np.inf)
       elif lp_lower < abs(target)+tol:
        base.update(method='BOUNDARY',status='NUMERICAL_BOUNDARY_UNRESOLVED',minimum_relative_cost=np.nan,dual_lower=np.nan)
       else:
        d0=target*Hi[:,j]/Hi[j,j]
        if np.max(np.abs(P@d0))<=eps*(1-1e-10):
         d=d0;cost=float(d@H@d/J);lower=eta_analytic
         solve={'d':d,'status':'optimal','cost':cost,'dual_lower':lower,'gap':cost-lower,'stationarity_inf':0.,'iterations':0,'time':0.,'nu':float(-2*target/Hi[j,j]),'upper_mu':np.zeros(n),'lower_mu':np.zeros(n)}
         method='CLOSED_FORM_FEASIBLE'
        else:
         print('QP_START',path.stem,j,eps,gamma,flush=True)
         solve=minimum_cost(P,H,J,j,target,eps,initial=lp['d']*(target/lp['lower']));method='CONVEX_QP'
         print('QP_END',path.stem,j,eps,gamma,solve['status'],solve.get('iterations'),flush=True)
         if solve['status']!='optimal':
          base.update(method=method,status='SOLVER_UNRESOLVED_'+solve['status'],minimum_relative_cost=np.nan,dual_lower=np.nan)
          foldrows.append(base);continue
         d=solve['d'];cost=float(solve['cost']);lower=float(solve['dual_lower'])
        # No replacement of failures or relaxed budgets. These checks can fail execution.
        tc=P@d; hc=Pt@d;newbeta=beta+d
        actual=float((np.mean((yc-P@newbeta)**2)+lam*newbeta@newbeta-J)/J)
        maxtr=float(np.max(np.abs(tc))); equality_error=abs(d[j]-target)
        assert maxtr<=eps+2e-10,(path.name,j,maxtr,eps)
        assert equality_error<1e-8
        assert abs(actual-cost)<2e-9
        assert lower<=cost+2e-9
        if gamma==0:
         status='ZERO_REACHABLE_WITHIN_1PCT' if cost<.01-1e-8 else ('ZERO_EXCLUDED_BY_JOINT_COST' if lower>.01+1e-8 else 'BUDGET_BOUNDARY_UNRESOLVED')
        else:
         status='REVERSAL_WITHIN_1PCT' if cost<=.01-1e-8 and coeff*newbeta[j]<0 else ('REVERSAL_EXCLUDED_BY_JOINT_COST' if lower>.01+1e-8 else 'BUDGET_BOUNDARY_UNRESOLVED')
        base.update(method=method,status=status,minimum_relative_cost=cost,dual_lower=lower,duality_gap=cost-lower,
          max_training_change=maxtr,new_coefficient=float(newbeta[j]),target_error=equality_error,
          direct_objective_excess=actual,max_heldout_change=float(np.max(np.abs(hc))),
          heldout_pointwise_retained=bool(np.max(np.abs(hc))<=eps+1e-9),
          heldout_RMS_change=float(np.sqrt(np.sum(z['weight_test']*hc**2))),
          heldout_error_original=float(np.sqrt(np.sum(z['weight_test']*(z['ytest']-offset-Pt@beta)**2))),
          heldout_error_witness=float(np.sqrt(np.sum(z['weight_test']*(z['ytest']-offset-Pt@newbeta)**2))),
          kkt_inf=solve['stationarity_inf'],iterations=solve['iterations'])
        ek=f'{key}_eps{eps:g}_g{gamma:g}'
        for name in ['d','upper_mu','lower_mu']:
         arrays[f'{ek}_{name}']=solve[name]
        arrays[f'{ek}_nu']=np.array(solve['nu'])
       foldrows.append(base)
   df=pd.DataFrame(foldrows);df.to_csv(resultdir/f'{path.stem}_JOINT.csv',index=False)
   np.savez_compressed(resultdir/f'{path.stem}_WITNESSES.npz',**arrays)
   allrows+=foldrows
   checks.append({'family':family,'fold':fold,'stationarity':float(stationarity),'rows':len(df),'state_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
   print(path.stem,'elapsed',round(time.time()-start,2),'primary',df[(df.epsilon==.1)&(df.gamma==.001)].status.value_counts().to_dict(),flush=True)
 pd.DataFrame(allrows).to_csv(resultdir/'ALL_JOINT_STATEMENTS.csv',index=False)
 (resultdir/'EXECUTION.json').write_text(json.dumps({'elapsed_seconds':time.time()-start,'backend':HIGHS_BACKEND,'epsilons':epsilons,'parents':checks,'rows':len(allrows)},indent=2,default=jsonable))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--families',nargs='+',default=['AIRFOIL_ONESE']);p.add_argument('--epsilons',type=float,nargs='+',default=[.1]);p.add_argument('--output',type=Path);p.add_argument('--gammas',nargs='+',type=float,default=[0.,.001,1.]);a=p.parse_args();run(a.root,a.families,a.epsilons,a.output,a.gammas)
