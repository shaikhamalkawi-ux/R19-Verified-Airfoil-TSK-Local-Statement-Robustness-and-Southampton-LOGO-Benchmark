"""Predeclared descriptive strata after pilot; no subgroup inference or independent geometry validation.
Loads R11 OOF held-out group MSE and the frozen source group metadata.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
BASE=R/'input'/'R10_FROZEN_SOURCE'
OUT=R/'results'/'replay_200'
g=pd.read_csv(BASE/'data'/'group_configurations.csv').sort_values('group_id')
for cell in 'ABCD':
 all_={}
 for i in range(10):
  p=OUT/f'{cell}_outer{i:02d}_R10_B200.json'
  x=json.loads(p.read_text())
  for key,mse in x['test_square_error_by_group'].items():
   assert key not in all_
   all_[key]=mse
 assert len(all_)==106
 g[f'{cell}_mse_dB2']=g.group_id.map(all_)
 assert g[f'{cell}_mse_dB2'].notna().all()
g['B_better_than_A']=g['B_mse_dB2']<g['A_mse_dB2']
g.to_csv(R/'results'/'R11_OOF_GROUP_LOSS_WITH_OPERATING_CONDITIONS.csv',index=False)

# Velocity and chord are directly observed discrete settings. Angle and displacement are three quantile-defined bins (post hoc).
rows=[]
for stratifier in ['velocity_m_s','chord_m','angle_deg','displacement_m']:
 if stratifier in ['velocity_m_s','chord_m']:
  groups=g.groupby(stratifier,observed=True)
 else:
  bins=pd.qcut(g[stratifier],q=3,duplicates='drop')
  groups=g.groupby(bins,observed=True)
 for level, subset in groups:
  mse_a=subset.A_mse_dB2.mean();mse_b=subset.B_mse_dB2.mean()
  rows.append({'stratifier':stratifier,'bin':str(level),'groups':len(subset),
   'A_equal_group_RMSE_dB':float(np.sqrt(mse_a)),'B_equal_group_RMSE_dB':float(np.sqrt(mse_b)),
   'B_minus_A_group_RMSE_dB':float(np.sqrt(mse_b)-np.sqrt(mse_a)),
   'groups_B_mse_better':int(subset.B_better_than_A.sum()),
   'sampling_scope':'descriptive conditional bins, post hoc; no uncertainty interval, causal effect, or new population inference'})
pd.DataFrame(rows).to_csv(R/'results'/'R11_OPERATING_STRATA_EXPLORATORY.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
