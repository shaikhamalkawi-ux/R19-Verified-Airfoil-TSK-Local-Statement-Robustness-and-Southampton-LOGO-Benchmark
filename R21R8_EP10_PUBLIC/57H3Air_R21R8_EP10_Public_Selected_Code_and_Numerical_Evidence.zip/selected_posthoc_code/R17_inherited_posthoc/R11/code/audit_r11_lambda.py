"""Independent record audit of R11 B200 F5 R=10 shared-bootstrap ridge sensitivity.
Does not import or execute the R10 fitting/aggregation implementation.
"""
from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'results'/'lambda_200'
SRC=ROOT/'input'/'R10_FROZEN_SOURCE'
R10OLD=ROOT/'input'/'R10_FROZEN_SOURCE'/'results'/'penalty_sensitivity'
LAM=[1e-6,1e-4,1e-2,1.,100.]
checks=[]
def test(name,x):
 checks.append({'name':name,'passed':bool(x)});
 if not x:print('FAIL',name)
recs=[];rows=[]
for f in range(10):
 p=R/f'D_R10_fold{f:02d}_B200.json'
 test('present_fold'+str(f),p.exists())
 if not p.exists():continue
 r=json.loads(p.read_text());recs.append(r)
 old=json.loads((R10OLD/f'D_R10_fold{f:02d}_B030.json').read_text()) if (R10OLD/f'D_R10_fold{f:02d}_B030.json').exists() else None
 test('fixed_parent_exists_'+str(f),old is not None)
 test('run_meta_'+str(f),r['R']==10 and r['variant']=='D' and r['bootstrap_attempts']==200 and r['parent_success'])
 test('failed_replicates_'+str(f),r['bootstrap_fails']==len(r['failed_indices']) and r['bootstrap_fails']<=200)
 test('match_fraction_bounds_'+str(f),0<=r['match_fraction_mean']<=1)
 for lam in LAM:
  key=f'lambda_{lam:g}'
  x=r[key]
  test('lambda_record_'+str(f)+'_'+key,all(0<=x[k]<1e10 for k in ['D_common_median','D_parent_median','median_retention']) and x['pairs']>=x['empty_pairs'])
  if old:
   current=r[f'mse_by_group_{lam:g}']
   test('fixed_parent_all_group_losses_R10_lock_'+str(f)+'_'+key,current==old[f'mse_by_group_{lam:g}'])
  rows.append({'fold':f,'lambda':lam,'D_common_dB':x['D_common_median'],'D_parent_dB':x['D_parent_median'],'retention':x['median_retention'],'pairs':x['pairs'],'failed':r['bootstrap_fails'],'match_fraction':r['match_fraction_mean']})

summary=[]
if len(recs)==10:
 for lam in LAM:
  losses={key:val for r in recs for key,val in r[f'mse_by_group_{lam:g}'].items()}
  test('unique_group_losses_'+str(lam),len(losses)==106 and sum(len(r[f'mse_by_group_{lam:g}']) for r in recs)==106)
  mm=[r[f'lambda_{lam:g}'] for r in recs]
  summary.append({'lambda':lam,'folds':10,'heldout_groups':len(losses),'group_RMSE_dB':float(np.sqrt(np.mean(list(losses.values())))),
   'median_fold_D_common_dB':float(np.median([s['D_common_median'] for s in mm])),
   'median_fold_D_parent_dB':float(np.median([s['D_parent_median'] for s in mm])),
   'median_fold_retention':float(np.median([s['median_retention'] for s in mm])),
   'median_fold_match_fraction':float(np.median([r['match_fraction_mean'] for r in recs])),
   'bootstrap_attempts':sum(r['bootstrap_attempts'] for r in recs),'failed_FCM':sum(r['bootstrap_fails'] for r in recs),
   'matched_pairs':sum(s['pairs'] for s in mm),'empty_common_pairs':sum(s['empty_pairs'] for s in mm)})
 # all penalties in a fold use identical antecedents, match assignments and masks: verify pair counts and retention.
 for r in recs:
  first=r['lambda_1e-06']
  for lam in LAM:
   z=r[f'lambda_{lam:g}']
   test('shared_penalty_mask_fold'+str(r['fold'])+'_lam'+str(lam),z['pairs']==first['pairs'] and z['empty_pairs']==first['empty_pairs'] and z['median_retention']==first['median_retention'])

pd.DataFrame(rows).to_csv(ROOT/'results'/'R11_RIDGE_B200_FOLD_RESULTS.csv',index=False)
pd.DataFrame(summary).to_csv(ROOT/'results'/'R11_B200_RIDGE_SUMMARY.csv',index=False)
out={'label':'R11 lambda B200 independent record audit','checks':len(checks),'passed':sum(c['passed'] for c in checks),'failures':[c for c in checks if not c['passed']],
     'folds':len(recs),'summary':summary,'caveats':['Separate R10-LAMBDA bootstrap draw ids; do not merge or subtract D across the independent R11 factorial panel without pairing.',
     'Within this penalty panel bootstrap draws, matchings and support are identical across all lambda values.',
     'Fixed out-of-fold predictions independent of bootstrap replication count, no retraining-inclusive CI.',
     'Very high penalties shrink all local coefficients toward zero, leaving the boot-parent mean difference as a floor for D.']}
(ROOT/'qa'/'R11_LAMBDA_INDEPENDENT_AUDIT.json').write_text(json.dumps(out,indent=2))
print('lambda checks',out['passed'],'/',out['checks'],'folds',out['folds'])
print(pd.DataFrame(summary).to_string(index=False))
if out['failures'] or len(recs)!=10:raise SystemExit(1)
