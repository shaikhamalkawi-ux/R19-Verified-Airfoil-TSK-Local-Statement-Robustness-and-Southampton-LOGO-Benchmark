#!/usr/bin/env python3
"""Recompute raw row identity, group splits, fitted design and ridge stationarity,
selection from retained inner scores, selected ET predictions, all primal and dual
certificates. Does not rerun nested tuning or solve the certificate optimization.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import argparse,hashlib,json,urllib.parse,itertools
from pathlib import Path
import numpy as np,pandas as pd,h5py
from scipy.special import logsumexp
from sklearn.ensemble import ExtraTreesRegressor
ROOT=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,default=ROOT/'results');ap.add_argument('--raw',type=Path,default=ROOT/'raw');args=ap.parse_args();p=args.results;raw=next(args.raw.glob('*/.info.json')).parent
 inv=pd.read_csv(p/'source_inventory.csv');assert len(inv)==59
 for r in inv.itertuples(index=False):
  a=(raw/r.file).read_bytes();assert len(a)==r.bytes and hashlib.sha1(a).hexdigest()==r.expected and hashlib.sha256(a).hexdigest()==r.sha256
 d=pd.read_csv(p/'canonical_private.csv');assert len(d)==1464 and d.group.nunique()==122;assert np.array_equal(d.row_id,np.arange(1,1465));assert not d.duplicated(['geometry','angle_deg','frequency_Hz']).any()
 for fname,part in d.groupby('source_file'):
  with h5py.File(raw/fname) as h:
   a=h['angles'][:].ravel();f=h['f'][:];y=h['spl'][:]
  ii=part.source_angle_index.to_numpy();jj=part.source_band_index.to_numpy();assert len(part)==y.size and len(set(zip(ii,jj)))==y.size;assert np.max(abs(a[ii]-part.angle_deg))<1e-12 and np.max(abs(f[ii,jj]-part.frequency_Hz))<1e-10 and np.max(abs(y[ii,jj]-part.spl_dB))<1e-12
 X=np.column_stack((np.log10(d.frequency_Hz),d.angle_deg));Y=d.spl_dB.to_numpy();g=d.group.to_numpy();geos=d.geometry.to_numpy();qarec=[];all_audits=[];allpred=[];coverage={}; maxima=dict(design=0.,ridge_stationarity=0.,ridge_coef=0.,tsk_pred=0.,et_pred=0.,zero_lower_replay=0.,zero_upper_replay=0.,direct_objective=0.,crossing=0.);mins=dict(protection_gap=float('inf'),strict_prediction_slack=float('inf'),strict_objective_slack=float('inf'))
 def update(k,val):maxima[k]=max(maxima[k],float(val))
 for fd in sorted(p.glob('*/fit.json')):
  fd=fd.parent;info=json.loads((fd/'fit.json').read_text());pr=info['protocol'];fold=info['fold'];s=info['selection'];z=np.load(fd/'state.npz',allow_pickle=False);tr,te=z['tr'],z['te'];b=z['beta'];n=len(tr);q=len(b);lam=float(z['lam']);P,Pt=z['P'],z['Pt'];assert len(set(tr)&set(te))==0 and not set(g[tr])&set(g[te])
  expected=np.arange(len(d)) if pr=='LOGO' else np.flatnonzero(geos=='NACA 0012');assert set(tr)|set(te)==set(expected);assert len(set(te))==len(te)
  if pr=='LOGO':assert not set(geos[tr])&set(geos[te]) and len(set(geos[te]))==1
  coverage.setdefault(pr,[]).extend(te.tolist());assert np.max(abs(z['scaler_mean']-X[tr].mean(0)))<1e-12 and np.max(abs(z['scaler_scale']-X[tr].std(0)))<1e-12 and abs(float(z['offset'])-Y[tr].mean())<1e-12
  assert np.max(abs(z['ytrain']-Y[tr]))<1e-12 and len(b)==3*s['R'] and lam==s['lambda'];assert np.all(z['S']>0)
  def design(ix):
   A=(X[ix]-z['scaler_mean'])/z['scaler_scale'];L=-.5*np.sum(((A[:,None,:]-z['C'])/z['S'])**2,axis=-1);W=np.exp(L-logsumexp(L,axis=1,keepdims=True));return np.einsum('ij,ik->ijk',W,np.column_stack((np.ones(len(ix)),A))).reshape(len(ix),q)
  update('design',max(np.max(abs(P-design(tr))),np.max(abs(Pt-design(te)))));y=Y[tr]-float(z['offset']);H=P.T@P/n+lam*np.eye(q);rhs=P.T@y/n;J=np.mean((P@b-y)**2)+lam*b@b;update('ridge_stationarity',np.max(abs(H@b-rhs)));update('ridge_coef',np.max(abs(np.linalg.solve(H,rhs)-b)))
  pred=pd.read_csv(fd/'predictions.csv');assert np.array_equal(pred.row_id.to_numpy(),te+1) and np.max(abs(pred.y-Y[te]))<1e-12;update('tsk_pred',np.max(abs(pred.tsk-(Pt@b+float(z['offset'])))))
  et=info['et'];model=ExtraTreesRegressor(n_estimators=400,random_state=20261007,n_jobs=1,bootstrap=False,min_samples_leaf=et['min_samples_leaf'],max_features=et['max_features'],max_depth=et['max_depth']).fit(X[tr],Y[tr]);update('et_pred',np.max(abs(model.predict(X[te])-pred.extra_trees)))
  splits=pd.read_csv(fd/'inner_splits.csv');counts=[];vseen=[];nr=3 if pr=='LOGO' else 5;assert splits.inner.nunique()==nr
  for i,ss in splits.groupby('inner'):
   it=ss[ss.role=='train'].row_id.to_numpy()-1;iv=ss[ss.role=='validation'].row_id.to_numpy()-1;assert set(it)|set(iv)==set(tr) and not set(it)&set(iv) and not set(g[it])&set(g[iv]);assert len(set(it))==len(it) and len(set(iv))==len(iv);vseen.extend(iv.tolist());counts.append(len(set(g[iv])))
   if pr=='LOGO':assert not set(geos[it])&set(geos[iv]) and len(set(geos[iv]))==1
  assert sorted(vseen)==sorted(tr.tolist())
  cs=pd.read_csv(fd/'tsk_candidates.csv');assert not cs.duplicated(['R','h','lambda','inner']).any();candidates=[]
  for (R,h,l),c in cs.groupby(['R','h','lambda']):
   if len(c)!=nr:continue
   v=c.sort_values('inner').rmse.to_numpy();candidates.append((int(R),float(h),float(l),float(np.sqrt(np.average(v*v,weights=counts))),float(v.std(ddof=1)/np.sqrt(nr))))
  assert len(candidates)==info['complete_tsk_candidates'];best=min(candidates,key=lambda a:a[3]);limit=best[3]+best[4];chosen=min([a for a in candidates if a[3]<=limit+1e-12],key=lambda a:(a[0],a[3],-a[2],abs(a[1]-1),a[1]));assert chosen[:3]==(s['R'],s['h'],s['lambda']) and abs(chosen[3]-s['score'])<1e-12
  etrows=pd.read_csv(fd/'et_candidates.csv');assert len(etrows)==12*nr and not etrows.duplicated(['candidate','inner']).any();sc=[]
  for k,t in etrows.groupby('candidate'):
   v=t.sort_values('inner').rmse.to_numpy();sc.append((np.sqrt(np.average(v*v,weights=counts)),int(k)))
  assert min(sc)[1]==et['candidate'];assert abs(min(sc)[0]-et['score'])<1e-12
  # exact feature-coordinate coverage, not a statistical extrapolation claim
  traincoords=set(map(tuple,X[tr]));same=sum(tuple(x) in traincoords for x in X[te]);qarec.append(dict(protocol=pr,fold=fold,heldout_rows=len(te),heldout_spectra=len(set(g[te])),heldout_exact_feature_matches=same,selected_rules=s['R'],complete_tsk_candidates=len(candidates),fcm_restart_failures=int((~pd.read_csv(fd/'fcm_restarts.csv').converged).sum())))
  tab=pd.read_csv(fd/'slope_audit.csv');ev=np.load(fd/'slope_evidence.npz',allow_pickle=False);assert len(tab)==4*s['R'] and not tab.duplicated(['epsilon','j']).any();used=set();assert set(tab.epsilon)=={.1,1.}
  def audit_record(r,side,U,stem):
   st=getattr(r,side+'_status');j=int(r.j);a=np.eye(q)[j];eps=float(r.epsilon);v=np.linalg.solve(H,a);eta0=b[j]**2/(J*(a@v));assert abs(b[j]-r.base)<1e-10
   if st=='PROTECTED_SUBSET':assert r.train_status.startswith('PROTECTED');return
   if st=='ORIGINAL_WITNESS_RETAINED':assert r.train_status=='STRICT_REVERSAL' and r.train_witness_test<=eps;return
   recorded=getattr(r,side+'_zero_eta0');assert abs(eta0-recorded)<1e-8*max(1.,eta0)
   if st=='PROTECTED_OBJECTIVE':assert eta0>.01+1e-10;return
   dk,ik,uk=[stem+'_zero_'+k for k in ['d','ix','u']];assert all(k in ev.files for k in [dk,ik,uk]);used.update([dk,ik,uk]);delta,ix,u=ev[dk],ev[ik],ev[uk];assert len(ix)==len(u) and len(set(ix))==len(ix) and np.all((ix>=0)&(ix<len(U))) and sum(abs(u))<=1+1e-10
   d0=-b[j]*v/(a@v);room=.01*J-b[j]**2/(a@v);ad=U[ix].T@u;tangent=np.linalg.solve(H,ad)-v*(v@ad)/(a@v);assert room>=0
   rawlo=ad@d0-np.sqrt(room*max(0,tangent@H@tangent));rawup=max(abs(U@delta));guard=1e-9*max(1.,abs(rawlo),rawup);lo=max(0,rawlo-guard);up=rawup+guard;assert lo<=up+1e-9 and abs(delta[j]+b[j])<1e-8*max(1,abs(b[j])) and delta@H@delta/J<=.0100000001;update('zero_lower_replay',abs(lo-getattr(r,side+'_zero_lower')));update('zero_upper_replay',abs(up-getattr(r,side+'_zero_upper')))
   if st=='PROTECTED_BOUND':assert lo>eps;mins['protection_gap']=min(mins['protection_gap'],lo-eps);return
   assert st=='STRICT_REVERSAL',st;key=stem+'_strict';w=ev[key];used.add(key);train=max(abs(P@w));test=max(abs(Pt@w));actual=(np.mean((P@(b+w)-y)**2)+lam*((b+w)@(b+w))-J)/J;update('direct_objective',abs(actual-w@H@w/J));update('crossing',abs((b[j]+w[j])/b[j]+.001));assert (b[j]+w[j])*b[j]<0 and max(abs(U@w))<=eps+1e-10 and actual<=.01+1e-10;assert abs(train-getattr(r,side+'_witness_train'))<1e-8 and abs(test-getattr(r,side+'_witness_test'))<1e-8 and abs(actual-getattr(r,side+'_witness_eta'))<1e-9;mins['strict_prediction_slack']=min(mins['strict_prediction_slack'],eps-max(abs(U@w)));mins['strict_objective_slack']=min(mins['strict_objective_slack'],.01-actual)
  for r in tab.itertuples(index=False):
   k=1 if r.feature=='log10_frequency' else 2;assert r.j==3*r.rule+k;stem=f'e{r.epsilon:g}_r{r.rule:02}_k{k}';audit_record(r,'train',P,stem+'_train');audit_record(r,'joint',np.vstack([P,Pt]),stem+'_joint')
  assert used==set(ev.files);tab.insert(0,'protocol',pr);tab.insert(1,'fold',fold);all_audits.append(tab);pred.insert(0,'protocol',pr);pred.insert(1,'fold',fold);allpred.append(pred)
 assert sorted(coverage['LOGO'])==list(range(1464)) and sorted(coverage['NACA0012'])==list(np.flatnonzero(geos=='NACA 0012'));assert len(qarec)==9
 for k,v in maxima.items():assert v<1e-7,(k,v)
 audits=pd.concat(all_audits,ignore_index=True);preds=pd.concat(allpred,ignore_index=True);audits.to_csv(p/'all_slope_audits.csv',index=False);preds.to_csv(p/'all_predictions.csv',index=False);pd.DataFrame(qarec).to_csv(p/'fold_QA.csv',index=False)
 summary=[];metrics=[]
 for (pr,e),t in audits.groupby(['protocol','epsilon']):
  for feature,ss in [('all',t),*list(t.groupby('feature'))]:
   rev=ss[ss.train_status=='STRICT_REVERSAL'];summary.append(dict(protocol=pr,epsilon=e,feature=feature,statements=len(ss),train_protected=int(ss.train_status.str.startswith('PROTECTED').sum()),train_reversible=len(rev),train_unresolved=int((ss.train_status=='UNRESOLVED').sum()),original_witness_retained=int((rev.train_witness_test<=e).sum()),joint_protected=int(ss.joint_status.str.startswith('PROTECTED').sum()),joint_reversible=int(ss.joint_status.isin(['STRICT_REVERSAL','ORIGINAL_WITNESS_RETAINED']).sum()),joint_unresolved=int((ss.joint_status=='UNRESOLVED').sum())))
 for pr,t in preds.groupby('protocol'):
  for support,ss in [('all',t),('common_angles_ge_minus4',t[t.angle>=-4])]:
   for m in ['tsk','extra_trees']:
    loss=(ss[m]-ss.y)**2;keys=ss.geometry if pr=='LOGO' else ss.group;metrics.append(dict(protocol=pr,support=support,model=m,rows=len(ss),spectra=ss.group.nunique(),rmse_dB=float(np.sqrt(loss.groupby(keys).mean().mean()))))
 pd.DataFrame(summary).to_csv(p/'classification_summary.csv',index=False);pd.DataFrame(metrics).to_csv(p/'prediction_summary.csv',index=False)
 out=dict(status='PASS',source_sha1_matches=59,rows=1464,spectra=122,outer_folds=9,inner_folds=37,budget_statement_tests=len(audits),original_strict_witnesses=int((audits.train_status=='STRICT_REVERSAL').sum()),all_training_classifications_resolved=not (audits.train_status=='UNRESOLVED').any(),all_joint_classifications_resolved=not (audits.joint_status=='UNRESOLVED').any(),max_errors=maxima,min_margins=mins,scope='independent source row alignment, split checks, stored score selection, fixed-design ridge and selected Extra Trees replay, all primal/dual certificate checks; no inner tuning refit or optimizer rerun')
 (p/'independent_QA.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));print(pd.DataFrame(summary).to_string(index=False));print(pd.DataFrame(metrics).to_string(index=False));print(pd.DataFrame(qarec).to_string(index=False))
if __name__=='__main__':main()
